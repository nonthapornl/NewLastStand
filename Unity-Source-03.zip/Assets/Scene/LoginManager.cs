﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class LoginManager : MonoBehaviour
{
    private const string LoginSceneName = "LogINScene";

    [Header("Login UI")]
    public TMP_InputField usernameInput;
    public TMP_Dropdown difficultyDropdown;
    public Button startButton;

    [Header("Scene")]
    public string gameSceneName = "Play scene";

    private void Reset()
    {
        AutoBindUi();
    }

    private void OnValidate()
    {
        AutoBindUi();
    }

    private void Awake()
    {
        if (!IsLoginScene())
        {
            enabled = false;
            return;
        }
        
        GameData.ResetForNewPlayer();
        AutoBindUi();
        ConfigureUsernameLayout();
        gameObject.AddComponent<MainMenuView>().Build(this);

        if (difficultyDropdown != null && difficultyDropdown.options.Count >= 3)
        {
            difficultyDropdown.options[0].text = "Easy";
            difficultyDropdown.options[1].text = "Medium";
            difficultyDropdown.options[2].text = "Hard";
            difficultyDropdown.RefreshShownValue();
        }

        if (startButton != null)
        {
            startButton.onClick.RemoveListener(OnPlayPressed);
            startButton.onClick.AddListener(OnPlayPressed);
        }
    }

    private void AutoBindUi()
    {
        if (usernameInput == null)
            usernameInput = FindComponentByName<TMP_InputField>("UsernameInput");

        if (difficultyDropdown == null)
            difficultyDropdown = FindComponentByName<TMP_Dropdown>("DifficultyDropdown");

        if (startButton == null)
            startButton = FindComponentByName<Button>("StartButton");
    }

    private void ConfigureUsernameLayout()
    {
        if (usernameInput == null) return;
        // Retain the scene's pixel font for Latin. Thai glyphs are supplied by
        // the global Sarabun fallback, including names mixing both scripts.
        if (usernameInput.textComponent != null && usernameInput.textComponent.font != null)
            usernameInput.fontAsset = usernameInput.textComponent.font;
        usernameInput.pointSize = 18f;
        RectTransform field = usernameInput.GetComponent<RectTransform>();
        field.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, Mathf.Max(36f, field.rect.height));
        field.anchoredPosition += new Vector2(0f, 3f);
        RectTransform viewport = usernameInput.textViewport;
        if (viewport != null)
        {
            viewport.anchorMin = Vector2.zero;
            viewport.anchorMax = Vector2.one;
            viewport.offsetMin = new Vector2(8f, 2f);
            viewport.offsetMax = new Vector2(-8f, -2f);
        }
        ConfigureUsernameText(usernameInput.textComponent);
        ConfigureUsernameText(usernameInput.placeholder as TMP_Text);
    }

    private static void ConfigureUsernameText(TMP_Text text)
    {
        if (text == null) return;
        text.alignment = TextAlignmentOptions.Center;
        text.enableAutoSizing = false;
        text.fontSize = 18f;
        text.margin = Vector4.zero;
        text.extraPadding = true;
        text.useMaxVisibleDescender = false;
        RectTransform rect = text.rectTransform;
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = rect.offsetMax = Vector2.zero;
    }

    private T FindComponentByName<T>(string name) where T : Component
    {
        GameObject go = GameObject.Find(name);
        if (go == null)
            go = GameObject.Find($"{name}(Clone)");

        if (go == null)
            return null;

        return go.GetComponent<T>();
    }

    public void OnPlayPressed()
    {
        if (!IsLoginScene())
            return;

        AutoBindUi();

        GameData.ResetForNewPlayer();

        if (usernameInput != null)
        {
            GameData.username = string.IsNullOrWhiteSpace(usernameInput.text)
                ? "Player"
                : usernameInput.text;
        }

        if (difficultyDropdown != null)
        {
            GameData.selectedLevel = (FruitSpeedLevel)Mathf.Clamp(difficultyDropdown.value, 0, 2);
        }

        GameData.score = 0;
        GameData.timeRemaining = GameData.MatchDurationSeconds;

        if (!string.IsNullOrEmpty(gameSceneName))
        {
            SceneManager.LoadScene(gameSceneName);
        }
    }

    private bool IsLoginScene()
    {
        return gameObject.scene.name == LoginSceneName;
    }
}
