using UnityEngine;

// Replaces only the visual; every character shares the original movement and hitbox.
public sealed class SelectedCharacterVisual : MonoBehaviour
{
    private CatchCharacter character;
    private SpriteRenderer visual;
    private Rigidbody2D body;
    private PlayerMovement movement;
    private Vector3 localFeet;
    private Sprite[] current;
    private float clock;
    private void Start()
    {
        character = CharacterCatalog.Load(CharacterCatalog.Selection);
        if (character == null || character.idle == null || character.idle.Length == 0) return;
        var original = GetComponent<SpriteRenderer>();
        var animator = GetComponent<Animator>();
        if (animator != null) animator.enabled = false;
        if (original == null) return;
        Bounds bounds = original.bounds;
        original.enabled = false;
        var child = new GameObject("Selected character visual");
        child.transform.SetParent(transform, false);
        visual = child.AddComponent<SpriteRenderer>();
        visual.sortingLayerID = original.sortingLayerID;
        visual.sortingOrder = original.sortingOrder;
        visual.sprite = character.idle[0];
        float height = Mathf.Max(1f, bounds.size.y);
        float scale = height / visual.sprite.bounds.size.y / Mathf.Abs(transform.lossyScale.y);
        child.transform.localScale = Vector3.one * scale;
        child.transform.position = new Vector3(bounds.center.x, bounds.min.y, transform.position.z);
        localFeet = child.transform.localPosition;
        ApplyFrame(character.idle[0]);
        body = GetComponent<Rigidbody2D>();
        movement = GetComponent<PlayerMovement>();
        current = character.idle;
    }
    private void LateUpdate()
    {
        if (visual == null || body == null) return;
        bool airborne = (movement != null && !movement.IsGrounded) || Mathf.Abs(body.linearVelocity.y) > 8f;
        Sprite[] next = airborne && character.air.Length > 0 ? character.air
            : Mathf.Abs(body.linearVelocity.x) > 1f && character.run.Length > 0 ? character.run : character.idle;
        if (next != current) { current = next; clock = 0f; }
        clock += Time.deltaTime;
        ApplyFrame(current[(int)(clock * 8f) % current.Length]);
        if (Mathf.Abs(body.linearVelocity.x) > 1f) visual.flipX = body.linearVelocity.x < 0f;
    }

    private void ApplyFrame(Sprite frame)
    {
        visual.sprite = frame;
        // Doki's source uses centred pivots; the other characters use bottom pivots.
        // Align both to the original feet without changing the shared hitbox.
        visual.transform.localPosition = localFeet - Vector3.up * (frame.bounds.min.y * visual.transform.localScale.y);
    }
}
