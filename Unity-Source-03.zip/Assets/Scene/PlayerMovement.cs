
using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

public class PlayerMovement : MonoBehaviour
{
    [Header("ความเร็วเคลื่อนที่")]
    public float moveSpeed = 5f;

    [Header("Jump")]
    public float jumpForce = 8f;
    public float gravityScale = 1f;
    public float fastFallSpeed = 12f;
    public float groundCheckRadius = 0.2f;
    public LayerMask groundLayer;

    [Header("Dash - ระบบพุ่งแนวนอน")]
    [SerializeField] private float dashSpeed = 1400f;
    [SerializeField] private float dashDuration = 0.18f;
    [SerializeField] private float dashCooldown = 0.8f;

    private MpuHandInput mpuInput;
    private MediaPipeHandInput cameraInput;
    private Rigidbody2D rb;
    private Collider2D playerCollider;
    private Camera gameplayCamera;
    private SpriteRenderer spriteRenderer;
    private Animator animator;
    private bool hasIsRunningParameter;
    private bool hasIsJumpingParameter;

    private bool isGrounded;
    public bool IsGrounded => isGrounded;
    private Vector3 normalScale;
    private float appliedSize = 1f;
    public float SizeMultiplier => appliedSize;
    private bool isDashing;
    public bool SkillActive => isDashing;
    public int DashDirection { get; private set; }
    public float HorizontalIntent { get; private set; }
    private float nextDashTime;
    private readonly Collider2D[] groundHits = new Collider2D[8];

    private void Awake()
    {
        normalScale = transform.localScale;
        mpuInput = GetComponent<MpuHandInput>();
        cameraInput = GetComponent<MediaPipeHandInput>();
        rb = GetComponent<Rigidbody2D>();
        playerCollider = GetComponent<Collider2D>();
        gameplayCamera = Camera.main;
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        animator = GetComponentInChildren<Animator>();
        CacheAnimatorParameters();
        if (GetComponent<SelectedCharacterVisual>() == null) gameObject.AddComponent<SelectedCharacterVisual>();
        if (mpuInput != null && GetComponent<PiezoShockwave>() == null) gameObject.AddComponent<PiezoShockwave>();

        if (rb == null)
        {
            Debug.LogError("ไม่พบ Rigidbody2D บนตัวละคร");
            enabled = false;
            return;
        }

        rb.bodyType = RigidbodyType2D.Dynamic;
        rb.gravityScale = gravityScale;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        rb.freezeRotation = true;

        if (groundLayer.value == 0)
            groundLayer = LayerMask.GetMask("Ground");
    }

    private void Update()
    {
        if (rb == null || Time.timeScale <= 0f) return;
        isGrounded = CheckGrounded();

        float moveInput = 0f;
        bool jumpPressed = false;
        bool dashLeft = false;
        bool dashRight = false;
        bool keyboardDirectionHeld = false;
        int keyboardHorizontal = 0;
        bool fastFall = false, shiftPressed = false, shiftHeld = false, directionPressed = false;

        if (GamePreferences.Controls == ControlScheme.Keyboard && Keyboard.current != null)
        {
            var keyboard = Keyboard.current;

            bool left = keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed;
            bool right = keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed;
            keyboardDirectionHeld = left || right;
            keyboardHorizontal = (right ? 1 : 0) - (left ? 1 : 0);
            moveInput = keyboardHorizontal;

            jumpPressed =
                keyboard.wKey.wasPressedThisFrame ||
                keyboard.upArrowKey.wasPressedThisFrame;
            fastFall = keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed;
            shiftPressed = (keyboard.leftShiftKey.wasPressedThisFrame || keyboard.rightShiftKey.wasPressedThisFrame);
            shiftHeld = (keyboard.leftShiftKey.isPressed || keyboard.rightShiftKey.isPressed);
            directionPressed = keyboard.aKey.wasPressedThisFrame || keyboard.leftArrowKey.wasPressedThisFrame ||
                keyboard.dKey.wasPressedThisFrame || keyboard.rightArrowKey.wasPressedThisFrame;
        }

        // Each mode reads only its selected controller. The shared serial
        // component remains active in all modes to supply magnet distance.
        if (GamePreferences.Controls == ControlScheme.Gyro && mpuInput != null && mpuInput.isActiveAndEnabled && mpuInput.Connected)
        {
            jumpPressed |= mpuInput.JumpPressed;
            if (mpuInput.takeMovementControlWhenConnected)
            {
                moveInput = mpuInput.Horizontal;
                dashLeft = mpuInput.DashDirection < 0;
                dashRight = mpuInput.DashDirection > 0;
            }
            else
            {
                if (mpuInput.HasDirectionalInput) moveInput = mpuInput.Horizontal;
                if (mpuInput.DashDirection != 0)
                {
                    dashLeft = mpuInput.DashDirection < 0;
                    dashRight = mpuInput.DashDirection > 0;
                }
            }
        }
        if (GamePreferences.Controls == ControlScheme.Joystick && mpuInput != null && mpuInput.isActiveAndEnabled && mpuInput.StickConnected)
        {
            if (mpuInput.StickHorizontal != 0)
            {
                moveInput = mpuInput.StickHorizontal;
                dashLeft = dashRight = false;
            }
            jumpPressed |= mpuInput.StickJumpPressed;
            if (mpuInput.StickDashDirection != 0)
            {
                dashLeft = mpuInput.StickDashDirection < 0;
                dashRight = mpuInput.StickDashDirection > 0;
            }
        }
        if (GamePreferences.Controls == ControlScheme.Camera)
        {
            if (cameraInput != null && cameraInput.CameraLive)
            {
                moveInput = cameraInput.Horizontal;
                dashLeft = cameraInput.DashDirection < 0;
                dashRight = cameraInput.DashDirection > 0;
                jumpPressed = cameraInput.JumpPressed;
            }
            if (Keyboard.current is Keyboard keyboard)
            {
                jumpPressed |= keyboard.wKey.wasPressedThisFrame || keyboard.upArrowKey.wasPressedThisFrame;
                fastFall = keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed;
            }
        }
        // Manual keyboard direction has the highest priority.
        if (keyboardDirectionHeld)
        {
            moveInput = keyboardHorizontal;
            dashLeft = dashRight = false;
        }
        // Accept either order: hold direction then tap Shift, or hold Shift
        // then press direction. Holding the chord does not auto-repeat dashes.
        if (shiftPressed || (shiftHeld && directionPressed))
        {
            dashLeft = moveInput < 0f;
            dashRight = moveInput > 0f;
        }
        // Reverse the final intent so keyboard, joystick and gyro behave alike.
        if (GameData.Potions.DirectionFactor(Time.time) < 0f)
        {
            moveInput = -moveInput;
            bool left = dashLeft; dashLeft = dashRight; dashRight = left;
        }
        HorizontalIntent = moveInput;
        if (!isDashing)
        {
            if (dashLeft && Time.time >= nextDashTime)
                StartCoroutine(Dash(-1));

            else if (dashRight && Time.time >= nextDashTime)
                StartCoroutine(Dash(1));

            if (!isDashing)
            {
                if (jumpPressed && isGrounded)
                {
                    rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
                    GameAudio.Play("Jump", .35f, 1f, .15f);
                }
                if (fastFall && !isGrounded)
                    rb.linearVelocity = new Vector2(rb.linearVelocity.x, Mathf.Min(rb.linearVelocity.y, -fastFallSpeed));
                rb.linearVelocity = new Vector2(moveInput * moveSpeed * GameData.Potions.MoveFactor(Time.time), rb.linearVelocity.y);
            }
        }

        if (spriteRenderer != null && moveInput != 0)
            spriteRenderer.flipX = moveInput < 0;

        if (animator != null && !isDashing)
        {
            if (hasIsRunningParameter)
                animator.SetBool("IsRunning", Mathf.Abs(moveInput) > 0.01f);

            if (hasIsJumpingParameter)
                animator.SetBool("IsJumping", !isGrounded);
        }
    }

    private bool CheckGrounded()
    {
        if (playerCollider == null) return false;
        Bounds bounds = playerCollider.bounds;
        float depth = Mathf.Max(groundCheckRadius, bounds.size.y * 0.04f);
        Vector2 center = new Vector2(bounds.center.x, bounds.min.y - depth * 0.25f);
        var filter = new ContactFilter2D
        {
            useTriggers = false,
            useLayerMask = groundLayer.value != 0,
            layerMask = groundLayer
        };
        int count = Physics2D.OverlapBox(center, new Vector2(bounds.size.x * 0.7f, depth), 0f, filter, groundHits);
        for (int i = 0; i < count; i++)
        {
            Collider2D hit = groundHits[i];
            if (hit == null || hit == playerCollider) continue;
            if (hit.CompareTag("Ground") || (groundLayer.value & (1 << hit.gameObject.layer)) != 0) return true;
        }
        return false;
    }

    private void OnDisable()
    {
        StopAllCoroutines();
        isDashing = false;
        ApplySize(1f);
        if (rb != null) rb.gravityScale = gravityScale;
    }

    private void FixedUpdate()
    {
        if (rb == null)
            return;

        ApplySize(GameData.Potions.SizeFactor(Time.time));

        if (gameplayCamera == null)
        {
            gameplayCamera = Camera.main;
            if (gameplayCamera == null)
                gameplayCamera = FindFirstObjectByType<Camera>();
        }

        if (gameplayCamera == null)
            return;

        float cameraDepth = transform.position.z - gameplayCamera.transform.position.z;
        float leftEdge = gameplayCamera.ViewportToWorldPoint(new Vector3(0f, 0.5f, cameraDepth)).x;
        float rightEdge = gameplayCamera.ViewportToWorldPoint(new Vector3(1f, 0.5f, cameraDepth)).x;
        Vector2 position = rb.position;
        Bounds playerBounds = playerCollider != null ? playerCollider.bounds : new Bounds(transform.position, Vector3.zero);
        if (spriteRenderer != null && spriteRenderer.enabled)
            playerBounds.Encapsulate(spriteRenderer.bounds);
        float minimumX = leftEdge + position.x - playerBounds.min.x;
        float maximumX = rightEdge + position.x - playerBounds.max.x;

        if (minimumX > maximumX)
        {
            Debug.LogError("Player collider is wider than the visible camera area.", this);
            return;
        }

        float clampedX = Mathf.Clamp(position.x, minimumX, maximumX);
        if (!Mathf.Approximately(position.x, clampedX))
            rb.position = new Vector2(clampedX, position.y);

        // Limit the next physics step as well so a dash cannot overshoot the edge.
        Vector2 velocity = rb.linearVelocity;
        float step = Time.fixedDeltaTime;
        float safeX = Mathf.Clamp(velocity.x, (minimumX - clampedX) / step, (maximumX - clampedX) / step);
        if (!Mathf.Approximately(velocity.x, safeX))
            rb.linearVelocity = new Vector2(safeX, velocity.y);
    }

    private void ApplySize(float factor)
    {
        if (rb == null || Mathf.Approximately(appliedSize, factor)) return;
        float feet = playerCollider != null ? playerCollider.bounds.min.y : transform.position.y;
        transform.localScale = normalScale * factor;
        Physics2D.SyncTransforms();
        if (playerCollider != null)
            rb.position += Vector2.up * (feet - playerCollider.bounds.min.y);
        appliedSize = factor;
    }

    private void CacheAnimatorParameters()
    {
        if (animator == null || animator.runtimeAnimatorController == null)
            return;

        foreach (AnimatorControllerParameter parameter in animator.parameters)
        {
            if (parameter.type != AnimatorControllerParameterType.Bool)
                continue;

            if (parameter.name == "IsRunning")
                hasIsRunningParameter = true;
            else if (parameter.name == "IsJumping")
                hasIsJumpingParameter = true;
        }
    }

    private IEnumerator Dash(int direction)
    {
        isDashing = true;
        DashDirection = direction;
        GameAudio.Play("Dash", .5f, 1f, .2f);
        nextDashTime = Time.time + dashCooldown;

        // ล็อกการเคลื่อนที่ในแนวตั้งชั่วคราว
        float originalGravity = rb.gravityScale;
        rb.gravityScale = 0f;
        rb.linearVelocity = new Vector2(direction * dashSpeed, 0f);

        if (spriteRenderer != null)
            spriteRenderer.flipX = direction < 0;

        Debug.Log("Dash direction: " + direction +
                  " | Speed: " + dashSpeed);

        yield return new WaitForSeconds(dashDuration);

        rb.gravityScale = originalGravity;
        rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
        isDashing = false;
        DashDirection = 0;
    }
}
