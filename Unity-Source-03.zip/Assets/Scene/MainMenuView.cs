using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Four focused pages share one canvas and preserve the existing login/round flow.
public sealed class MainMenuView : MonoBehaviour
{
    private readonly Color ink = new Color(.055f,.20f,.19f);
    private readonly Color paper = new Color(.97f,.98f,.88f,.98f);
    private readonly Color selected = new Color(1f,.72f,.29f);
    private Canvas canvas;
    private LoginManager login;
    private TMP_FontAsset font;
    private RectTransform settings;
    private TMP_Text volumeText,musicText,effectsText,hintsText,magnetText,summary,helpTip;
    private readonly TMP_Text[] helpActions = new TMP_Text[4], helpBindings = new TMP_Text[4];
    private readonly Image[] potionHelpIcons = new Image[5];
    private readonly TMP_Text[] potionHelpNames = new TMP_Text[5], potionHelpEffects = new TMP_Text[5];
    private readonly GameObject[] potionHelpRows = new GameObject[5];
    private TMP_Text poisonHelpNote;
    private Image goodPotionTab, poisonPotionTab;
    private readonly GameObject[] pages = new GameObject[4];
    private readonly RectTransform[] homeCatchers = new RectTransform[3];
    private readonly Image[] previews = new Image[3];
    private readonly List<Image> catcherCards = new List<Image>();
    private readonly List<Image> difficultyCards = new List<Image>();
    private readonly List<Image> controlCards = new List<Image>();
    private readonly List<Image> helpTabs = new List<Image>();
    private readonly List<Image> backgroundCards = new List<Image>();
    private readonly Sprite[] fruitSprites = new Sprite[5];
    private BackgroundSelector backgrounds;
    private Sprite originalPreview;
    private int helpReturnPage,helpControl;
    private float clock;
    public int CurrentPage { get; private set; }

    public void Build(LoginManager manager)
    {
        login=manager;
        Canvas original=login.usernameInput.GetComponentInParent<Canvas>();
        font=login.difficultyDropdown.captionText.font;GameUiLayout.MenuFont=font;
        canvas=new GameObject("MainMenuCanvas",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster)).GetComponent<Canvas>();
        canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=80;GameUiLayout.ScaleCanvas(canvas);
        GameUiLayout.Panel("Menu tint",canvas.transform,Vector2.zero,Vector2.one,new Color(.02f,.14f,.12f,.10f));
        backgrounds=FindFirstObjectByType<BackgroundSelector>();
        originalPreview=Resources.Load<CatchCharacter>("Characters/Character0")?.idle[0];
        foreach(SpriteRenderer renderer in FindObjectsByType<SpriteRenderer>(FindObjectsSortMode.None))
        {
            string n=renderer.name.ToLowerInvariant();
            int i=n.Contains("orange")?0:n.Contains("coconut")?1:n.Contains("banana")?2:n.Contains("pineapple")?4:n.Contains("apple")?3:-1;
            if(i>=0){fruitSprites[i]=renderer.sprite;renderer.enabled=false;}
            if(n=="ui-frames_0")renderer.enabled=false;
        }
        for(int i=0;i<4;i++)pages[i]=GameUiLayout.Panel("MenuPage"+i,canvas.transform,Vector2.zero,Vector2.one,Color.clear).gameObject;
        BuildHome();BuildCatchers();BuildSetup();BuildHelp();CreateSettings();
        // Hidden legacy dropdowns retain serialized data and existing listeners.
        Transform storage=new GameObject("Menu data").transform;storage.SetParent(canvas.transform,false);
        ApplyDropdownFont(login.difficultyDropdown);
        login.difficultyDropdown.transform.SetParent(storage,false);
        if(backgrounds!=null&&backgrounds.MenuDropdown!=null)
        {
            ApplyDropdownFont(backgrounds.MenuDropdown);
            backgrounds.MenuDropdown.transform.SetParent(storage,false);
        }
        storage.gameObject.SetActive(false);
        if(original!=null)original.gameObject.SetActive(false);
        SelectCharacter(CharacterCatalog.Selection);SelectDifficulty(login.difficultyDropdown.value);
        SelectControls((int)GamePreferences.Controls);ShowPage(0);
        StartCoroutine(BuildBackgroundChoices());
    }

    private void BuildHome()
    {
        Transform home=pages[0].transform;
        Image logo=GameUiLayout.Panel("Game logo",home,new Vector2(.23f,.48f),new Vector2(.77f,.95f),Color.white).GetComponent<Image>();
        Texture2D texture=Resources.Load<Texture2D>("Menu/GameLogo");
        if(texture!=null){logo.sprite=Sprite.Create(texture,new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f));logo.preserveAspect=true;}
        Button("Play",home,.36f,.365f,.64f,.475f,()=>ShowPage(1),54);
        Button secondary=Button("How to Play",home,.39f,.25f,.61f,.335f,()=>OpenHelp(0),32);secondary.image.color=new Color(.38f,.58f,.28f);
        Button b=Button("Settings",home,.39f,.14f,.61f,.225f,()=>settings.gameObject.SetActive(true),32);b.image.color=new Color(.38f,.58f,.28f);
        for(int i=0;i<3;i++)
        {
            float x=i==0?.10f:i==1?.235f:.75f;
            Sprite sprite=CharacterSprite(i);
            Image catcher = Icon(sprite, home, x, .09f, x + .14f, .39f);
            catcher.name = CharacterCatalog.Name(i) + " title pose";
            homeCatchers[i] = catcher.rectTransform;
        }
        Label("Catch fruit. Dodge bombs. Find your rhythm.",home,.22f,.025f,.78f,.08f,26);
    }

    private void BuildCatchers()
    {
        Transform page=pages[1].transform;Heading(page,"Choose your catcher","Pick a favourite. Every catcher has the same abilities.");
        for(int i=0;i<3;i++)
        {
            int index=i;float x=.10f+i*.275f;
            RectTransform card=Card("Catcher "+i,page,x,.23f,x+.25f,.78f);
            Image border=card.parent.GetComponent<Image>();catcherCards.Add(border);
            Button select=card.gameObject.AddComponent<Button>();select.targetGraphic=card.GetComponent<Image>();select.onClick.AddListener(()=>SelectCharacter(index));
            card.GetComponent<Image>().raycastTarget=true;
            previews[i]=GameUiLayout.Panel("Catcher preview "+i,card,new Vector2(.20f,.25f),new Vector2(.80f,.86f),Color.white).GetComponent<Image>();
            previews[i].sprite=CharacterSprite(i);previews[i].preserveAspect=true;
            previews[i].rectTransform.pivot=new Vector2(.5f,0f);
            Label(CharacterCatalog.Name(i),card,.05f,.06f,.95f,.22f,38);
        }
        Button("Back",page,.07f,.07f,.23f,.16f,()=>ShowPage(0),32);
        Button("Next >",page,.75f,.07f,.93f,.16f,()=>ShowPage(2),36);
    }

    private void BuildSetup()
    {
        Transform page=pages[2].transform;Heading(page,"Ready to play?","Choose your setup, then start a two-minute round.");
        RectTransform left=Card("Player setup",page,.07f,.23f,.465f,.80f);
        Label("Player name",left,.06f,.81f,.94f,.92f,30,TextAlignmentOptions.Left);
        Move(login.usernameInput.GetComponent<RectTransform>(),left,.06f,.66f,.94f,.81f);
        login.usernameInput.pointSize=34;login.usernameInput.fontAsset=font;login.usernameInput.textComponent.font=font;
        login.usernameInput.characterLimit=24;
        if(login.usernameInput.placeholder is TMP_Text placeholder){placeholder.font=font;placeholder.text="Your name";placeholder.fontSize=30;}
        Label("Difficulty",left,.06f,.52f,.94f,.63f,30,TextAlignmentOptions.Left);
        string[] levels={"Easy","Medium","Hard"};
        for(int i=0;i<3;i++){int index=i;Button b=Button(levels[i],left,.055f+i*.30f,.39f,.335f+i*.30f,.52f,()=>SelectDifficulty(index),28);difficultyCards.Add(b.image);}
        Label("Controls",left,.06f,.25f,.94f,.36f,30,TextAlignmentOptions.Left);
        float controlWidth = .90f / GamePreferences.ControlCount;
        for (int i = 0; i < GamePreferences.ControlCount; i++)
        {
            int index = i;
            float x = .05f + i * controlWidth;
            Button b = Button(GamePreferences.ControlLabels[i], left, x, .08f, x + controlWidth - .015f, .25f, () => SelectControls(index), 25);
            controlCards.Add(b.image);
        }
        RectTransform right=Card("Background choices",page,.49f,.38f,.93f,.80f);
        Label("Choose background",right,.04f,.82f,.96f,.97f,32);
        backgroundContainer=right;
        RectTransform recap=Card("Setup summary",page,.49f,.23f,.93f,.355f);
        summary=Label("",recap,.02f,.08f,.98f,.92f,27);
        summary.textWrappingMode=TextWrappingModes.NoWrap;
        Button("Back",page,.07f,.07f,.23f,.16f,()=>ShowPage(1),32);
        Button("How to Play",page,.40f,.07f,.60f,.16f,()=>OpenHelp(2),28);
        Move(login.startButton.GetComponent<RectTransform>(),page,.72f,.07f,.93f,.16f);
        TMP_Text start=login.startButton.GetComponentInChildren<TMP_Text>(true);
        if(start!=null){start.font=font;start.text="Start Game";GameUiLayout.Style(start,login.startButton.transform,new Vector2(.03f,.08f),new Vector2(.97f,.92f),36,Color.white);}
    }
    private RectTransform backgroundContainer;
    private IEnumerator BuildBackgroundChoices()
    {
        yield return null; // BackgroundSelector.Start populates sprites and names.
        if(backgrounds==null)yield break;
        int count=backgrounds.Backgrounds.Count;
        for(int i=0;i<count;i++)
        {
            int index=i;float step=.92f/Mathf.Max(1,count),x=.04f+i*step;
            RectTransform card=Card("Background "+i,backgroundContainer,x,.10f,x+step-.018f,.79f);
            backgroundCards.Add(card.parent.GetComponent<Image>());
            Button b=card.gameObject.AddComponent<Button>();b.targetGraphic=card.GetComponent<Image>();card.GetComponent<Image>().raycastTarget=true;
            b.onClick.AddListener(()=>{backgrounds.Choose(index);RefreshSelection();});
            Image thumbnail=GameUiLayout.Panel("Background thumbnail",card,new Vector2(.04f,.29f),new Vector2(.96f,.96f),Color.white).GetComponent<Image>();
            thumbnail.sprite=backgrounds.Backgrounds[i];thumbnail.preserveAspect=false;
            Label(backgrounds.OptionName(i).Replace(" ","\n"),card,.025f,.02f,.975f,.27f,23);
        }
        RefreshSelection();
    }

    private void BuildHelp()
    {
        Transform page=pages[3].transform;
        Heading(page,"How to play","Choose a controller. Learn the moves. Catch the good stuff!");
        RectTransform left=Card("Control guide",page,.06f,.30f,.49f,.81f);
        Label("Controls",left,.05f,.86f,.95f,.98f,36);
        float tabWidth = .92f / GamePreferences.ControlCount;
        for(int i=0;i<GamePreferences.ControlCount;i++)
        {
            int index=i;
            float x = .045f + i * tabWidth;
            Button b=Button(GamePreferences.ControlLabels[i],left,x,.735f,x + tabWidth - .015f,.855f,()=>ShowHelpControls(index),28);
            helpTabs.Add(b.image);
        }
        for(int i=0;i<4;i++)
        {
            float y=.575f-i*.135f;
            RectTransform row=GameUiLayout.Panel("Control row "+i,left,new Vector2(.05f,y),new Vector2(.95f,y+.115f),new Color(.87f,.92f,.79f));
            helpActions[i]=Label("",row,.025f,.05f,.26f,.95f,32,TextAlignmentOptions.MidlineLeft);
            helpBindings[i]=Label("",row,.27f,.05f,.98f,.95f,29,TextAlignmentOptions.MidlineLeft);
            helpBindings[i].textWrappingMode=TextWrappingModes.NoWrap;
        }
        helpTip=Label("",left,.06f,.015f,.94f,.14f,25,TextAlignmentOptions.MidlineLeft);
        RectTransform right=Card("Collectibles",page,.51f,.30f,.94f,.81f);
        Label("Fruit points",right,.03f,.86f,.97f,.98f,34);
        int[] points={50,40,30,20,10};

        for(int i=0;i<5;i++)
        {
            float x=.035f+i*.19f;
            Icon(fruitSprites[i],right,x+.035f,.72f,x+.125f,.85f);
            Label(points[i].ToString(),right,x,.63f,x+.17f,.72f,31);
            float y=.405f-i*.083f;
            RectTransform row=GameUiLayout.Panel("Potion row "+i,right,new Vector2(.045f,y),new Vector2(.955f,y+.076f),new Color(.87f,.92f,.79f));
            potionHelpRows[i]=row.gameObject;
            potionHelpIcons[i]=Icon(null,row,.015f,.06f,.085f,.94f);
            potionHelpNames[i]=Label("",row,.10f,.04f,.38f,.96f,26,TextAlignmentOptions.MidlineLeft);
            potionHelpEffects[i]=Label("",row,.39f,.04f,.99f,.96f,25,TextAlignmentOptions.MidlineLeft);
        }
        goodPotionTab=Button("Good potions",right,.045f,.515f,.48f,.61f,()=>ShowPotionGuide(false),26).image;
        poisonPotionTab=Button("Poison !",right,.52f,.515f,.955f,.61f,()=>ShowPotionGuide(true),26).image;
        poisonHelpNote=Label("Red ! = poison. Effects wear off.\nShield blocks bombs, not poison.",right,.05f,.02f,.95f,.21f,23,TextAlignmentOptions.MidlineLeft);
        ShowPotionGuide(false);
        RectTransform magnet=Card("Magnet guide",page,.06f,.155f,.94f,.28f);
        Label("MAGNET",magnet,.02f,.14f,.17f,.86f,32);
        Label("Keyboard / Camera: set Magnet % in Settings",magnet,.18f,.45f,.98f,.91f,28,TextAlignmentOptions.MidlineLeft);
        Label("Joystick / Gyro: 5-70 cm sensor; manual if disconnected. Pulls bombs too!",magnet,.18f,.07f,.98f,.49f,26,TextAlignmentOptions.MidlineLeft);
        Button("Back",page,.06f,.035f,.22f,.125f,()=>ShowPage(helpReturnPage),32);
        Button("Got it!",page,.77f,.035f,.94f,.125f,()=>ShowPage(helpReturnPage),34);
        ShowHelpControls((int)GamePreferences.Controls);
    }
    private void ShowPotionGuide(bool poison)
    {
        string[] names=poison?new[]{"Shrink","Sluggish","Confuse"}:new[]{"Heal","Shield","Score x2","Speed","Slow"};
        string[] effects=poison?new[]{"Size 60% / 6s","Move 60% / 6s","Reverse L/R / 5s"}
            :new[]{"+1 heart (max 3)","Block 1 bomb / 8s","Double points / 10s","Move faster / 8s","Slower drops / 6s"};
        for(int i=0;i<5;i++)
        {
            bool active=i<names.Length;potionHelpRows[i].SetActive(active);if(!active)continue;
            Sprite[] sprites=PotionSpriteLibrary.Frames((PotionKind)(poison?5+i:i));
            potionHelpIcons[i].sprite=sprites.Length>0?sprites[0]:null;potionHelpIcons[i].enabled=sprites.Length>0;
            potionHelpNames[i].text=names[i];potionHelpEffects[i].text=effects[i];
            potionHelpRows[i].GetComponent<Image>().color=poison?new Color(1f,.85f,.81f):new Color(.87f,.92f,.79f);
        }
        poisonHelpNote.enabled=poison;
        goodPotionTab.color=poison?ink:Color.white;poisonPotionTab.color=poison?Color.white:ink;
    }
    private void ShowHelpControls(int index)
    {
        helpControl=index;
        ControlScheme scheme=(ControlScheme)Mathf.Clamp(index,0,GamePreferences.ControlCount - 1);
        string[] actions=GamePreferences.ControlActions(scheme),bindings=GamePreferences.ControlBindings(scheme);
        for(int i=0;i<4;i++){helpActions[i].text=actions[i];helpBindings[i].text=bindings[i];}
        helpTip.text=GamePreferences.ControlTip(scheme);
        Highlight(helpTabs,index);
    }
    public void ShowPage(int index)
    {
        CurrentPage=Mathf.Clamp(index,0,3);
        for(int i=0;i<pages.Length;i++)pages[i].SetActive(i==CurrentPage);
        RefreshSelection();
    }
    public void OpenHelp(int returnPage){helpReturnPage=returnPage;ShowHelpControls((int)GamePreferences.Controls);ShowPage(3);}
    private void Heading(Transform page,string title,string subtitle)
    {
        RectTransform sign=Card(title,page,.21f,.845f,.79f,.965f);
        Label(title,sign,.02f,.04f,.98f,.96f,48);
        Label(subtitle,page,.15f,.81f,.85f,.85f,25);
    }
    private Sprite CharacterSprite(int index)
    {
        CatchCharacter c=Resources.Load<CatchCharacter>("Characters/Character"+index);
        return c!=null&&c.idle.Length>0?c.idle[0]:originalPreview;
    }
    private void SelectCharacter(int index){CharacterCatalog.Select(index);RefreshSelection();}
    private void SelectDifficulty(int index){login.difficultyDropdown.value=index;RefreshSelection();}
    private void SelectControls(int index){GamePreferences.SetControls(index);RefreshSelection();}
    private void RefreshSelection()
    {
        Highlight(catcherCards,CharacterCatalog.Selection);Highlight(difficultyCards,login.difficultyDropdown.value);
        Highlight(controlCards,(int)GamePreferences.Controls);
        Highlight(backgroundCards,backgrounds!=null&&backgrounds.MenuDropdown!=null?backgrounds.MenuDropdown.value:0);
        if(summary!=null)summary.text=CharacterCatalog.Name(CharacterCatalog.Selection)+" / "+new[]{"Easy","Medium","Hard"}[Mathf.Clamp(login.difficultyDropdown.value,0,2)]+" / "+(backgrounds!=null&&backgrounds.MenuDropdown!=null?backgrounds.OptionName(backgrounds.MenuDropdown.value):"");
    }
    private void Highlight(List<Image> items,int index){for(int i=0;i<items.Count;i++)items[i].color=i==index?selected:ink;}
    private void ApplyDropdownFont(TMP_Dropdown dropdown)
    {
        if(dropdown.captionText!=null)dropdown.captionText.font=font;
        if(dropdown.itemText!=null)dropdown.itemText.font=font;
    }
    private void Update()
    {
        clock+=Time.unscaledDeltaTime;
        if (CurrentPage == 0)
        {
            for (int i = 0; i < homeCatchers.Length; i++)
            {
                RectTransform catcher = homeCatchers[i];
                if (catcher == null) continue;

                const float cycleSeconds = 2.4f;
                const float hopSeconds = .55f;
                float phase = Mathf.Repeat(clock - i * .65f, cycleSeconds);
                float progress = Mathf.Clamp01(phase / hopSeconds);
                float hop = 4f * progress * (1f - progress);
                catcher.anchoredPosition = Vector2.up * (catcher.rect.height * .14f * hop);
            }
            return;
        }
        if(CurrentPage!=1)return;
        for(int i=0;i<previews.Length;i++)
        {
            CatchCharacter c=Resources.Load<CatchCharacter>("Characters/Character"+i);
            if(c!=null&&c.idle.Length>0)previews[i].sprite=c.idle[(int)(clock*6)%c.idle.Length];
        }
    }
    private void CreateSettings()
    {
        settings=GameUiLayout.Panel("Settings overlay",canvas.transform,Vector2.zero,Vector2.one,new Color(.025f,.09f,.09f,.8f));
        settings.GetComponent<Image>().raycastTarget=true;
        RectTransform card=Card("Settings window",settings,.25f,.12f,.75f,.88f);
        Label("Settings",card,.08f,.79f,.92f,.94f,42);
        volumeText=Label("",card,.21f,.66f,.79f,.78f,30);
        Button("-",card,.08f,.66f,.21f,.78f,()=>ChangeVolume(-.1f),36);
        Button("+",card,.79f,.66f,.92f,.78f,()=>ChangeVolume(.1f),36);
        musicText=Label("",card,.21f,.53f,.79f,.63f,30);
        Button("-",card,.08f,.53f,.21f,.63f,()=>{GamePreferences.SetMusicVolume(GamePreferences.MusicVolume-.1f);RefreshSettings();},36);
        Button("+",card,.79f,.53f,.92f,.63f,()=>{GamePreferences.SetMusicVolume(GamePreferences.MusicVolume+.1f);RefreshSettings();},36);
        effectsText=Label("",card,.21f,.41f,.79f,.51f,30);
        Button("-",card,.08f,.41f,.21f,.51f,()=>{GamePreferences.SetEffectsVolume(GamePreferences.EffectsVolume-.1f);RefreshSettings();},36);
        Button("+",card,.79f,.41f,.92f,.51f,()=>{GamePreferences.SetEffectsVolume(GamePreferences.EffectsVolume+.1f);RefreshSettings();},36);
        hintsText=Label("",card,.08f,.30f,.70f,.39f,27);
        Button("Change",card,.69f,.30f,.92f,.39f,()=>{GamePreferences.SetHints(!GamePreferences.ShowHints);RefreshSettings();},24);
        magnetText=Label("",card,.21f,.19f,.79f,.29f,28);
        Button("-",card,.08f,.19f,.21f,.29f,()=>{GamePreferences.SetManualMagnetPower(GamePreferences.ManualMagnetPower-.1f);RefreshSettings();},36);
        Button("+",card,.79f,.19f,.92f,.29f,()=>{GamePreferences.SetManualMagnetPower(GamePreferences.ManualMagnetPower+.1f);RefreshSettings();},36);
        Label("Keyboard / Camera / no sensor: manual",card,.08f,.115f,.92f,.18f,22);
        Button("Back",card,.31f,.02f,.69f,.105f,()=>settings.gameObject.SetActive(false),30);
        RefreshSettings();settings.gameObject.SetActive(false);
    }
    private void ChangeVolume(float value){GamePreferences.SetVolume(GamePreferences.Volume+value);RefreshSettings();}
    private void RefreshSettings()
    {
        volumeText.text="Master "+Mathf.RoundToInt(GamePreferences.Volume*100)+"%";
        musicText.text="Music "+Mathf.RoundToInt(GamePreferences.MusicVolume*100)+"%";
        effectsText.text="Effects "+Mathf.RoundToInt(GamePreferences.EffectsVolume*100)+"%";
        magnetText.text="Magnet "+Mathf.RoundToInt(GamePreferences.ManualMagnetPower*100)+"%";
        hintsText.text="Control hints: "+(GamePreferences.ShowHints?"ON":"OFF");
    }
    private RectTransform Card(string name,Transform parent,float x,float y,float right,float top)
    {
        RectTransform border=GameUiLayout.Panel(name,parent,new Vector2(x,y),new Vector2(right,top),ink);
        RectTransform inner=GameUiLayout.Panel(name+" paper",border,Vector2.zero,Vector2.one,paper);
        inner.offsetMin=new Vector2(5,5);inner.offsetMax=new Vector2(-5,-5);
        return inner;
    }
    private TMP_Text Label(string value,Transform parent,float x,float y,float r,float t,float size,TextAlignmentOptions alignment=TextAlignmentOptions.Center)
    {
        TMP_Text text=GameUiLayout.Label(value,parent,font,value,new Vector2(x,y),new Vector2(r,t),size,ink);text.alignment=alignment;return text;
    }
    private Button Button(string value,Transform parent,float x,float y,float r,float t,UnityEngine.Events.UnityAction action,float size)
    {
        Button b=GameUiLayout.Button(value,parent,login.startButton,font,value,new Vector2(x,y),new Vector2(r,t),action);
        b.GetComponentInChildren<TMP_Text>().fontSizeMax=size;b.GetComponentInChildren<TMP_Text>().fontSizeMin=size*.8f;return b;
    }
    private static void Move(RectTransform rect,Transform parent,float x,float y,float r,float t)=>GameUiLayout.Place(rect,parent,new Vector2(x,y),new Vector2(r,t));
    private Image Icon(Sprite sprite,Transform parent,float x,float y,float r,float t)
    {
        Image image=GameUiLayout.Panel("Pickup icon",parent,new Vector2(x,y),new Vector2(r,t),Color.white).GetComponent<Image>();
        image.sprite=sprite;image.preserveAspect=true;image.enabled=sprite!=null;
        image.rectTransform.pivot=new Vector2(.5f,0f);
        return image;
    }
}
