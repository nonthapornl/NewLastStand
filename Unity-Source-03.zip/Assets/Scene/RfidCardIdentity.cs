using System;
using System.Collections.Generic;
using System.Text;

// Local player labels, independent of the serial transport and scene objects.
public static class RfidCardIdentity
{
    [Serializable] public sealed class Entry { public string uid; public string playerName; }
    [Serializable] public sealed class Registry { public List<Entry> cards = new List<Entry>(); }

    public static string NormalizeUid(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var result = new StringBuilder(20);
        foreach (char raw in value)
        {
            if (raw == ' ' || raw == ':' || raw == '-') continue;
            char c = char.ToUpperInvariant(raw);
            if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F'))) return null;
            result.Append(c);
            if (result.Length > 20) return null;
        }
        return result.Length == 8 || result.Length == 14 || result.Length == 20 ? result.ToString() : null;
    }

    public static string Find(Registry registry, string uid)
    {
        uid = NormalizeUid(uid);
        if (uid == null || registry == null || registry.cards == null) return null;
        foreach (Entry entry in registry.cards)
            if (entry != null && NormalizeUid(entry.uid) == uid && !string.IsNullOrWhiteSpace(entry.playerName))
                return entry.playerName;
        return null;
    }

    public static bool Bind(Registry registry, string uid, string name)
    {
        uid = NormalizeUid(uid);
        if (registry == null || uid == null || string.IsNullOrWhiteSpace(name)) return false;
        name = name.Trim();
        if (name.Length > 24) return false;
        if (registry.cards == null) registry.cards = new List<Entry>();
        foreach (Entry entry in registry.cards)
            if (entry != null && NormalizeUid(entry.uid) == uid) { entry.playerName = name; return true; }
        registry.cards.Add(new Entry { uid = uid, playerName = name });
        return true;
    }
}
