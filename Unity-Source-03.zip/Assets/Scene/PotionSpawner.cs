using System.Collections;
using UnityEngine;

public sealed class PotionSpawner : MonoBehaviour
{
    private Camera gameplayCamera;
    private float playerWidth = 100f;

    private void Start()
    {
        gameplayCamera = Camera.main;
        PlayerMovement player = FindFirstObjectByType<PlayerMovement>();
        Collider2D collider = player != null ? player.GetComponent<Collider2D>() : null;
        if (collider != null) playerWidth = Mathf.Max(0.1f, collider.bounds.size.x);
        StartCoroutine(SpawnPotions());
    }

    private IEnumerator SpawnPotions()
    {
        yield return new WaitForSeconds(Random.Range(3f, 5f));
        while (enabled && GameData.RoundActive)
        {
            Spawn();
            yield return new WaitForSeconds(Random.Range(10f, 15f));
        }
    }

    private void Spawn()
    {
        if (gameplayCamera == null) gameplayCamera = Camera.main;
        if (gameplayCamera == null) return;
        PotionKind kind = GameData.lives < GameData.StartingLives && Random.value < 0.4f
            ? PotionKind.Health : (PotionKind)Random.Range(1, 5);
        float poisonChance = GameData.selectedLevel == FruitSpeedLevel.Easy ? .18f
            : GameData.selectedLevel == FruitSpeedLevel.Hard ? .33f : .25f;
        // Give players a short opening before harmful pickups join the pool.
        if (Time.timeSinceLevelLoad >= 15f && Random.value < poisonChance)
            kind = (PotionKind)Random.Range((int)PotionKind.Shrink, (int)PotionKind.Confuse + 1);
        Sprite[] frames = PotionSpriteLibrary.Frames(kind);
        if (frames.Length == 0) return;
        Vector3 position = gameplayCamera.ViewportToWorldPoint(new Vector3(Random.Range(0.15f, 0.85f), 1.1f, 10f));
        position.z = 0f;
        var potion = new GameObject(kind + " Potion");
        potion.transform.position = position;
        potion.transform.localScale = Vector3.one * playerWidth * 0.52f;
        SpriteRenderer renderer = potion.AddComponent<SpriteRenderer>();
        renderer.sprite = frames[0];
        PlayerMovement player = FindFirstObjectByType<PlayerMovement>();
        SpriteRenderer playerRenderer = player != null ? player.GetComponent<SpriteRenderer>() : null;
        if (playerRenderer != null) renderer.sortingLayerID = playerRenderer.sortingLayerID;
        renderer.sortingOrder = 6;
        Rigidbody2D body = potion.AddComponent<Rigidbody2D>();
        body.gravityScale = DifficultyProfile.For(GameData.selectedLevel).FruitGravity * 0.85f * DifficultyProfile.FallTempo;
        body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        body.freezeRotation = true;
        potion.AddComponent<PotionFallModifier>();
        CapsuleCollider2D shape = potion.AddComponent<CapsuleCollider2D>();
        shape.isTrigger = true;
        shape.size = new Vector2(0.45f, 0.9f);
        potion.AddComponent<PotionPickup>().Initialize(kind, renderer, frames);
        Debug.Log("[Potions] Spawned " + kind + " at " + position + ", sprite=" + (renderer.sprite != null), potion);
        StartCoroutine(Watch(potion));
    }

    private IEnumerator Watch(GameObject potion)
    {
        while (potion != null)
        {
            if (!GameData.RoundActive || (gameplayCamera != null && gameplayCamera.WorldToViewportPoint(potion.transform.position).y < -0.15f))
            {
                potion.GetComponent<PotionPickup>().Discard();
                yield break;
            }
            yield return null;
        }
    }
}
