using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections.Generic;

public class PauseMenu : MonoBehaviour
{
    private const string GameSceneName = "Play scene";
    private const string ContinueMenuSceneName = "restartscene";
    private static Camera gameplayCamera;
    private static EventSystem gameplayEventSystem;
    private static readonly List<Canvas> hiddenGameplayCanvases = new List<Canvas>();
    private static readonly List<AudioListener> mutedGameplayListeners = new List<AudioListener>();

    private void Awake()
    {
        if (gameObject.scene.name != GameSceneName)
            return;

        gameplayCamera = Camera.main;
        gameplayEventSystem = EventSystem.current;

        Button pauseButton = GetComponent<Button>();
        if (pauseButton != null)
            pauseButton.onClick.AddListener(OpenContinueMenu);
    }

    private void OpenContinueMenu()
    {
        if (SceneManager.GetSceneByName(ContinueMenuSceneName).isLoaded)
            return;

        Time.timeScale = 0f;
        hiddenGameplayCanvases.Clear();
        mutedGameplayListeners.Clear();
        foreach (AudioListener listener in FindObjectsByType<AudioListener>(FindObjectsSortMode.None))
        {
            if (listener.gameObject.scene.name != GameSceneName || !listener.enabled) continue;
            mutedGameplayListeners.Add(listener);
            listener.enabled = false;
        }
        foreach (Canvas canvas in FindObjectsByType<Canvas>(FindObjectsSortMode.None))
        {
            if (canvas.gameObject.scene.name != GameSceneName || !canvas.enabled) continue;
            hiddenGameplayCanvases.Add(canvas);
            canvas.enabled = false;
        }
        if (gameplayCamera != null)
            gameplayCamera.enabled = false;
        if (gameplayEventSystem != null)
            gameplayEventSystem.enabled = false;

        SceneManager.LoadScene(ContinueMenuSceneName, LoadSceneMode.Additive);
    }

    public static void ResumeGame()
    {
        Scene pauseScene = SceneManager.GetSceneByName(ContinueMenuSceneName);
        if (pauseScene.isLoaded)
        {
            AsyncOperation unloadOperation = SceneManager.UnloadSceneAsync(pauseScene);
            if (unloadOperation != null)
            {
                unloadOperation.completed += _ => RestoreGameplay();
                return;
            }
        }

        RestoreGameplay();
    }

    private static void RestoreGameplay()
    {
        foreach (Canvas canvas in hiddenGameplayCanvases)
            if (canvas != null) canvas.enabled = true;
        hiddenGameplayCanvases.Clear();
        foreach (AudioListener listener in mutedGameplayListeners)
            if (listener != null) listener.enabled = true;
        mutedGameplayListeners.Clear();
        if (gameplayCamera != null)
            gameplayCamera.enabled = true;
        if (gameplayEventSystem != null)
            gameplayEventSystem.enabled = true;
        Time.timeScale = 1f;
    }

    public void QuitToLogin()
    {
        Time.timeScale = 1f;
        GameData.ResetForNewPlayer();
        SceneManager.LoadScene("LogINScene");
    }
}
