using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Restartscene : MonoBehaviour
{
    private const string GameSceneName = "Play scene";
    [SerializeField] private Button continueButton;
    [SerializeField] private Button restartButton;
    [SerializeField] private Button quitButton;
    private GameObject mainPanel, settingsPanel, helpPanel;
    private TMP_Text volumeText, musicText, effectsText, hintsText, magnetText;
    private Button settingsButton;
    private TMP_FontAsset font;

    private void Awake()
    {
        Canvas canvas = GetComponentInParent<Canvas>();
        if (canvas == null) canvas = GetComponent<Canvas>();
        if (canvas == null) return;
        GameUiLayout.ScaleCanvas(canvas);
        canvas.sortingOrder = 100;
        foreach (Button button in canvas.GetComponentsInChildren<Button>(true))
        {
            if (button.name == "continueButton") continueButton = button;
            if (button.name == "restartButton") restartButton = button;
            if (button.name == "quitButton") quitButton = button;
            if (button.name == "playButton") settingsButton = button;
        }
        TMP_Text templateText = continueButton != null ? continueButton.GetComponentInChildren<TMP_Text>(true) : null;
        font = templateText != null ? templateText.font : TMP_Settings.defaultFontAsset;
        foreach (TMP_Text label in canvas.GetComponentsInChildren<TMP_Text>(true))
            if (label.GetComponentInParent<Button>() == null) label.gameObject.SetActive(false);
        GameUiLayout.Panel("PauseShade", canvas.transform, Vector2.zero, Vector2.one, new Color(0f, 0f, 0f, 0.55f));
        RectTransform menu = GameUiLayout.Panel("PauseCard", canvas.transform, new Vector2(0.32f, 0.12f), new Vector2(0.68f, 0.88f), new Color(0.035f, 0.09f, 0.12f, 0.97f));
        mainPanel = menu.gameObject;
        GameUiLayout.Label("PauseTitle", menu, font, "PAUSED", new Vector2(0.06f, 0.83f), new Vector2(0.94f, 0.97f), 52f, new Color(1f, 0.84f, 0.52f));
        PlaceButton(continueButton, menu, "Continue", 0.65f, ContinueGame);
        PlaceButton(restartButton, menu, "Restart", 0.48f, RestartGame);
        PlaceButton(settingsButton, menu, "Settings", 0.31f, () => ShowSettings(true));
        PlaceButton(quitButton, menu, "Quit", 0.14f, ReturnToLogin);
        CreateSettings(canvas.transform);
        CreateHelp(canvas.transform);
    }

    private void PlaceButton(Button button, Transform parent, string title, float bottom, UnityEngine.Events.UnityAction action)
    {
        if (button == null) return;
        GameUiLayout.Place(button.GetComponent<RectTransform>(), parent, new Vector2(0.10f, bottom), new Vector2(0.90f, bottom + 0.13f));
        button.onClick = new Button.ButtonClickedEvent();
        button.onClick.AddListener(action);
        TMP_Text label = button.GetComponentInChildren<TMP_Text>(true);
        if (label != null)
        {
            label.text = title;
            GameUiLayout.Style(label, button.transform, new Vector2(0.04f, 0.12f), new Vector2(0.96f, 0.88f), 36f, Color.white);
        }
    }

    private void CreateSettings(Transform parent)
    {
        RectTransform card = GameUiLayout.Panel("SettingsCard", parent, new Vector2(0.26f, 0.15f), new Vector2(0.74f, 0.85f), new Color(0.035f, 0.09f, 0.12f, 0.98f));
        settingsPanel = card.gameObject;
        GameUiLayout.Label("SettingsTitle", card, font, "SETTINGS", new Vector2(0.06f, 0.83f), new Vector2(0.94f, 0.97f), 48f, new Color(1f, 0.84f, 0.52f));
        volumeText = SoundRow(card,"Master",.69f,()=>ChangeVolume(-.1f),()=>ChangeVolume(.1f));
        musicText = SoundRow(card,"Music",.55f,()=>{GamePreferences.SetMusicVolume(GamePreferences.MusicVolume-.1f);UpdateSettings();},()=>{GamePreferences.SetMusicVolume(GamePreferences.MusicVolume+.1f);UpdateSettings();});
        effectsText = SoundRow(card,"Effects",.41f,()=>{GamePreferences.SetEffectsVolume(GamePreferences.EffectsVolume-.1f);UpdateSettings();},()=>{GamePreferences.SetEffectsVolume(GamePreferences.EffectsVolume+.1f);UpdateSettings();});
        magnetText = SoundRow(card,"Magnet",.27f,()=>{GamePreferences.SetManualMagnetPower(GamePreferences.ManualMagnetPower-.1f);UpdateSettings();},()=>{GamePreferences.SetManualMagnetPower(GamePreferences.ManualMagnetPower+.1f);UpdateSettings();});
        Button hints = GameUiLayout.Button("HintsToggle", card, continueButton, font, "", new Vector2(0.12f, 0.19f), new Vector2(0.88f, 0.26f), () => { GamePreferences.SetHints(!GamePreferences.ShowHints); UpdateSettings(); });
        hintsText = hints.GetComponentInChildren<TMP_Text>();
        GameUiLayout.Button("ControlsHelp", card, continueButton, font, "How to Play", new Vector2(0.12f, 0.105f), new Vector2(0.88f, 0.18f), () => { settingsPanel.SetActive(false); helpPanel.SetActive(true); });
        GameUiLayout.Button("SettingsBack", card, continueButton, font, "Back", new Vector2(0.28f, 0.02f), new Vector2(0.72f, 0.10f), () => ShowSettings(false));
        UpdateSettings();
        settingsPanel.SetActive(false);
    }

    private void CreateHelp(Transform parent)
    {
        RectTransform card = GameUiLayout.Panel("PauseControlsHelp", parent, new Vector2(0.10f, 0.12f), new Vector2(0.90f, 0.88f), new Color(0.035f, 0.09f, 0.12f, 0.98f));
        helpPanel = card.gameObject;
        GameUiLayout.Label("PauseHelpTitle", card, font, GamePreferences.ControlName + " + MAGNET", new Vector2(0.05f, 0.85f), new Vector2(0.95f, 0.97f), 42f, new Color(1f, 0.84f, 0.52f));
        string[] actions = GamePreferences.ControlActions(GamePreferences.Controls);
        string[] bindings = GamePreferences.ControlBindings(GamePreferences.Controls);
        for(int i=0;i<4;i++)
        {
            float y=.68f-i*.105f;
            RectTransform row=GameUiLayout.Panel("Pause control row "+i,card,new Vector2(.05f,y),new Vector2(.51f,y+.09f),new Color(.10f,.20f,.22f));
            TMP_Text action=GameUiLayout.Label("Action",row,font,actions[i],new Vector2(.02f,.03f),new Vector2(.27f,.97f),30f,Color.white);
            action.alignment=TextAlignmentOptions.MidlineLeft;
            TMP_Text binding=GameUiLayout.Label("Binding",row,font,bindings[i],new Vector2(.28f,.03f),new Vector2(.98f,.97f),27f,Color.white);
            binding.alignment=TextAlignmentOptions.MidlineLeft;
        }
        TMP_Text tip=GameUiLayout.Label("Control tip",card,font,GamePreferences.ControlTip(GamePreferences.Controls),new Vector2(.05f,.23f),new Vector2(.51f,.36f),25f,Color.white);
        tip.alignment=TextAlignmentOptions.MidlineLeft;
        TMP_Text powerups=GameUiLayout.Label("Potion guide",card,font,
            "POTION POWER-UPS\n\nHeal: +1 heart (max 3)\nShield: block 1 bomb / 8s\nScore x2: double points / 10s\nSpeed: move faster / 8s\nSlow: slower drops / 6s\n\nSame colour refreshes its timer.\n\nPOISONS (RED !)\nShrink: size 60% / 6s\nSluggish: move 60% / 6s\nConfuse: reverse L/R / 5s",
            new Vector2(.55f,.24f),new Vector2(.95f,.79f),27f,Color.white);
        powerups.alignment=TextAlignmentOptions.MidlineLeft;
        TMP_Text magnet=GameUiLayout.Label("Magnet guide",card,font,
            GamePreferences.MagnetHelp,
            new Vector2(.05f,.15f),new Vector2(.95f,.25f),23f,new Color(1f,.84f,.52f));
        GameUiLayout.Button("HelpBack", card, continueButton, font, "Back", new Vector2(0.34f, 0.04f), new Vector2(0.66f, 0.14f), () => { helpPanel.SetActive(false); settingsPanel.SetActive(true); });
        helpPanel.SetActive(false);
    }

    private void ChangeVolume(float step) { GamePreferences.SetVolume(GamePreferences.Volume + step); UpdateSettings(); }
    private TMP_Text SoundRow(Transform parent,string name,float y,UnityEngine.Events.UnityAction down,UnityEngine.Events.UnityAction up)
    {
        TMP_Text text=GameUiLayout.Label(name+"Volume",parent,font,"",new Vector2(.23f,y),new Vector2(.77f,y+.12f),30f,Color.white);
        GameUiLayout.Button(name+"Down",parent,continueButton,font,"-",new Vector2(.08f,y),new Vector2(.22f,y+.12f),down);
        GameUiLayout.Button(name+"Up",parent,continueButton,font,"+",new Vector2(.78f,y),new Vector2(.92f,y+.12f),up);
        return text;
    }
    private void UpdateSettings()
    {
        if (volumeText != null) volumeText.text = "Master "+Mathf.RoundToInt(GamePreferences.Volume * 100f) + "%";
        if (musicText != null) musicText.text = "Music "+Mathf.RoundToInt(GamePreferences.MusicVolume * 100f) + "%";
        if (effectsText != null) effectsText.text = "Effects "+Mathf.RoundToInt(GamePreferences.EffectsVolume * 100f) + "%";
        if (magnetText != null) magnetText.text = "Magnet "+Mathf.RoundToInt(GamePreferences.ManualMagnetPower*100f)+"%";
        if (hintsText != null) hintsText.text = "HINTS " + (GamePreferences.ShowHints ? "ON" : "OFF");
    }
    private void ShowSettings(bool visible) { mainPanel.SetActive(!visible); settingsPanel.SetActive(visible); }
    private void ContinueGame() => PauseMenu.ResumeGame();
    private void RestartGame()
    {
        GameSessionManager.StopCurrentRound();
        Time.timeScale = 1f;
        GameData.score = 0;
        GameData.timeRemaining = GameData.MatchDurationSeconds;
        SceneManager.LoadScene(GameSceneName);
    }
    private void ReturnToLogin()
    {
        GameSessionManager.StopCurrentRound();
        Time.timeScale = 1f;
        GameData.ResetForNewPlayer();
        SceneManager.LoadScene("LogINScene");
    }
}
