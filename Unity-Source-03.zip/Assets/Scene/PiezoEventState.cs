// Consume the shared serial event counter once, even if an event is repeated.
public sealed class PiezoEventState
{
    private int lastSequence = -1;
    private float receivedAt;
    private bool valid;
    public bool Pressed { get; private set; }
    public int Peak { get; private set; }
    public void BeginFrame() { Pressed = false; }
    public bool IsLive(float now) => valid && now - receivedAt <= .75f;
    public void Record(int sequence, int hit, int ok, int peak, float now)
    {
        if (sequence < 0 || hit < 0 || hit > 1 || ok < 0 || ok > 1 || peak < 0 || peak > 4095) return;
        receivedAt = now; valid = ok == 1; Peak = peak;
        // A counter change recovers a lost hit line; the first heartbeat only
        // establishes the baseline and does not replay a tap from an old round.
        if (valid && ((lastSequence < 0 && hit == 1) || (lastSequence >= 0 && sequence > lastSequence)))
            Pressed = true;
        lastSequence = sequence;
    }
    public void Reset() { lastSequence = -1; valid = Pressed = false; Peak = 0; receivedAt = 0f; }
}
