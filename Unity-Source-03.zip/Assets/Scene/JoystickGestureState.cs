// One serial joystick packet can request a one-frame jump or dash. Keeping
// the stick/button held never repeats the action after a landing/cooldown.
public sealed class JoystickGestureState
{
    public int Horizontal { get; private set; }
    public int Vertical { get; private set; }
    public bool ButtonHeld { get; private set; }
    public bool JumpPressed { get; private set; }
    public int DashDirection { get; private set; }
    public bool Valid { get; private set; }
    private float receivedAt;

    public void BeginFrame() { JumpPressed = false; DashDirection = 0; }

    public void Record(int x, int y, int button, float now)
    {
        if (x < -1 || x > 1 || y < -1 || y > 1 || button < 0 || button > 1) return;
        bool pressed = button == 1;
        JumpPressed |= y == 1 && Vertical != 1;
        if (pressed && x != 0 && (!ButtonHeld || x != Horizontal)) DashDirection = x;
        Horizontal = x; Vertical = y; ButtonHeld = pressed;
        receivedAt = now; Valid = true;
    }

    public void Expire(float now, float timeout)
    {
        if (Valid && now - receivedAt > timeout) Reset();
    }

    public void Reset()
    {
        Horizontal = Vertical = DashDirection = 0;
        ButtonHeld = JumpPressed = Valid = false;
    }
}
