public enum PotionKind { Health, Shield, DoubleScore, Haste, SlowFall, Shrink, Sluggish, Confuse }

// Time is supplied by Unity's scaled game clock, so pausing freezes the effect.
public sealed class PotionEffectState
{
    public const float ShieldDuration = 8f;
    private float shieldUntil;
    private float scoreUntil, hasteUntil, slowUntil;
    private float shrinkUntil, sluggishUntil, confuseUntil;
    public static bool IsPoison(PotionKind kind) => kind == PotionKind.Shrink || kind == PotionKind.Sluggish || kind == PotionKind.Confuse;
    public float ShrinkRemaining(float now) => shrinkUntil > now ? shrinkUntil - now : 0f;
    public float SluggishRemaining(float now) => sluggishUntil > now ? sluggishUntil - now : 0f;
    public float ConfuseRemaining(float now) => confuseUntil > now ? confuseUntil - now : 0f;
    public float SizeFactor(float now) => ShrinkRemaining(now) > 0f ? .6f : 1f;
    public float DirectionFactor(float now) => ConfuseRemaining(now) > 0f ? -1f : 1f;
    public float ScoreRemaining(float now) => scoreUntil > now ? scoreUntil - now : 0f;
    public float HasteRemaining(float now) => hasteUntil > now ? hasteUntil - now : 0f;
    public float SlowRemaining(float now) => slowUntil > now ? slowUntil - now : 0f;
    public float ScoreFactor(float now) => ScoreRemaining(now) > 0f ? 2f : 1f;
    public float MoveFactor(float now) => (HasteRemaining(now) > 0f ? 1.3f : 1f) * (SluggishRemaining(now) > 0f ? .6f : 1f);
    public float FallFactor(float now) => SlowRemaining(now) > 0f ? 0.55f : 1f;

    public float ShieldRemaining(float now) => shieldUntil > now ? shieldUntil - now : 0f;

    public bool TryUse(PotionKind kind, int lives, int maxLives, float now, out int newLives)
    {
        newLives = lives;
        if (lives <= 0 || maxLives <= 0 || float.IsNaN(now) || float.IsInfinity(now)) return false;
        if (kind == PotionKind.Health)
        {
            if (lives >= maxLives) return false;
            newLives = lives + 1;
            return true;
        }
        switch (kind)
        {
            case PotionKind.Shield: shieldUntil = now + ShieldDuration; break;
            case PotionKind.DoubleScore: scoreUntil = now + 10f; break;
            case PotionKind.Haste: hasteUntil = now + 8f; break;
            case PotionKind.SlowFall: slowUntil = now + 6f; break;
            case PotionKind.Shrink: shrinkUntil = now + 6f; break;
            case PotionKind.Sluggish: sluggishUntil = now + 6f; break;
            case PotionKind.Confuse: confuseUntil = now + 5f; break;
            default: return false;
        }
        return true;
    }

    public bool TryBlock(float now)
    {
        if (float.IsNaN(now) || float.IsInfinity(now) || ShieldRemaining(now) <= 0f) return false;
        shieldUntil = 0f;
        return true;
    }

    public void Reset() => shieldUntil = scoreUntil = hasteUntil = slowUntil = shrinkUntil = sluggishUntil = confuseUntil = 0f;
}
