using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(Collider2D))]
public sealed class PotionPickup : MonoBehaviour
{
    private PotionKind kind;
    private SpriteRenderer visual;
    private Sprite[] frames;
    private bool resolved;
    private float animationTime;

    public void Initialize(PotionKind value, SpriteRenderer renderer, Sprite[] sprites)
    {
        kind = value; visual = renderer; frames = sprites;
        if (PotionEffectState.IsPoison(kind) && visual != null)
        {
            var badge = new GameObject("Poison warning !");
            badge.transform.SetParent(transform, false);
            badge.transform.localPosition = new Vector3(.28f,.42f,0f);
            TextMesh label = badge.AddComponent<TextMesh>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.text = "!"; label.fontSize = 48; label.characterSize = .4f;
            label.fontStyle = FontStyle.Bold; label.anchor = TextAnchor.MiddleCenter;
            label.color = new Color(1f,.15f,.2f);
            MeshRenderer marker = badge.GetComponent<MeshRenderer>();
            marker.sharedMaterial = label.font.material;
            marker.sortingLayerID = visual.sortingLayerID; marker.sortingOrder = visual.sortingOrder + 1;
        }
    }

    private void Update()
    {
        if (visual == null || frames == null || frames.Length == 0) return;
        animationTime += Time.deltaTime;
        visual.sprite = frames[(int)(animationTime * 10f) % frames.Length];
    }

    private void OnTriggerEnter2D(Collider2D other) => Contact(other.gameObject);
    private void OnCollisionEnter2D(Collision2D other) => Contact(other.gameObject);

    private void Contact(GameObject other)
    {
        if (resolved || other == null) return;
        if (other.CompareTag("Player"))
        {
            RepelledPickup repelled = GetComponent<RepelledPickup>();
            if (repelled != null && repelled.BlocksPlayerContact) return;
            resolved = true;
            GameSessionManager.TryCollectPotion(kind);
            Destroy(gameObject);
        }
        else if (other.CompareTag("Ground")) Discard();
    }

    public void Discard()
    {
        if (resolved) return;
        resolved = true;
        // Potions are optional: dropping one never changes fruit accuracy/combo.
        Destroy(gameObject);
    }
}
