using UnityEngine;

// A short, bounded hop replaces an unbounded outward impulse. MovePosition
// controls the hop only; normal gravity and potion fall effects resume after it.
[RequireComponent(typeof(Rigidbody2D))]
public sealed class PickupScatterMotion : MonoBehaviour
{
    private Rigidbody2D body;
    private Vector2 start, destination;
    private float began, duration, height, fallSpeed;
    private float entryDownSpeed;
    private bool active;

    public void Begin(float horizontalDistance, float playerWidth, float seconds, float heightWidths)
    {
        body = GetComponent<Rigidbody2D>();
        start = body.position;
        destination = start + new Vector2(horizontalDistance, -playerWidth * .12f);
        // Keep the landing path inside the visible play area at the edges.
        Camera camera = Camera.main;
        Collider2D collider = GetComponent<Collider2D>();
        if (camera != null && camera.orthographic)
        {
            float half = collider != null ? collider.bounds.extents.x : playerWidth * .1f;
            float left = camera.transform.position.x - camera.orthographicSize * camera.aspect + half;
            float right = camera.transform.position.x + camera.orthographicSize * camera.aspect - half;
            if (left < right) destination.x = Mathf.Clamp(destination.x, left, right);
        }
        began = Time.time; duration = Mathf.Max(.3f, seconds);
        height = playerWidth * Mathf.Max(0f, heightWidths);
        fallSpeed = playerWidth * .8f;
        entryDownSpeed = Mathf.Min(0f, body.linearVelocity.y);
        active = enabled = true;
        // This is the first tangent; subsequent physics steps follow the arc.
        body.linearVelocity = new Vector2((destination.x - start.x) / duration,
            (4f * height + destination.y - start.y) / duration);
        body.WakeUp();
    }

    private void FixedUpdate()
    {
        if (!active || body == null || !body.simulated) return;
        float t = Mathf.Clamp01((Time.time - began + Time.fixedDeltaTime) / duration);
        if (t >= 1f)
        {
            // The final correction is at most the last physics step of the hop.
            body.position = destination;
            body.linearVelocity = new Vector2((destination.x - start.x) / duration * .1f,
                Mathf.Min(entryDownSpeed, -fallSpeed));
            active = false; enabled = false;
            return;
        }
        Vector2 point = Vector2.Lerp(start, destination, t);
        point.y += 4f * height * t * (1f - t);
        body.MovePosition(point);
    }
}
