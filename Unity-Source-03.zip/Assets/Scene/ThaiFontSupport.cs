using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Bundled font data works in builds and on other computers without OS fonts.
public static class ThaiFontSupport
{
    private static Font thaiFont;
    private static TMP_FontAsset thaiTmpFont;

    public static Font Font
    {
        get
        {
            if (thaiFont == null)
                thaiFont = Resources.Load<Font>("Fonts/Sarabun-Regular");
            return thaiFont;
        }
    }

    public static bool ContainsThai(string text)
    {
        if (string.IsNullOrEmpty(text)) return false;
        foreach (char character in text)
            if (character >= '\u0E00' && character <= '\u0E7F') return true;
        return false;
    }

    public static TMP_FontAsset TmpFont
    {
        get
        {
            if (thaiTmpFont == null && Font != null)
            {
                thaiTmpFont = TMP_FontAsset.CreateFontAsset(Font);
                if (thaiTmpFont != null) thaiTmpFont.name = "Sarabun runtime fallback";
            }
            return thaiTmpFont;
        }
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void InstallFallback()
    {
        if (Font == null)
        {
            Debug.LogError("Missing bundled Thai font: Resources/Fonts/Sarabun-Regular.ttf");
            return;
        }

        if (TmpFont == null) return;

        // Preserve BoldPixels for existing Latin text; use Thai glyphs as needed
        // in the login input, placeholders and result screen's TMP labels.
        if (TMP_Settings.fallbackFontAssets == null)
            TMP_Settings.fallbackFontAssets = new List<TMP_FontAsset>();
        if (!TMP_Settings.fallbackFontAssets.Contains(thaiTmpFont))
            TMP_Settings.fallbackFontAssets.Add(thaiTmpFont);
    }
}
