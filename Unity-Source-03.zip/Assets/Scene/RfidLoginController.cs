using System;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// The login scene owns COM only until Start Game. Gameplay then opens the same
// port through MpuHandInput; no second simultaneous serial reader is created.
public sealed class RfidLoginController : MonoBehaviour
{
    public string portName = "COM9";
    private LoginManager login;
    private TMP_Text status;
    private TMP_Text homeStatus;
    private Button saveButton;
    private ESP32WindowsSerial port;
    private RfidCardIdentity.Registry registry = new RfidCardIdentity.Registry();
    private string pending = "", scannedUid;
    private float retryAt;
    private bool leaving;
    private string currentStatus = "RFID: connecting... (name can also be typed)";
    private string RegistryPath => Path.Combine(Application.persistentDataPath, "rfid-players.json");
    [Serializable] private sealed class Packet { public string t; public string uid; public int ok; }

    public void Initialize(LoginManager manager)
    {
        login = manager;
        try
        {
            if (File.Exists(RegistryPath))
                registry = JsonUtility.FromJson<RfidCardIdentity.Registry>(File.ReadAllText(RegistryPath)) ?? registry;
        }
        catch (Exception e) { Debug.LogWarning("RFID names could not be loaded: " + e.Message, this); }
    }

    public void AttachUi(TMP_Text label, Button save, TMP_Text home)
    {
        status = label; saveButton = save; homeStatus = home;
        saveButton.onClick.AddListener(SaveCard);
        RefreshUi();
    }

    private void Update()
    {
        if (login == null || leaving) return;
        if (port == null)
        {
            if (Time.realtimeSinceStartup < retryAt) return;
            retryAt = Time.realtimeSinceStartup + 3f;
            try
            {
                port = new ESP32WindowsSerial(portName, 115200, false);
                port.Open();
                SetStatus("RFID: tap your card, or type a name");
            }
            catch { ClosePort(); SetStatus("RFID offline: type a name to play"); }
            return;
        }
        try
        {
            pending += port.ReadExisting();
            // Other sensors share this stream. Drain complete lines every frame.
            if (pending.Length > 32768) pending = "";
            int end;
            while ((end = pending.IndexOf('\n')) >= 0)
            {
                string line = pending.Substring(0, end).Trim();
                pending = pending.Substring(end + 1);
                if (line.Length == 0 || line[0] != '{') continue;
                Packet packet;
                try { packet = JsonUtility.FromJson<Packet>(line); }
                catch (ArgumentException) { continue; }
                if (packet == null) continue;
                if (packet.t == "id") ReceiveCard(packet.uid);
                else if (packet.t == "rfid") SetStatus(packet.ok == 1
                    ? "RFID ready: tap your card" : "RFID reader not found: check wiring");
            }
        }
        catch (Exception) { ClosePort(); SetStatus("RFID disconnected: type a name to play"); }
        RefreshUi();
    }

    public void ReceiveCard(string uid)
    {
        if (leaving || login == null) return;
        uid = RfidCardIdentity.NormalizeUid(uid);
        if (uid == null) return;
        scannedUid = uid;
        string name = RfidCardIdentity.Find(registry, uid);
        login.usernameInput.text = name ?? "";
        SetStatus(name == null ? "New card: type a name, then Save card" : "Card recognized: name filled in");
    }

    private void SaveCard()
    {
        if (login == null || scannedUid == null || string.IsNullOrWhiteSpace(login.usernameInput.text)) return;
        // Commit to disk before replacing the in-memory registry.
        var next = JsonUtility.FromJson<RfidCardIdentity.Registry>(JsonUtility.ToJson(registry));
        if (!RfidCardIdentity.Bind(next, scannedUid, login.usernameInput.text)) return;
        try
        {
            Directory.CreateDirectory(Application.persistentDataPath);
            string temporary = RegistryPath + ".tmp";
            File.WriteAllText(temporary, JsonUtility.ToJson(next, true));
            if (File.Exists(RegistryPath)) File.Replace(temporary, RegistryPath, RegistryPath + ".bak");
            else File.Move(temporary, RegistryPath);
            registry = next;
            login.usernameInput.text = RfidCardIdentity.Find(registry, scannedUid);
            SetStatus("Card saved: tap it next time to fill your name");
        }
        catch (Exception e) { SetStatus("Could not save card. You can still play."); Debug.LogWarning(e.Message, this); }
    }

    private void SetStatus(string value) { currentStatus = value; RefreshUi(); }
    private void RefreshUi()
    {
        if (status != null) status.text = currentStatus;
        if (homeStatus != null) homeStatus.text = currentStatus;
        if (saveButton != null) saveButton.interactable = scannedUid != null && login != null
            && !string.IsNullOrWhiteSpace(login.usernameInput.text);
    }
    public void ReleaseForGame() { leaving = true; ClosePort(); }
    private void ClosePort() { if (port != null) port.Dispose(); port = null; pending = ""; }
    private void OnDisable() { ClosePort(); }
    private void OnDestroy() { ClosePort(); }
    private void OnApplicationQuit() { ClosePort(); }
}
