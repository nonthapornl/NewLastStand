using System;
using System.Globalization;
using System.Text;
using UnityEngine;

[DefaultExecutionOrder(-80)]
public class MpuHandInput : MonoBehaviour
{
    public string portName = "COM12";
    public int baudRate = 115200;
    [Tooltip("Enable for UNO R4 native USB CDC; leave disabled for ESP32-S3 USB-to-UART.")]
    public bool dtrEnable = false;
    public float disconnectTimeout = 0.35f;
    [Tooltip("When MPU has live, calibrated data it owns walking/dashing. Keyboard jump still works.")]
    public bool takeMovementControlWhenConnected = true;
    public TextAsset calibrationProfile;
    [Tooltip("Restore the saved accel/map/trim in board RAM if different. Never writes EEPROM.")]
    public bool restoreSavedCalibrationWhenDifferent = true;
    [Tooltip("Inclusive pitch range that releases walking. Outside it, this hand requests its side.")]
    public float pitchNeutralMin = -35f, pitchNeutralMax = 45f;
    public float waveSpeed = 30f, waveTravel = 4f, waveWindow = 0.65f, waveCooldown = 0.9f;
    [Tooltip("Show detailed serial diagnostics. The magnet supplies the compact gameplay status bar.")]
    public bool showStatus = false;
    public bool invertJoystickX = false, invertJoystickY = false;

    public int Horizontal { get; private set; }
    public int DashDirection { get; private set; }
    public bool JumpPressed { get; private set; }
    private bool bothHandsRaised;
    public bool Connected { get; private set; }
    public bool HasDirectionalInput { get; private set; }
    public bool StickConnected => stick.Valid;
    public int StickHorizontal => stick.Horizontal;
    public bool StickJumpPressed => stick.JumpPressed;
    public int StickDashDirection => stick.DashDirection;
    private readonly JoystickGestureState stick = new JoystickGestureState();
    private readonly PiezoEventState piezo = new PiezoEventState();
    public bool PiezoPressed => piezo.Pressed;
    public bool PiezoLive => piezo.IsLive(Time.realtimeSinceStartup);
    [Serializable] private class PiezoPacket { public int seq, hit, ok, peak; }
    [Serializable] private class StickPacket { public int[] v; }
    public bool LeftHandRaised => hands[0].Valid && hands[0].MovementActive;
    public bool RightHandRaised => hands[1].Valid && hands[1].MovementActive;
    public bool LeftHandValid => hands[0].Valid;
    public bool RightHandValid => hands[1].Valid;
    public float UltrasonicCm { get; private set; }
    public int UltrasonicPacketCount => ultrasonicPackets;
    public bool UltrasonicValid => ultrasonicOk && Time.realtimeSinceStartup - ultrasonicAt <= 0.5f;
    private bool ultrasonicOk;
    private float ultrasonicAt;
    private int ultrasonicPackets;
    [Serializable] private class DistancePacket { public float cm; public int ok; }
    public string CalibrationStatus { get; private set; } = "Waiting for board settings";
    private ESP32WindowsSerial port;
    private string pending = "";
    private float probeAt, openedAt;
    private int receivedBytes, settingsPackets, dataPackets, gyroPackets;
    private bool warnedNoData;
    private int completeLines, unknownLines, seenAnglePackets, debugChunks;
    private int malformedPackets;
    private string lastWireLine = "No complete line yet";
    private float debugAt;
    private static readonly char[] LineEndings = { '\r', '\n' };
    private bool configured, calibrationMatches, restoreAttempted;
    private readonly MpuGestureState[] hands = { new MpuGestureState(), new MpuGestureState() };
    private SavedProfile saved;

    [Serializable] private class SavedProfile { public SavedHand[] imus; }
    [Serializable] private class SavedHand
    {
        public string addr;
        public float[] gyroOffset, accelBias, accelScale;
        public float accelLsbPerG;
        public int[] axisMap;
        public Trim levelTrim;
    }
    [Serializable] private class Trim { public float roll, pitch; }
    [Serializable] private class SettingsPacket { public float alsb; public BoardHand[] imu; }
    [Serializable] private class BoardHand
    {
        public int addr;
        public float[] go, ab, @as;
        public int[] map;
        public float rz, pz;
    }

    private void OnEnable()
    {
        Disconnect();
        configured = calibrationMatches = restoreAttempted = false;
        receivedBytes = settingsPackets = dataPackets = gyroPackets = 0;
        ultrasonicPackets = 0;
        warnedNoData = false;
        completeLines = unknownLines = seenAnglePackets = debugChunks = 0;
        malformedPackets = 0;
        debugAt = 0;
        lastWireLine = "No complete line yet";
        CalibrationStatus = "Waiting for board settings";
        saved = null;
        try
        {
            if (calibrationProfile == null) throw new InvalidOperationException("Assign the saved MPU calibration JSON first.");
            saved = JsonUtility.FromJson<SavedProfile>(calibrationProfile.text);
            if (saved == null || saved.imus == null || saved.imus.Length != 2)
                throw new InvalidOperationException("Saved MPU profile must contain two hands.");
            foreach (SavedHand hand in saved.imus)
                if (hand.accelBias == null || hand.accelBias.Length != 3 ||
                    hand.accelScale == null || hand.accelScale.Length != 3 ||
                    hand.axisMap == null || hand.axisMap.Length != 3 ||
                    hand.gyroOffset == null || hand.gyroOffset.Length != 3 || hand.levelTrim == null)
                    throw new InvalidOperationException("Saved MPU profile is incomplete.");
            port = new ESP32WindowsSerial(portName, baudRate, dtrEnable);
            port.Open();
            openedAt = Time.realtimeSinceStartup;
            port.WriteLine("GET");
            probeAt = Time.realtimeSinceStartup + 2f;
            Debug.Log("MPU: opened " + portName + " DTR=" + dtrEnable + ". Waiting for settings/data; keep sensors still during startup.", this);
        }
        catch (Exception e)
        {
            CalibrationStatus = e.Message;
            Debug.LogWarning("MPU: " + e.Message, this);
            Disconnect();
        }
    }

    private void Update()
    {
        DashDirection = 0;
        JumpPressed = false;
        stick.BeginFrame();
        piezo.BeginFrame();
        stick.Expire(Time.realtimeSinceStartup, disconnectTimeout);
        if (port == null || !port.IsOpen) return;
        float now = Time.realtimeSinceStartup;
        bool leftDash = false, rightDash = false;
        try
        {
            string chunk = port.ReadExisting();
            receivedBytes += chunk.Length;
            if (chunk.Length > 0 && debugChunks < 3)
            {
                debugChunks++;
                Debug.Log("MPU RX chunk: " + chunk.Substring(0, Math.Min(chunk.Length, 800))
                    .Replace("\r", "\\r").Replace("\n", "\\n").Replace("\0", "\\0"), this);
            }
            pending += chunk;
            if (pending.Length > 16384)
            {
                pending = "";
                ClearInput();
                return;
            }
            int end;
            while ((end = pending.IndexOfAny(LineEndings)) >= 0)
            {
                string line = pending.Substring(0, end).Trim();
                pending = pending.Substring(end + 1);
                if (line.Length == 0) continue;
                completeLines++;
                lastWireLine = line;
                string type = MpuPacketParser.MessageType(line);
                if (completeLines <= 6 || (type == "" && unknownLines < 5))
                    Debug.Log("MPU RX line [type=" + type + "]: " + line.Substring(0, Math.Min(line.Length, 1400)), this);
                if (type == "") unknownLines++;
                if (type == "p")
                {
                    PiezoPacket packet = ReadWirePacket<PiezoPacket>(line);
                    if (packet != null) piezo.Record(packet.seq, packet.hit, packet.ok, packet.peak, now);
                }
                else if (type == "j")
                {
                    StickPacket packet = ReadWirePacket<StickPacket>(line);
                    if (packet != null && packet.v != null && packet.v.Length == 3)
                    {
                        int x = packet.v[0], y = packet.v[1], button = packet.v[2];
                        if (x >= -1 && x <= 1 && y >= -1 && y <= 1 && button >= 0 && button <= 1)
                        {
                            int stickX = invertJoystickX ? -x : x;
                            int stickY = invertJoystickY ? -y : y;
                            // The mounted stick sends left/right on Y and up/down on inverted X.
                            stick.Record(stickY, -stickX, button, now);
                        }
                    }
                }
                else if (type == "u")
                {
                    DistancePacket distance = ReadWirePacket<DistancePacket>(line);
                    if (distance == null) continue;
                    ultrasonicAt = now;
                    ultrasonicPackets++;
                    ultrasonicOk = distance != null && distance.ok == 1 &&
                        !float.IsNaN(distance.cm) && !float.IsInfinity(distance.cm) &&
                        distance.cm >= 2f && distance.cm <= 400f;
                    UltrasonicCm = ultrasonicOk ? distance.cm : 0f;
                }
                else if (type == "s")
                {
                    SettingsPacket settings = ReadWirePacket<SettingsPacket>(line);
                    if (settings == null || settings.imu == null || settings.imu.Length != 2 || settings.alsb <= 0) continue;
                    settingsPackets++;
                    CheckCalibration(settings);
                    if (!configured)
                    {
                        configured = true;
                        // Runtime streaming only. Do not CAL/ZERO/DEF or SAVE.
                        port.WriteLine("STREAM 1");
                        port.WriteLine("RAW 1");
                        // Learn the piezo's quiet level after USB/ADC has settled,
                        // once per scene connection. No IMU calibration or EEPROM write.
                        port.WriteLine("PIEZOZERO");
                    }
                }
                else if (type == "d" && MpuPacketParser.TryAngles(line, out float[][] angles))
                {
                    seenAnglePackets++;
                    if (now >= debugAt)
                    {
                        debugAt = now + 2f;
                        Debug.Log("MPU angles: L=" + angles[0][0] + "," + angles[0][1] + " ok=" + angles[0][3] +
                            " R=" + angles[1][0] + "," + angles[1][1] + " ok=" + angles[1][3] +
                            " calibrationReady=" + calibrationMatches, this);
                    }
                    if (!calibrationMatches) continue;
                    dataPackets++;
                    if (dataPackets == 1) Debug.Log("MPU: first angle packet received. Saved calibration verified.", this);
                    for (int i = 0; i < 2; ++i)
                    {
                        Configure(hands[i]);
                        hands[i].UpdateAngles(angles[i][0], angles[i][1], angles[i][3] == 1, now);
                    }
                }
                else if (calibrationMatches && type == "r" && MpuPacketParser.TryGyro(line, out float[][] gyro))
                {
                    gyroPackets++;
                    leftDash |= hands[0].UpdateGyro(gyro[0][0], gyro[0][1], gyro[0][2], now);
                    rightDash |= hands[1].UpdateGyro(gyro[1][0], gyro[1][1], gyro[1][2], now);
                }
            }
            if (settingsPackets == 0 && receivedBytes > 0 && now - openedAt > 4f)
                CalibrationStatus = "Receiving bytes but no settings packet; inspect MPU RX lines in Console.";
            if (!warnedNoData && receivedBytes == 0 && now - openedAt > 4f)
            {
                warnedNoData = true;
                CalibrationStatus = "No serial bytes. Check DTR, COM port and board USB connection.";
                Debug.LogWarning("MPU: port opened but no serial bytes received after 4 seconds. DTR=" + dtrEnable, this);
            }
            if (!configured && now >= probeAt)
            {
                port.WriteLine("GET");
                probeAt = now + 2f;
            }
            foreach (MpuGestureState hand in hands) hand.Expire(now, disconnectTimeout);
            Connected = calibrationMatches && (hands[0].Valid || hands[1].Valid);
            Horizontal = (hands[1].MovementActive ? 1 : 0) - (hands[0].MovementActive ? 1 : 0);
            HasDirectionalInput = hands[0].MovementActive || hands[1].MovementActive;
            bool raisedTogether = calibrationMatches && LeftHandRaised && RightHandRaised;
            JumpPressed = raisedTogether && !bothHandsRaised;
            bothHandsRaised = raisedTogether;
            DashDirection = leftDash == rightDash ? 0 : leftDash ? -1 : 1;
            // Raising both hands is a jump gesture, not an accidental wave dash.
            if (!Connected || JumpPressed) DashDirection = 0;
        }
        catch (Exception e)
        {
            CalibrationStatus = e.Message;
            Debug.LogWarning("MPU serial: " + e.Message, this);
            Disconnect();
        }
    }

    private void Configure(MpuGestureState hand)
    {
        hand.PitchNeutralMin = pitchNeutralMin; hand.PitchNeutralMax = pitchNeutralMax;
        hand.WaveSpeed = waveSpeed; hand.WaveTravel = waveTravel;
        hand.WaveWindow = waveWindow; hand.WaveCooldown = waveCooldown;
    }

    private T ReadWirePacket<T>(string line) where T : class
    {
        try { return JsonUtility.FromJson<T>(line); }
        catch (ArgumentException)
        {
            // A paused/unfocused editor can overflow the OS serial buffer.
            // Discard this line and resync at the next newline, keeping COM open.
            if (++malformedPackets <= 3)
                Debug.LogWarning("MPU: skipped incomplete serial packet; receiving continues. " +
                    line.Substring(0, Math.Min(line.Length, 140)), this);
            return null;
        }
    }

    private void CheckCalibration(SettingsPacket settings)
    {
        if (settings == null || settings.imu == null || settings.imu.Length != 2 || settings.alsb <= 0) return;
        bool match = true;
        for (int i = 0; i < 2; ++i)
        {
            SavedHand profile = saved.imus[i];
            BoardHand board = settings.imu[i];
            int expectedAddress = Convert.ToInt32(profile.addr.Replace("0x", ""), 16);
            if (board.addr != expectedAddress) throw new InvalidOperationException("MPU left/right addresses differ from the saved profile.");
            float scale = settings.alsb / (profile.accelLsbPerG > 0 ? profile.accelLsbPerG : 16384f);
            if (board.ab == null || board.ab.Length != 3 || board.@as == null || board.@as.Length != 3 ||
                board.map == null || board.map.Length != 3) return;
            for (int axis = 0; axis < 3; ++axis)
                match &= Math.Abs(board.ab[axis] - profile.accelBias[axis] * scale) <= 0.25f &&
                         Math.Abs(board.@as[axis] - profile.accelScale[axis] * scale) <= 0.25f &&
                         board.map[axis] == profile.axisMap[axis];
            match &= Math.Abs(board.rz - profile.levelTrim.roll) <= 0.03f &&
                     Math.Abs(board.pz - profile.levelTrim.pitch) <= 0.03f;
        }
        calibrationMatches = match;
        if (match)
        {
            if (settingsPackets == 1 || CalibrationStatus != "Saved accel / axes / trim verified; board gyro retained")
                Debug.Log("MPU: saved accel/map/trim verified; retaining board gyro calibration.", this);
            CalibrationStatus = "Saved accel / axes / trim verified; board gyro retained";
            return;
        }
        ClearInput();
        CalibrationStatus = "Profile differs: input paused";
        if (!restoreSavedCalibrationWhenDifferent || restoreAttempted) return;
        restoreAttempted = true;
        for (int i = 0; i < 2; ++i)
        {
            SavedHand profile = saved.imus[i];
            BoardHand board = settings.imu[i];
            float scale = settings.alsb / (profile.accelLsbPerG > 0 ? profile.accelLsbPerG : 16384f);
            // Preserve the startup gyro calibration; restore saved accel/mounting only.
            float[] gyro = board.go != null && board.go.Length == 3 ? board.go : profile.gyroOffset;
            StringBuilder command = new StringBuilder("CALSET " + i);
            foreach (float n in gyro) Append(command, n);
            foreach (float n in profile.accelBias) Append(command, n * scale);
            foreach (float n in profile.accelScale) Append(command, n * scale);
            foreach (int n in profile.axisMap) command.Append(' ').Append(n);
            Append(command, profile.levelTrim.roll); Append(command, profile.levelTrim.pitch);
            port.WriteLine(command.ToString());
        }
        port.WriteLine("GET");
        CalibrationStatus = "Restoring saved profile in RAM; waiting for verification";
        Debug.Log("MPU: restoring saved accel/map/trim in RAM. EEPROM is unchanged.", this);
    }

    private static void Append(StringBuilder builder, float n)
    {
        builder.Append(' ').Append(n.ToString("0.###", CultureInfo.InvariantCulture));
    }

    private void ClearInput()
    {
        JumpPressed = bothHandsRaised = false;
        stick.Reset();
        piezo.Reset();
        ultrasonicOk = false;
        UltrasonicCm = 0f;
        foreach (MpuGestureState hand in hands) hand.Reset();
        Horizontal = DashDirection = 0;
        HasDirectionalInput = Connected = false;
    }

    private void Disconnect()
    {
        if (port != null) port.Dispose();
        port = null;
        pending = "";
        ClearInput();
    }

    private void OnDisable() { Disconnect(); }

    private void OnGUI()
    {
        if (!showStatus) return;
        GUI.Box(new Rect(12, 110, 690, 218), "MPU " + portName + " | " + (Connected ? "LIVE" : "WAITING"));
        GUI.Label(new Rect(24, 137, 585, 23),
            "Left pitch: " + hands[0].PitchDegrees.ToString("0") + " deg " + (hands[0].MovementActive ? "MOVE" : "neutral") +
            "   Right pitch: " + hands[1].PitchDegrees.ToString("0") + " deg " + (hands[1].MovementActive ? "MOVE" : "neutral") +
            "   Move: " + Horizontal);
        GUI.Label(new Rect(24, 163, 665, 23), CalibrationStatus);
        GUI.Label(new Rect(24, 189, 665, 23), "RX bytes: " + receivedBytes + " | settings: " + settingsPackets + " | angles: " + dataPackets + " | gyro: " + gyroPackets + " | DTR: " + dtrEnable);
        GUI.Label(new Rect(24, 215, 665, 23), "Lines: " + completeLines + " | unknown: " + unknownLines + " | angle packets seen: " + seenAnglePackets + " | pending bytes: " + pending.Length);
        GUI.Label(new Rect(24, 241, 665, 45), "Last RX: " + lastWireLine.Substring(0, Math.Min(lastWireLine.Length, 150)));
        GUI.Label(new Rect(24, 291, 665, 23), "HC-SR04: " + (UltrasonicValid ? UltrasonicCm.ToString("0.0") + " cm" : "NO ECHO / WAITING") + " | packets: " + ultrasonicPackets);
    }
}
