using System;

// No Unity dependency: posture/wave rules can be checked without a live board.
public sealed class MpuGestureState
{
    public bool MovementActive { get; private set; }
    public bool Valid { get; private set; }
    public float PitchDegrees { get; private set; }
    public float LastDataAt { get; private set; } = float.NegativeInfinity;
    public float PitchNeutralMin = -35f, PitchNeutralMax = 45f;
    public float PoseConfirmSeconds = 0.12f;
    public float WaveSpeed = 30f; // calibrated degrees/second
    public float WaveTravel = 4f; // integrated degrees in EACH direction
    public float WaveWindow = 0.65f;
    public float WaveCooldown = 0.9f;
    public float PoseSettleSeconds = 0.25f;
    private bool candidate;
    private float candidateAt, poseChangedAt;
    private float lastGyroAt = float.NegativeInfinity;
    private float waveStartedAt, firstTravel, returnTravel, cooldownUntil;
    private int waveAxis = -1, waveSign;

    public void UpdateAngles(float roll, float pitch, bool valid, float now)
    {
        if (!valid || !Finite(roll) || !Finite(pitch)) { Reset(); return; }
        bool first = !Valid;
        Valid = true;
        LastDataAt = now;
        PitchDegrees = pitch;
        // Both endpoints are neutral. Roll/yaw do not decide walking.
        bool next = pitch < PitchNeutralMin || pitch > PitchNeutralMax;
        if (first) { candidateAt = now; poseChangedAt = now; candidate = next; }
        if (next != candidate) { candidate = next; candidateAt = now; }
        // Release immediately on entering the inclusive neutral pitch range.
        if (!next && MovementActive) ChangePose(false, now);
        else if (next && !MovementActive && now - candidateAt >= PoseConfirmSeconds)
            ChangePose(true, now);
    }

    private void ChangePose(bool upright, float now)
    {
        MovementActive = upright;
        poseChangedAt = now;
        ResetWave();
    }

    public bool UpdateGyro(float x, float y, float z, float now)
    {
        float dt = now - lastGyroAt;
        lastGyroAt = now;
        if (!Valid || now - LastDataAt > 0.35f || !Finite(x) || !Finite(y) || !Finite(z) ||
            dt <= 0 || dt > 0.25f || now < cooldownUntil || now - poseChangedAt < PoseSettleSeconds)
        { ResetWave(); return false; }
        if (waveAxis >= 0 && now - waveStartedAt > WaveWindow) ResetWave();
        float[] rates = { x, y, z };
        if (waveAxis < 0)
        {
            int strongest = 0;
            for (int i = 1; i < 3; ++i)
                if (Math.Abs(rates[i]) > Math.Abs(rates[strongest])) strongest = i;
            if (Math.Abs(rates[strongest]) < WaveSpeed) return false;
            waveAxis = strongest;
            waveSign = Math.Sign(rates[strongest]);
            waveStartedAt = now;
        }
        float speed = rates[waveAxis];
        if (Math.Abs(speed) < WaveSpeed) return false;
        float travel = Math.Abs(speed) * Math.Min(dt, 0.15f);
        if (Math.Sign(speed) == waveSign)
        {
            firstTravel += travel;
            returnTravel = 0;
        }
        else if (firstTravel >= WaveTravel)
        {
            returnTravel += travel;
            if (returnTravel >= WaveTravel)
            {
                cooldownUntil = now + WaveCooldown;
                ResetWave();
                return true;
            }
        }
        else
        {
            waveSign = Math.Sign(speed);
            firstTravel = travel;
            returnTravel = 0;
            waveStartedAt = now;
        }
        return false;
    }

    public void Expire(float now, float timeout)
    {
        if (Valid && now - LastDataAt > timeout) Reset();
    }

    public void Reset()
    {
        Valid = MovementActive = candidate = false;
        PitchDegrees = 0;
        LastDataAt = lastGyroAt = float.NegativeInfinity;
        ResetWave();
    }

    private void ResetWave()
    {
        waveAxis = -1;
        firstTravel = returnTravel = 0;
    }

    private static bool Finite(float n) { return !float.IsNaN(n) && !float.IsInfinity(n); }
}
