using UnityEngine;

public static class PotionSpriteLibrary
{
    public const int FrameWidth = 19, FrameHeight = 38, FrameCount = 15;
    private static Sprite[] red, blue, gold, green, purple;
    private static Sprite[] black, orange, lime;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetCache()
    {
        red = null;
        blue = null;
        gold = green = purple = null;
        black = orange = lime = null;
    }

    private static bool IsUsable(Sprite[] frames)
    {
        if (frames == null || frames.Length != FrameCount) return false;
        foreach (Sprite frame in frames)
            if (frame == null || frame.texture == null) return false;
        return true;
    }

    public static Sprite[] Frames(PotionKind kind)
    {
        if (kind == PotionKind.Shrink) { if (!IsUsable(black)) black = Load("RoundPotionBlack"); return black; }
        if (kind == PotionKind.Sluggish) { if (!IsUsable(orange)) orange = Load("RoundPotionOrange"); return orange; }
        if (kind == PotionKind.Confuse) { if (!IsUsable(lime)) lime = Load("RoundPotionLime"); return lime; }
        if (kind == PotionKind.DoubleScore) { if (!IsUsable(gold)) gold = Load("RoundPotionGold"); return gold; }
        if (kind == PotionKind.Haste) { if (!IsUsable(green)) green = Load("RoundPotionGreen"); return green; }
        if (kind == PotionKind.SlowFall) { if (!IsUsable(purple)) purple = Load("RoundPotionPurple"); return purple; }
        if (kind == PotionKind.Health)
        {
            if (!IsUsable(red)) red = Load("RoundPotionRed");
            return red;
        }
        if (!IsUsable(blue)) blue = Load("RoundPotionBlue");
        return blue;
    }

    private static Sprite[] Load(string name)
    {
        Texture2D texture = Resources.Load<Texture2D>("Potions/" + name);
        if (texture == null || texture.width != FrameWidth * FrameCount || texture.height != FrameHeight)
        {
            Debug.LogError("Missing or resized potion sheet: Resources/Potions/" + name + ".png (expected 285x38)");
            return new Sprite[0];
        }
        texture.filterMode = FilterMode.Point;
        var frames = new Sprite[FrameCount];
        for (int i = 0; i < FrameCount; i++)
        {
            frames[i] = Sprite.Create(texture, new Rect(i * FrameWidth, 0, FrameWidth, FrameHeight),
                new Vector2(0.5f, 0.5f), FrameHeight);
            frames[i].name = name + " " + i;
        }
        return frames;
    }
}
