using System;
using System.Globalization;
using System.Text.RegularExpressions;

// Firmware sends a nested numeric array for d, which Unity JsonUtility does not
// support directly. Parse this small, fixed protocol without adding a JSON DLL.
public static class MpuPacketParser
{
    private static readonly Regex Type = new Regex("\"t\"\\s*:\\s*\"([a-z]+)\"");
    private static readonly Regex Hands = new Regex("\"h\"\\s*:\\s*\\[\\s*\\[([^\\[\\]]*)\\]\\s*,\\s*\\[([^\\[\\]]*)\\]\\s*\\]");
    private static readonly Regex Gyro = new Regex("\"g\"\\s*:\\s*\\[([^\\[\\]]*)\\]");

    public static string MessageType(string line)
    {
        if (string.IsNullOrEmpty(line) || !line.StartsWith("{") || !line.EndsWith("}")) return "";
        Match match = Type.Match(line);
        return match.Success ? match.Groups[1].Value : "";
    }

    public static bool TryAngles(string line, out float[][] values)
    {
        values = null;
        if (MessageType(line) != "d") return false;
        Match match = Hands.Match(line);
        if (!match.Success || !Numbers(match.Groups[1].Value, 4, out float[] left) ||
            !Numbers(match.Groups[2].Value, 4, out float[] right)) return false;
        if ((left[3] != 0 && left[3] != 1) || (right[3] != 0 && right[3] != 1)) return false;
        if (Math.Abs(left[0]) > 360 || Math.Abs(right[0]) > 360 ||
            Math.Abs(left[1]) > 180 || Math.Abs(right[1]) > 180) return false;
        values = new[] { left, right };
        return true;
    }

    public static bool TryGyro(string line, out float[][] values)
    {
        values = null;
        if (MessageType(line) != "r") return false;
        MatchCollection matches = Gyro.Matches(line);
        if (matches.Count != 2 || !Numbers(matches[0].Groups[1].Value, 3, out float[] left) ||
            !Numbers(matches[1].Groups[1].Value, 3, out float[] right)) return false;
        values = new[] { left, right };
        return true;
    }

    private static bool Numbers(string text, int length, out float[] values)
    {
        values = null;
        string[] parts = text.Split(',');
        if (parts.Length != length) return false;
        float[] parsed = new float[length];
        for (int i = 0; i < length; ++i)
            if (!float.TryParse(parts[i], NumberStyles.Float, CultureInfo.InvariantCulture, out parsed[i]) ||
                float.IsNaN(parsed[i]) || float.IsInfinity(parsed[i])) return false;
        values = parsed;
        return true;
    }
}
