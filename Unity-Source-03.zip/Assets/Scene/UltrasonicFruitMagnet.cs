using System.Collections.Generic;
using UnityEngine;

// Uses the existing MPU serial connection; never opens a second COM handle.
[RequireComponent(typeof(MpuHandInput))]
public class UltrasonicFruitMagnet : MonoBehaviour
{
    [Tooltip("Person-to-sensor distance for maximum attraction (centimetres).")]
    public float fullPowerCm = 5f;
    [Tooltip("At or beyond this person-to-sensor distance, attraction is off.")]
    public float offDistanceCm = 70f;
    [Tooltip("Radii are multiples of the player's world collider width.")]
    public float minRadiusWidths = 0.7f, maxRadiusWidths = 2.6f;
    [Tooltip("Seconds for smoothing changes in the visible field.")]
    public float smoothingSeconds = 0.18f;
    public Color shadowTint = new Color(0.25f, 0.62f, 1f, 1f);
    [Range(0f, 0.5f)] public float shadowOpacity = 0.32f;
    public bool showStatus = true;
    public float Power { get; private set; }
    public float Radius { get; private set; }

    private MpuHandInput input;
    private Collider2D playerCollider;
    private PlayerMovement playerMovement;
    private readonly List<Collider2D> nearby = new List<Collider2D>(64);
    private readonly HashSet<Rigidbody2D> affected = new HashSet<Rigidbody2D>();
    private ContactFilter2D filter;
    private SpriteRenderer shadow;
    private Texture2D shadowTexture;
    private Sprite shadowSprite;
    private readonly MagnetProximityState proximity = new MagnetProximityState();
    private int lastPacket = -1;
    private float width;
    private float targetPower;
    public bool UsingManualPower => proximity.UseManual(GamePreferences.UsesManualMagnet,
        input != null && input.isActiveAndEnabled, Time.realtimeSinceStartup);
    private bool audibleField;

    private void Awake()
    {
        input = GetComponent<MpuHandInput>();
        playerCollider = GetComponent<Collider2D>();
        playerMovement = GetComponent<PlayerMovement>();
        filter = new ContactFilter2D { useTriggers = true, useLayerMask = false };
        CreateShadow();
    }

    private void CreateShadow()
    {
        // A translucent filled field with a feathered rim: background remains
        // visible, but the actual attraction boundary can still be read.
        const int size = 128;
        var pixels = new Color[size * size];
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float nx = (x + 0.5f - size * 0.5f) / (size * 0.5f);
                float ny = (y + 0.5f - size * 0.5f) / (size * 0.5f);
                float radius = Mathf.Sqrt(nx * nx + ny * ny);
                float rimDistance = (radius - 0.89f) / 0.065f;
                float rim = Mathf.Exp(-rimDistance * rimDistance);
                float fade = Mathf.Clamp01((radius - 0.95f) / 0.05f);
                float alpha = radius >= 1f ? 0f : (0.55f + 0.45f * rim) * (1f - Mathf.SmoothStep(0f, 1f, fade));
                pixels[y * size + x] = new Color(1f, 1f, 1f, alpha);
            }
        shadowTexture = new Texture2D(size, size, TextureFormat.RGBA32, false);
        shadowTexture.name = "Soft magnet alpha";
        shadowTexture.wrapMode = TextureWrapMode.Clamp;
        shadowTexture.filterMode = FilterMode.Bilinear;
        shadowTexture.SetPixels(pixels);
        shadowTexture.Apply(false, true);
        shadowSprite = Sprite.Create(shadowTexture, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size * 0.5f);
        shadowSprite.name = "Soft magnet shadow";
        var visual = new GameObject("Soft magnet shadow");
        visual.transform.SetParent(transform, false);
        shadow = visual.AddComponent<SpriteRenderer>();
        shadow.sprite = shadowSprite;
        var sprite = GetComponentInChildren<SpriteRenderer>();
        if (sprite != null && sprite != shadow) { shadow.sortingLayerID = sprite.sortingLayerID; shadow.sortingOrder = sprite.sortingOrder + 1; }
        shadow.enabled = false;
    }

    private Vector2 Center => playerCollider != null ? (Vector2)playerCollider.bounds.center : (Vector2)transform.position;

    private void Update()
    {
        float now = Time.realtimeSinceStartup;
        if (input != null && input.isActiveAndEnabled)
        {
            if (lastPacket != input.UltrasonicPacketCount)
            {
                lastPacket = input.UltrasonicPacketCount;
                proximity.Record(input.UltrasonicCm, input.UltrasonicValid, now);
            }
        }
        else proximity.Reset();
        float target = proximity.ResolvePower(GamePreferences.UsesManualMagnet,
            input != null && input.isActiveAndEnabled, now, GamePreferences.ManualMagnetPower, fullPowerCm, offDistanceCm);
        targetPower = target;
        Power = Mathf.Lerp(Power, target, 1f - Mathf.Exp(-Time.deltaTime / Mathf.Max(0.01f, smoothingSeconds)));
        if (target == 0f && Power < 0.001f) Power = 0f;
        // Shrinking changes the catch area, while the sensor keeps its usual range.
        width = playerCollider != null ? Mathf.Max(0.1f, playerCollider.bounds.size.x / (playerMovement != null ? playerMovement.SizeMultiplier : 1f)) : 1f;
        Radius = Power > 0f ? width * Mathf.Lerp(minRadiusWidths, maxRadiusWidths, Power) : 0f;
        if (Time.timeScale > 0f)
        {
            bool active = Power > (audibleField ? .04f : .20f);
            if (active != audibleField)
            {
                audibleField = active;
                GameAudio.Play(active ? "MagnetOn" : "MagnetOff", .16f, 1f, 1f);
            }
        }
    }

    private void LateUpdate()
    {
        shadow.enabled = Radius > 0f && Power > 0.001f;
        if (!shadow.enabled) return;
        Vector2 center = Center;
        shadow.transform.position = new Vector3(center.x, center.y, transform.position.z);
        Vector3 parentScale = transform.lossyScale;
        shadow.transform.localScale = new Vector3(
            Radius / Mathf.Max(0.001f, Mathf.Abs(parentScale.x)),
            Radius / Mathf.Max(0.001f, Mathf.Abs(parentScale.y)), 1f);
        Color tint = shadowTint;
        // Keep a weak but active field legible; range communicates strength.
        // Only fade the whole field when it is nearly switched off.
        tint.a = shadowOpacity * Mathf.Lerp(0.75f, 1f, Power) * Mathf.Clamp01(Power / 0.04f);
        shadow.color = tint;
    }

    private void FixedUpdate()
    {
        if (Radius <= 0f || targetPower <= 0f) return;
        Vector2 center = Center;
        Physics2D.OverlapCircle(center, Radius, filter, nearby);
        affected.Clear();
        foreach (Collider2D hit in nearby)
        {
            // Fruit, bombs and optional potions share the same attraction.
            FruitPickup fruit = hit.GetComponentInParent<FruitPickup>();
            BombObstacle bomb = fruit == null ? hit.GetComponentInParent<BombObstacle>() : null;
            PotionPickup potion = fruit == null && bomb == null ? hit.GetComponentInParent<PotionPickup>() : null;
            if (fruit == null && bomb == null && potion == null) continue;
            Rigidbody2D body = fruit != null ? fruit.GetComponent<Rigidbody2D>()
                : bomb != null ? bomb.GetComponent<Rigidbody2D>() : potion.GetComponent<Rigidbody2D>();
            if (body == null || !body.simulated || body.bodyType != RigidbodyType2D.Dynamic || !affected.Add(body)) continue;
            RepelledPickup repelled = body.GetComponent<RepelledPickup>();
            if (repelled != null && repelled.BlocksMagnet) continue;
            Vector2 offset = center - body.position;
            float distance = offset.magnitude;
            if (distance <= 0.001f || distance > Radius) continue;
            float proximity = 1f - distance / Radius;
            float speed = width * Mathf.Lerp(0.8f, 4f, Power) * Mathf.Lerp(0.5f, 1f, proximity);
            // Limit travel per physics step so targets cannot jump through the player.
            speed = Mathf.Min(speed, distance / Time.fixedDeltaTime);
            Vector2 desired = offset / distance * speed;
            float acceleration = width * Mathf.Lerp(3f, 20f, Power) * Mathf.Lerp(0.4f, 1f, proximity);
            body.linearVelocity = Vector2.MoveTowards(body.linearVelocity, desired, acceleration * Time.fixedDeltaTime);
        }
    }

    private void OnDisable()
    {
        Power = Radius = targetPower = 0f;
        proximity.Reset();
        lastPacket = -1;
        if (shadow != null) shadow.enabled = false;
    }

    private void OnDestroy()
    {
        if (shadowSprite != null) Destroy(shadowSprite);
        if (shadowTexture != null) Destroy(shadowTexture);
    }

    private void OnValidate()
    {
        fullPowerCm = Mathf.Clamp(fullPowerCm, 2f, 390f);
        offDistanceCm = Mathf.Clamp(offDistanceCm, fullPowerCm + 10f, 400f);
        minRadiusWidths = Mathf.Max(0.1f, minRadiusWidths);
        maxRadiusWidths = Mathf.Max(minRadiusWidths, maxRadiusWidths);
        smoothingSeconds = Mathf.Max(0.01f, smoothingSeconds);
        shadowOpacity = Mathf.Clamp(shadowOpacity, 0f, 0.5f);
    }
}
