using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class RetrySceneController : MonoBehaviour
{
    [SerializeField] private TMP_Text playerText;
    [SerializeField] private TMP_Text levelText;
    [SerializeField] private TMP_Text scoreText;
    [SerializeField] private TMP_Text bestScoreText;

    private void Start()
    {
        if (scoreText == null) return;
        Canvas canvas = scoreText.GetComponentInParent<Canvas>();
        if (canvas == null) return;
        GameUiLayout.ScaleCanvas(canvas);
        CreateBackgroundImage(canvas.transform);
        TMP_Text title = null;
        foreach (TMP_Text text in canvas.GetComponentsInChildren<TMP_Text>(true))
            if (text.text.Trim().ToLowerInvariant().Contains("time up")) { title = text; break; }
        Button[] buttons = canvas.GetComponentsInChildren<Button>(true);
        GameUiLayout.Panel("ResultShade", canvas.transform, Vector2.zero, Vector2.one, new Color(0f, 0f, 0f, 0.26f));
        RectTransform card = GameUiLayout.Panel("ResultCard", canvas.transform,
            new Vector2(0.14f, 0.08f), new Vector2(0.86f, 0.94f), new Color(0.035f, 0.09f, 0.12f, 0.94f));
        if (title == null)
            title = GameUiLayout.Label("ResultTitle", card, scoreText.font, "", Vector2.zero, Vector2.one, 62f, Color.white);
        title.text = GameData.lives == 0 ? "ROUND OVER" : "TIME UP!";
        GameUiLayout.Style(title, card, new Vector2(0.05f, 0.83f), new Vector2(0.95f, 0.97f), 62f, new Color(1f, 0.84f, 0.52f));
        if (playerText != null)
        {
            playerText.text = "Player: " + GameData.username;
            GameUiLayout.Style(playerText, card, new Vector2(0.06f, 0.72f), new Vector2(0.59f, 0.81f), 32f, Color.white, TextAlignmentOptions.MidlineLeft);
        }
        if (levelText != null)
        {
            levelText.text = "Level: " + DifficultyProfile.For(GameData.selectedLevel).Name;
            GameUiLayout.Style(levelText, card, new Vector2(0.61f, 0.72f), new Vector2(0.94f, 0.81f), 32f, Color.white, TextAlignmentOptions.MidlineRight);
        }
        scoreText.text = "SCORE " + GameData.score;
        GameUiLayout.Style(scoreText, card, new Vector2(0.06f, 0.57f), new Vector2(0.94f, 0.71f), 64f, new Color(1f, 0.84f, 0.52f));
        if (bestScoreText != null)
        {
            bestScoreText.text = "BEST SCORE " + GameData.bestScore;
            GameUiLayout.Style(bestScoreText, card, new Vector2(0.06f, 0.49f), new Vector2(0.94f, 0.57f), 28f, new Color(0.65f, 0.87f, 0.91f));
        }
        string accuracy = GameData.caught + GameData.missed == 0 ? "--" : GameData.Accuracy.ToString("0.0") + "%";
        string[] names = {"CAUGHT", "MISSED", "ACCURACY", "BEST COMBO", "COMBO BONUS", "ACCURACY BONUS"};
        string[] values = {GameData.caught.ToString(), GameData.missed.ToString(), accuracy,
            GameData.bestCombo.ToString(), "+" + GameData.comboBonus, "+" + GameData.accuracyBonus};
        for (int i = 0; i < 6; i++)
        {
            float x = 0.06f + (i % 3) * 0.30f;
            float y = i < 3 ? 0.35f : 0.21f;
            RectTransform cell = GameUiLayout.Panel(names[i], card, new Vector2(x, y), new Vector2(x + 0.28f, y + 0.12f), new Color(0.12f, 0.24f, 0.27f, 0.8f));
            GameUiLayout.Label(names[i] + "Caption", cell, scoreText.font, names[i], new Vector2(0.02f, 0.56f), new Vector2(0.98f, 0.93f), 20f, new Color(0.65f, 0.87f, 0.91f));
            GameUiLayout.Label(names[i] + "Value", cell, scoreText.font, values[i], new Vector2(0.02f, 0.04f), new Vector2(0.98f, 0.56f), 34f, Color.white);
        }
        foreach (Button button in buttons)
        {
            TMP_Text label = button.GetComponentInChildren<TMP_Text>(true);
            if (label == null) continue;
            bool retry = label.text.Trim().ToLowerInvariant() == "retry";
            bool home = label.text.Trim().ToLowerInvariant() == "home";
            if (!retry && !home) continue;
            GameUiLayout.Place(button.GetComponent<RectTransform>(), card,
                new Vector2(retry ? 0.10f : 0.57f, 0.05f), new Vector2(retry ? 0.43f : 0.90f, 0.16f));
            GameUiLayout.Style(label, button.transform, new Vector2(0.04f, 0.12f), new Vector2(0.96f, 0.88f), 34f, Color.white);
        }
    }

    private void CreateBackgroundImage(Transform parent)
    {
        if (GameData.selectedBackgroundSprite == null) return;
        RectTransform rect = GameUiLayout.Panel("RetryBackground", parent, Vector2.zero, Vector2.one, Color.white);
        rect.GetComponent<Image>().sprite = GameData.selectedBackgroundSprite;
        rect.SetAsFirstSibling();
    }
}
