using UnityEngine;

// Short separation window after a pulse: the magnet must not immediately undo
// the knockback and an overlapping trigger must not collect/hit the player.
public sealed class RepelledPickup : MonoBehaviour
{
    private float magnetUntil, contactUntil;
    public bool BlocksMagnet => Time.time < magnetUntil;
    public bool BlocksPlayerContact => Time.time < contactUntil;
    public void Protect(float magnetSeconds, float contactSeconds)
    {
        magnetUntil = Mathf.Max(magnetUntil, Time.time + magnetSeconds);
        contactUntil = Mathf.Max(contactUntil, Time.time + contactSeconds);
    }
}
