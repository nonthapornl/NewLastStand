using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class UiSoundFeedback : MonoBehaviour, IPointerClickHandler, ISubmitHandler
{
    private bool CanPlay => isActiveAndEnabled && GetComponent<Selectable>() != null && GetComponent<Selectable>().IsInteractable();
    public void OnPointerClick(PointerEventData data) { if(CanPlay&&data.button==PointerEventData.InputButton.Left)GameAudio.Play("Click",.42f); }
    public void OnSubmit(BaseEventData data) { if(CanPlay)GameAudio.Play("Click",.42f); }
}
