using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MpuHandInput))]
public sealed class PiezoShockwave : MonoBehaviour
{
    public float cooldownSeconds = 3f;
    public float radiusInPlayerWidths = 3f;
    [Tooltip("Maximum sideways travel during the short hop, in normal player widths.")]
    public float scatterDistanceWidths = .65f;
    public float hopHeightWidths = .32f;
    public float hopSeconds = .90f;
    public float magnetGraceSeconds = 1.1f;
    public float CooldownRemaining => Mathf.Max(0f, nextPulse - Time.time);
    public bool IsFlashing => Time.time < flashUntil;
    public bool SensorLive => input != null && input.PiezoLive;
    private MpuHandInput input;
    private Collider2D playerCollider;
    private PlayerMovement movement;
    private readonly List<Collider2D> hits = new List<Collider2D>(64);
    private readonly HashSet<Rigidbody2D> affected = new HashSet<Rigidbody2D>();
    private ContactFilter2D filter;
    private float nextPulse, flashUntil, visualStart, visualRadius;
    private Vector3 visualCenter;
    private LineRenderer ring;
    private Material ringMaterial;
    private const float VisualSeconds = .42f;

    private void Awake()
    {
        input = GetComponent<MpuHandInput>(); playerCollider = GetComponent<Collider2D>();
        movement = GetComponent<PlayerMovement>();
        filter = new ContactFilter2D { useTriggers = true, useLayerMask = false };
        var child = new GameObject("Piezo pulse ring"); child.transform.SetParent(transform, false);
        ring = child.AddComponent<LineRenderer>(); ring.useWorldSpace = true;
        ring.loop = true; ring.positionCount = 65; ring.numCapVertices = 0;
        Shader shader = Shader.Find("Sprites/Default");
        if (shader != null) { ringMaterial = new Material(shader); ring.sharedMaterial = ringMaterial; }
        var renderer = GetComponentInChildren<SpriteRenderer>();
        if (renderer != null) { ring.sortingLayerID = renderer.sortingLayerID; ring.sortingOrder = renderer.sortingOrder + 3; }
        ring.enabled = false;
    }

    private void Update()
    {
        if (Time.timeScale <= 0f || !GameData.RoundActive || GamePreferences.Controls != ControlScheme.Joystick) return;
        if (input != null && input.PiezoLive && input.PiezoPressed) TryPulse();
    }

    public bool TryPulse()
    {
        if (Time.timeScale <= 0f || !GameData.RoundActive || GamePreferences.Controls != ControlScheme.Joystick || Time.time < nextPulse)
            return false;
        nextPulse = Time.time + Mathf.Max(.3f, cooldownSeconds);
        flashUntil = Time.time + .45f;
        float scale = movement != null ? movement.SizeMultiplier : 1f;
        float width = playerCollider != null ? Mathf.Max(.1f, playerCollider.bounds.size.x / Mathf.Max(.1f, scale)) : 1f;
        Vector2 center = playerCollider != null ? (Vector2)playerCollider.bounds.center : (Vector2)transform.position;
        float radius = width * Mathf.Max(.1f, radiusInPlayerWidths);
        Physics2D.OverlapCircle(center, radius, filter, hits); affected.Clear();
        int centreSide = 0;
        foreach (Collider2D hit in hits)
        {
            FruitPickup fruit = hit.GetComponentInParent<FruitPickup>();
            BombObstacle bomb = fruit == null ? hit.GetComponentInParent<BombObstacle>() : null;
            PotionPickup potion = fruit == null && bomb == null ? hit.GetComponentInParent<PotionPickup>() : null;
            if (fruit == null && bomb == null && potion == null) continue;
            Rigidbody2D body = fruit != null ? fruit.GetComponent<Rigidbody2D>()
                : bomb != null ? bomb.GetComponent<Rigidbody2D>() : potion.GetComponent<Rigidbody2D>();
            if (body == null || !body.simulated || body.bodyType != RigidbodyType2D.Dynamic || !affected.Add(body)) continue;
            Vector2 offset = body.worldCenterOfMass - center;
            float distance = offset.magnitude;
            if (distance > radius) continue;
            // Fan out to each side. Items directly above the player alternate
            // left/right so they do not all fall back into the same column.
            float side = Mathf.Abs(offset.x) > width * .12f ? Mathf.Sign(offset.x)
                : (++centreSide % 2 == 0 ? 1f : -1f);
            float travel = side * width * Mathf.Max(.05f, scatterDistanceWidths) * Random.Range(.65f, 1f);
            var scatter = body.GetComponent<PickupScatterMotion>();
            if (scatter == null) scatter = body.gameObject.AddComponent<PickupScatterMotion>();
            scatter.Begin(travel, width, hopSeconds, hopHeightWidths);
            var guard = body.GetComponent<RepelledPickup>();
            if (guard == null) guard = body.gameObject.AddComponent<RepelledPickup>();
            guard.Protect(Mathf.Max(magnetGraceSeconds, hopSeconds + .25f), .20f);
        }
        visualCenter = new Vector3(center.x, center.y, transform.position.z);
        visualRadius = radius; visualStart = Time.time; ring.enabled = true;
        ring.startWidth = ring.endWidth = width * .055f;
        if (Application.isPlaying) GameAudio.Play("Dash", .45f, .8f, .15f, true);
        return true;
    }

    private void LateUpdate()
    {
        if (ring == null || !ring.enabled) return;
        float t = (Time.time - visualStart) / VisualSeconds;
        if (t >= 1f) { ring.enabled = false; return; }
        float radius = visualRadius * Mathf.Lerp(.12f, 1f, Mathf.SmoothStep(0f, 1f, t));
        for (int i = 0; i < ring.positionCount; i++)
        {
            float angle = i * Mathf.PI * 2f / ring.positionCount;
            ring.SetPosition(i, visualCenter + new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0f) * radius);
        }
        Color tint = new Color(.55f, 1f, .87f, .65f * (1f - t));
        ring.startColor = ring.endColor = tint;
    }
    private void OnDisable() { if (ring != null) ring.enabled = false; }
    private void OnDestroy()
    {
        if (ringMaterial == null) return;
        if (Application.isPlaying) Destroy(ringMaterial); else DestroyImmediate(ringMaterial);
    }
}
