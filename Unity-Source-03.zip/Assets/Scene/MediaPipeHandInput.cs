using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using UnityEngine;

[DefaultExecutionOrder(-90)]
public class MediaPipeHandInput : MonoBehaviour
{
    public int listenPort = 5055;
    public float disconnectTimeout = 0.4f;
    public int Horizontal { get; private set; }
    public int DashDirection { get; private set; }
    public bool JumpPressed { get; private set; }
    public bool HasDirectionalInput { get; private set; }
    public bool Connected { get; private set; }
    public bool CameraLive { get; private set; }
    public string LeftGesture { get; private set; } = "--";
    public string RightGesture { get; private set; } = "--";
    public int[] LeftPoints { get; private set; }
    public int[] RightPoints { get; private set; }

    [Serializable]
    private class Packet
    {
        public int version;
        public string session;
        public long seq;
        public int leftFist, rightFist;
        public long leftDash, rightDash, jump;
        public string leftGesture, rightGesture;
        public int[] leftPoints, rightPoints;
        public int cameraState; // 0: legacy sender, 1: waiting for frames, 2: live
    }

    private UdpClient client;
    private string session;
    private long sequence, leftDash, rightDash, jump;
    private float receivedAt;

    private void OnEnable()
    {
        if (GamePreferences.Controls != ControlScheme.Camera) return;
        ClearInput();
        session = null;
        sequence = leftDash = rightDash = jump = 0;
        try
        {
            client = new UdpClient(new IPEndPoint(IPAddress.Loopback, listenPort));
            client.Client.Blocking = false;
            Debug.Log("MediaPipe: listening on 127.0.0.1:" + listenPort, this);
        }
        catch (Exception e)
        {
            Debug.LogWarning("MediaPipe UDP: " + e.Message, this);
            CloseSocket();
        }
    }

    private void Update()
    {
        DashDirection = 0;
        JumpPressed = false;
        if (client == null) return;
        bool dashLeft = false, dashRight = false;
        try
        {
            // Bound work per frame and avoid waiting for a packet on Unity's thread.
            for (int i = 0; i < 64 && client.Available > 0; ++i)
            {
                IPEndPoint sender = new IPEndPoint(IPAddress.Loopback, 0);
                byte[] data = client.Receive(ref sender);
                if (data.Length == 0 || data.Length > 1024) continue;
                Packet packet;
                try { packet = JsonUtility.FromJson<Packet>(Encoding.UTF8.GetString(data)); }
                catch (ArgumentException) { continue; }
                if (packet == null || packet.version != 1 ||
                    !Guid.TryParse(packet.session, out _) || packet.seq <= 0 ||
                    packet.leftFist < 0 || packet.leftFist > 1 ||
                    packet.rightFist < 0 || packet.rightFist > 1 ||
                    packet.leftDash < 0 || packet.rightDash < 0 || packet.jump < 0 ||
                    packet.cameraState < 0 || packet.cameraState > 2) continue;

                // New sessions and reconnects establish a baseline: don't replay
                // a dash performed before Unity began listening.
                bool baseline = session != packet.session || !Connected ||
                    Time.realtimeSinceStartup - receivedAt > disconnectTimeout;
                if (!baseline && packet.seq <= sequence) continue;
                bool cameraLive = packet.cameraState != 1;
                if (!baseline)
                {
                    if (packet.leftDash < leftDash || packet.rightDash < rightDash || packet.jump < jump) continue;
                    dashLeft |= CameraLive && cameraLive && packet.leftDash > leftDash;
                    dashRight |= CameraLive && cameraLive && packet.rightDash > rightDash;
                    JumpPressed |= CameraLive && cameraLive && packet.jump > jump;
                }
                if (!cameraLive) JumpPressed = dashLeft = dashRight = false;
                session = packet.session;
                sequence = packet.seq;
                leftDash = packet.leftDash;
                rightDash = packet.rightDash;
                jump = packet.jump;
                CameraLive = cameraLive;
                LeftGesture = cameraLive ? GestureLabel(packet.leftGesture, packet.leftFist, dashLeft) : "--";
                RightGesture = cameraLive ? GestureLabel(packet.rightGesture, packet.rightFist, dashRight) : "--";
                LeftPoints = cameraLive ? ValidPoints(packet.leftPoints) : null;
                RightPoints = cameraLive ? ValidPoints(packet.rightPoints) : null;
                Horizontal = cameraLive ? packet.rightFist - packet.leftFist : 0;
                HasDirectionalInput = cameraLive && (packet.leftFist != 0 || packet.rightFist != 0);
                receivedAt = Time.realtimeSinceStartup;
                Connected = true;
            }
            DashDirection = dashLeft == dashRight ? 0 : dashLeft ? -1 : 1;
            if (Connected && Time.realtimeSinceStartup - receivedAt > disconnectTimeout)
                ClearInput();
        }
        catch (SocketException e)
        {
            if (e.SocketErrorCode != SocketError.WouldBlock)
            {
                Debug.LogWarning("MediaPipe UDP: " + e.Message, this);
                ClearInput();
                CloseSocket();
            }
        }
        catch (Exception e)
        {
            Debug.LogWarning("MediaPipe input: " + e.Message, this);
            ClearInput();
            CloseSocket();
        }
    }

    private static int[] ValidPoints(int[] points)
    {
        if (points == null || points.Length != 42) return null;
        foreach (int coordinate in points)
            if (coordinate < 0 || coordinate > 1000) return null;
        return points;
    }

    private static string GestureLabel(string gesture, int fist, bool dash) => gesture switch
    {
        "OPEN" => "OPEN",
        "FIST" => "FIST",
        "OK" => "OK",
        "V" => "V",
        "UNKNOWN" => "?",
        "NONE" => "--",
        _ => dash ? "OK" : fist != 0 ? "FIST" : "--"
    };

    private void ClearInput()
    {
        Horizontal = DashDirection = 0;
        JumpPressed = false;
        HasDirectionalInput = Connected = false;
        CameraLive = false;
        LeftGesture = RightGesture = "--";
        LeftPoints = RightPoints = null;
    }

    private void CloseSocket()
    {
        if (client != null) client.Close();
        client = null;
    }

    private void OnDisable()
    {
        CloseSocket();
        ClearInput();
    }
}
