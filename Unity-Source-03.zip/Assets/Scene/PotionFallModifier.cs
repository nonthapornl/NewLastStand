using UnityEngine;

// Only falling pickups/bombs slow down; player physics and the round timer stay unchanged.
[RequireComponent(typeof(Rigidbody2D))]
public sealed class PotionFallModifier : MonoBehaviour
{
    private Rigidbody2D body;
    private float gravity, previous = 1f;
    private void Start() { body = GetComponent<Rigidbody2D>(); gravity = body.gravityScale; }
    private void FixedUpdate()
    {
        if (body == null) return;
        float factor = GameData.Potions.FallFactor(Time.time);
        if (Mathf.Approximately(previous, factor)) return;
        body.gravityScale = gravity * factor;
        Vector2 velocity = body.linearVelocity;
        if (velocity.y < 0f) velocity.y *= factor / previous;
        body.linearVelocity = velocity;
        previous = factor;
    }
}
