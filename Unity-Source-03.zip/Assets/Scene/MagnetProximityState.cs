using System;

// Distance filtering and body-distance mapping without Unity dependencies.
public sealed class MagnetProximityState
{
    private readonly float[] samples = new float[3];
    private int count, next;
    private float lastValidAt = float.NegativeInfinity;
    public float FilteredCm { get; private set; }
    public float TimeoutSeconds = 0.35f;

    public void Record(float cm, bool valid, float now)
    {
        if (!valid || float.IsNaN(cm) || float.IsInfinity(cm) || cm < 2f || cm > 400f) return;
        if (!HasRecentReading(now)) count = next = 0;
        samples[next] = cm;
        next = (next + 1) % samples.Length;
        count = Math.Min(count + 1, samples.Length);
        lastValidAt = now;
        if (count == 1) FilteredCm = samples[0];
        else if (count == 2) FilteredCm = (samples[0] + samples[1]) * 0.5f;
        else
        {
            float a = samples[0], b = samples[1], c = samples[2];
            FilteredCm = Math.Max(Math.Min(a, b), Math.Min(Math.Max(a, b), c));
        }
    }

    public bool HasRecentReading(float now) => count > 0 && now - lastValidAt <= TimeoutSeconds;

    public bool UseManual(bool keyboard, bool inputEnabled, float now)
        => keyboard || !inputEnabled || !HasRecentReading(now);

    public float ResolvePower(bool keyboard, bool inputEnabled, float now, float manualPower, float fullCm, float offCm)
        => UseManual(keyboard, inputEnabled, now)
            ? Math.Max(0f, Math.Min(1f, manualPower)) : TargetPower(now, fullCm, offCm);

    public float TargetPower(float now, float fullPowerCm, float offDistanceCm)
    {
        if (!HasRecentReading(now) || offDistanceCm <= fullPowerCm) return 0f;
        return Math.Max(0f, Math.Min(1f, (offDistanceCm - FilteredCm) / (offDistanceCm - fullPowerCm)));
    }

    public void Reset()
    {
        count = next = 0;
        lastValidAt = float.NegativeInfinity;
        FilteredCm = 0f;
    }
}
