using TMPro;
using UnityEngine;
using UnityEngine.UI;

public static class GameUiLayout
{
    public static TMP_FontAsset MenuFont;
    public static void Place(RectTransform rect, Transform parent, Vector2 min, Vector2 max)
    {
        rect.SetParent(parent, false);
        rect.localScale = Vector3.one;
        rect.localRotation = Quaternion.identity;
        rect.anchorMin = min; rect.anchorMax = max;
        rect.offsetMin = rect.offsetMax = Vector2.zero;
    }

    public static void ScaleCanvas(Canvas canvas)
    {
        CanvasScaler scaler = canvas.GetComponent<CanvasScaler>();
        if (scaler == null) scaler = canvas.gameObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;
    }

    public static RectTransform Panel(string name, Transform parent, Vector2 min, Vector2 max, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        RectTransform rect = go.GetComponent<RectTransform>();
        Place(rect, parent, min, max);
        Image image = go.GetComponent<Image>();
        image.color = color;
        image.raycastTarget = false;
        return rect;
    }

    public static void Style(TMP_Text text, Transform parent, Vector2 min, Vector2 max,
        float size, Color color, TextAlignmentOptions alignment = TextAlignmentOptions.Center)
    {
        Place(text.rectTransform, parent, min, max);
        text.alignment = alignment;
        text.color = color;
        text.fontSize = size;
        text.enableAutoSizing = true;
        text.fontSizeMin = size * 0.65f;
        text.fontSizeMax = size;
        text.margin = new Vector4(8f, 3f, 8f, 3f);
        text.raycastTarget = false;
    }

    public static TMP_Text Label(string name, Transform parent, TMP_FontAsset font, string value,
        Vector2 min, Vector2 max, float size, Color color)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer));
        TMP_Text text = go.AddComponent<TextMeshProUGUI>();
        text.font = font != null ? font : MenuFont != null ? MenuFont : TMP_Settings.defaultFontAsset;
        text.text = value;
        Style(text, parent, min, max, size, color);
        return text;
    }

    public static Button Button(string name, Transform parent, Button template, TMP_FontAsset font,
        string value, Vector2 min, Vector2 max, UnityEngine.Events.UnityAction action)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
        Place(go.GetComponent<RectTransform>(), parent, min, max);
        Image image = go.GetComponent<Image>();
        if (template != null && template.image != null)
        {
            image.sprite = template.image.sprite;
            image.type = template.image.type;
            image.color = template.image.color;
        }
        else image.color = new Color(0.9f, 0.43f, 0.12f);
        Button button = go.GetComponent<Button>();
        button.targetGraphic = image;
        button.onClick.AddListener(action);
        Label(name + "Text", go.transform, font, value, new Vector2(0.04f, 0.1f), new Vector2(0.96f, 0.9f), 34f, Color.white);
        return button;
    }
}
