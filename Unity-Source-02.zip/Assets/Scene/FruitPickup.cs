using UnityEngine;

public class FruitPickup : MonoBehaviour
{
    public int scoreValue = 10;
    private bool resolved;

    private void OnTriggerEnter2D(Collider2D other) => HandleContact(other.gameObject);
    private void OnCollisionEnter2D(Collision2D collision) => HandleContact(collision.gameObject);

    private void HandleContact(GameObject other)
    {
        if (resolved || other == null) return;
        if (other.CompareTag("Ground")) { MarkMissed(); return; }
        if (!other.CompareTag("Player")) return;
        RepelledPickup repelled = GetComponent<RepelledPickup>();
        if (repelled != null && repelled.BlocksPlayerContact) return;
        resolved = true;
        int awarded = GameData.CatchFruit(scoreValue);
        if (awarded > 0) GameAudio.Fruit(GameData.combo);
        if (awarded > 0 && ComboFeedback.Instance != null)
        {
            ComboFeedback.Instance.ShowCatch(GameData.combo, awarded, GameData.ComboMultiplier);
        }
        Destroy(gameObject);
    }

    public void MarkMissed()
    {
        // Ground and off-screen checks can resolve a fruit in the same frame.
        if (resolved) return;
        resolved = true;
        GameData.MissFruit();
        Destroy(gameObject);
    }
}
