using UnityEngine;

public static class CharacterCatalog
{
    public static int Selection => Mathf.Clamp(PlayerPrefs.GetInt("Game.Character", 0), 0, 2);
    public static CatchCharacter Load(int index) => index < 0 || index > 2 ? null : Resources.Load<CatchCharacter>("Characters/Character" + index);
    public static string Name(int index) => index == 0 ? "Doki" : Load(index) != null ? Load(index).displayName : index == 1 ? "Addergul" : "Speckle";
    public static void Select(int index) { PlayerPrefs.SetInt("Game.Character", Mathf.Clamp(index, 0, 2)); PlayerPrefs.Save(); }
}
