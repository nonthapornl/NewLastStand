using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameSessionManager : MonoBehaviour
{
    [Header("Game Session")]
    private const float MatchDurationSeconds = GameData.MatchDurationSeconds;
    private const string GameSceneName = "Play scene";

    private float remainingTime;
    private bool gameEnded;
    private int lastWarningSecond = -1;
    private float nextDamageTime;

    private Canvas hudCanvas;
    [SerializeField] private Text timerText;
    [SerializeField] private Sprite heartIcon;
    private Image[] lifeImages;
    private static Sprite proceduralHeartSprite;
    private Text inputStatusText;
    private Text performanceText;
    private Text compactHintText;
    private Text shieldStatusText;
    private PotionEffectState potionEffects => GameData.Potions;
    private MpuHandInput handInput;
    private UltrasonicFruitMagnet fruitMagnet;
    private PlayerMovement playerMovement;
    private MediaPipeHandInput cameraInput;
    private HandPoseGraphic leftPose, rightPose;
    private Text leftPoseLabel, rightPoseLabel;
    private SpriteRenderer gameplayBackground;
    private Camera backgroundCamera;
    [SerializeField] private BoxCollider2D gameplayFloor;
    private float originalFloorWidth;
    private Vector3 backgroundBaseScale, backgroundBaseCenter;
    private Vector2 backgroundBaseSize;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void EnsureSessionManagerExists()
    {
        EnsureSessionManagerExistsInScene(SceneManager.GetActiveScene());
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void RegisterSceneLoadHandler()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private static void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        EnsureSessionManagerExistsInScene(scene);
    }

    private static void EnsureSessionManagerExistsInScene(Scene scene)
    {
        if (scene.name != GameSceneName)
            return;

        if (FindObjectOfType<GameSessionManager>() != null)
            return;

        GameObject managerObject = new GameObject("GameSessionManager");
        managerObject.AddComponent<GameSessionManager>();
    }

    private void Start()
    {
        EnsureGameplayCamera();
        ApplySelectedBackground();
        if (gameplayFloor != null) originalFloorWidth = gameplayFloor.size.x;
        FitFloorToView();
        // Loading the gameplay scene starts a fresh round; pause/resume does
        // not reload this scene and therefore keeps its current countdown.
        GameData.BeginRound();
        remainingTime = MatchDurationSeconds;
        GameData.timeRemaining = remainingTime;
        GameData.lives = GameData.StartingLives;
        gameEnded = false;
        nextDamageTime = 0f;
        potionEffects.Reset();

        Time.timeScale = 1f;

        EnsureHud();
        EnsureLivesHud();
        EnsureControlsHint();
        EnsureObstacleSpawner();
        UpdateTimerDisplay();
    }

    public static void RegisterBombHit()
    {
        GameSessionManager manager = FindFirstObjectByType<GameSessionManager>();
        if (manager != null)
            manager.TakeBombHit();
    }

    private void TakeBombHit()
    {
        if (gameEnded || Time.time < nextDamageTime)
            return;

        if (potionEffects.TryBlock(Time.time))
        {
            GameAudio.Play("ShieldBlock", .55f, 1f, .15f, true);
            if (ComboFeedback.Instance != null) ComboFeedback.Instance.ShowMessage("SHIELD BLOCK!");
            UpdateShieldHud();
            return;
        }

        nextDamageTime = Time.time + 0.75f;
        GameData.HitBomb();
        GameAudio.Play("Hurt", .5f, 1f, .15f, true);
        GameData.lives = Mathf.Max(0, GameData.lives - 1);
        UpdateLivesHud();
        Debug.Log("Player hit by a bomb. Hearts remaining: " + GameData.lives);

        if (GameData.lives == 0)
            StartCoroutine(EndGameAfterExplosion());
    }

    private System.Collections.IEnumerator EndGameAfterExplosion()
    {
        gameEnded = true;
        GameData.StopScoring();
        ObstacleSpawner spawner = GetComponent<ObstacleSpawner>();
        if (spawner != null)
            spawner.enabled = false;

        yield return new WaitForSecondsRealtime(0.6f);
        CompleteGame();
    }

    private void EnsureObstacleSpawner()
    {
        if (GetComponent<ObstacleSpawner>() == null)
            gameObject.AddComponent<ObstacleSpawner>();
        if (GetComponent<PotionSpawner>() == null)
            gameObject.AddComponent<PotionSpawner>();
    }

    public static bool TryCollectPotion(PotionKind kind)
    {
        GameSessionManager manager = FindFirstObjectByType<GameSessionManager>();
        if (manager == null || manager.gameEnded || !GameData.RoundActive) return false;
        if (!manager.potionEffects.TryUse(kind, GameData.lives, GameData.StartingLives, Time.time, out int lives))
            return false;
        GameData.lives = lives;
        GameAudio.Potion(kind);
        manager.UpdateLivesHud();
        manager.UpdateShieldHud();
        if (ComboFeedback.Instance != null)
            ComboFeedback.Instance.ShowMessage(kind == PotionKind.Health ? "+1 HEART" : kind == PotionKind.Shield ? "SHIELD READY!"
                : kind == PotionKind.DoubleScore ? "SCORE x2!" : kind == PotionKind.Haste ? "SPEED UP!"
                : kind == PotionKind.Shrink ? "POISON: SHRINK!" : kind == PotionKind.Sluggish ? "POISON: SLOW!"
                : kind == PotionKind.Confuse ? "POISON: REVERSE!" : "SLOW FALL!");
        return true;
    }

    private void UpdateShieldHud()
    {
        if (shieldStatusText == null) return;
        float now = Time.time;
        string status = "";
        AppendPotionStatus(ref status, "SHIELD", potionEffects.ShieldRemaining(now));
        AppendPotionStatus(ref status, "x2", potionEffects.ScoreRemaining(now));
        AppendPotionStatus(ref status, "SPEED", potionEffects.HasteRemaining(now));
        AppendPotionStatus(ref status, "SLOW", potionEffects.SlowRemaining(now));
        AppendPotionStatus(ref status, "<color=#FF7979>SHRINK</color>", potionEffects.ShrinkRemaining(now));
        AppendPotionStatus(ref status, "<color=#FF7979>SLUGGISH</color>", potionEffects.SluggishRemaining(now));
        AppendPotionStatus(ref status, "<color=#FF7979>REVERSE</color>", potionEffects.ConfuseRemaining(now));
        shieldStatusText.enabled = status.Length > 0 && GameData.RoundActive;
        shieldStatusText.text = status;
    }

    private static void AppendPotionStatus(ref string status, string name, float remaining)
    {
        if (remaining <= 0f) return;
        if (status.Length > 0) status += "   ";
        status += name + " " + Mathf.CeilToInt(remaining) + "s";
    }

    private void EnsureLivesHud()
    {
        GameObject canvasObject = new GameObject("LivesHudCanvas");
        Canvas livesCanvas = canvasObject.AddComponent<Canvas>();
        livesCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        livesCanvas.sortingOrder = 30;
        CanvasScaler scaler = canvasObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;
        canvasObject.AddComponent<GraphicRaycaster>();

        lifeImages = new Image[GameData.StartingLives];
        for (int i = 0; i < lifeImages.Length; i++)
        {
            GameObject heartObject = new GameObject("Heart " + (i + 1), typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            heartObject.transform.SetParent(canvasObject.transform, false);

            RectTransform heartRect = heartObject.GetComponent<RectTransform>();
            heartRect.anchorMin = new Vector2(0.84f, 1f);
            heartRect.anchorMax = new Vector2(0.84f, 1f);
            heartRect.anchoredPosition = new Vector2((i - 1) * 56f, -230f);
            heartRect.sizeDelta = new Vector2(52f, 52f);

            Image heartImage = heartObject.GetComponent<Image>();
            heartImage.sprite = GetHeartSprite();
            heartImage.raycastTarget = false;
            lifeImages[i] = heartImage;
        }

        shieldStatusText = CreateHintText("ShieldStatus", canvasObject.transform,
            timerText != null ? timerText.font : Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"),
            Vector2.zero, new Vector2(1400f, 48f), 23);
        shieldStatusText.resizeTextForBestFit = true;
        shieldStatusText.resizeTextMinSize = 16;
        shieldStatusText.resizeTextMaxSize = 23;
        shieldStatusText.rectTransform.anchorMin = shieldStatusText.rectTransform.anchorMax = new Vector2(0.5f, 1f);
        shieldStatusText.rectTransform.anchoredPosition = new Vector2(0f, -357f);
        shieldStatusText.color = new Color(0.48f, 0.88f, 1f);
        shieldStatusText.enabled = false;
        UpdateLivesHud();
    }

    private void UpdateLivesHud()
    {
        if (lifeImages == null)
            return;

        for (int i = 0; i < lifeImages.Length; i++)
            lifeImages[i].enabled = i < GameData.lives;
    }

    private void EnsureControlsHint()
    {
        // Use the same pixel font as the scene's timer/name/score.
        Font font = timerText != null ? timerText.font : null;
        if (font == null)
        {
            HUDManager hud = FindFirstObjectByType<HUDManager>();
            if (hud != null && hud.usernameText != null) font = hud.usernameText.font;
        }
        if (font == null) font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (GameUiLayout.MenuFont == null) GameUiLayout.MenuFont = TMPro.TMP_FontAsset.CreateFontAsset(font);

        GameObject canvasObject = new GameObject("ControlsHintCanvas");
        Canvas controlsCanvas = canvasObject.AddComponent<Canvas>();
        controlsCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        controlsCanvas.sortingOrder = 25;
        canvasObject.AddComponent<GraphicRaycaster>();
        CanvasScaler scaler = canvasObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;

        HUDManager hudLayout = FindFirstObjectByType<HUDManager>();
        if (hudLayout != null) hudLayout.ConfigureLayout(canvasObject.transform, GameUiLayout.MenuFont);
        HUDManager.PlaceHudText(timerText, canvasObject.transform,
            new Vector2(.03f, .755f), new Vector2(.30f, .805f));

        // Keep one original Pause button in the upper right corner.
        NormalizePauseButton(canvasObject.transform);
        RectTransform status = CreateHintPanel("InputStatus", canvasObject.transform,
            new Vector2(0.5f, 1f), new Vector2(0f, -230f), new Vector2(740f, 40f),
            new Color(0.06f, 0.14f, 0.18f, 0.48f));
        inputStatusText = CreateHintText("InputStatusText", status, font,
            Vector2.zero, Vector2.zero, 24);
        FitHintText(inputStatusText);
        if (GamePreferences.Controls == ControlScheme.Camera)
        {
            RectTransform hands = CreateHintPanel("Camera hands", canvasObject.transform,
                new Vector2(1f, 0f), new Vector2(-137f, 118f), new Vector2(222f, 154f),
                new Color(.06f, .14f, .18f, .82f));
            leftPose = CreateHandPose(hands, font, 0f, .5f, out leftPoseLabel);
            rightPose = CreateHandPose(hands, font, .5f, 1f, out rightPoseLabel);
        }

        RectTransform performance = CreateHintPanel("CatchPerformance", canvasObject.transform,
            new Vector2(0.5f, 1f), new Vector2(0f, -276f), new Vector2(740f, 38f),
            new Color(0.06f, 0.14f, 0.18f, 0.48f));
        performanceText = CreateHintText("CatchPerformanceText", performance, font,
            Vector2.zero, Vector2.zero, 24);
        FitHintText(performanceText);

        compactHintText = CreateHintText("CompactControlsHint", canvasObject.transform, font,
            Vector2.zero, Vector2.zero, 24);
        compactHintText.rectTransform.anchorMin = new Vector2(0.05f, 1f);
        compactHintText.rectTransform.anchorMax = new Vector2(0.95f, 1f);
        compactHintText.rectTransform.offsetMin = new Vector2(0f, -333f);
        compactHintText.rectTransform.offsetMax = new Vector2(0f, -300f);
        compactHintText.resizeTextForBestFit = true;
        compactHintText.resizeTextMinSize = 16;
        compactHintText.resizeTextMaxSize = 24;
        compactHintText.text = GamePreferences.ShortHint;

        handInput = FindFirstObjectByType<MpuHandInput>();
        fruitMagnet = handInput != null ? handInput.GetComponent<UltrasonicFruitMagnet>() : null;
        playerMovement = handInput != null ? handInput.GetComponent<PlayerMovement>() : null;
        UpdateInputStatus();
    }

    private static void FitHintText(Text text)
    {
        text.rectTransform.anchorMin = Vector2.zero;
        text.rectTransform.anchorMax = Vector2.one;
        text.rectTransform.offsetMin = new Vector2(10f, 2f);
        text.rectTransform.offsetMax = new Vector2(-10f, -2f);
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 16;
        text.resizeTextMaxSize = 24;
    }

    private static HandPoseGraphic CreateHandPose(Transform parent, Font font, float left, float right, out Text label)
    {
        var graphic = new GameObject("Tracked hand", typeof(RectTransform), typeof(CanvasRenderer), typeof(HandPoseGraphic))
            .GetComponent<HandPoseGraphic>();
        GameUiLayout.Place(graphic.rectTransform, parent, new Vector2(left, .23f), new Vector2(right, .97f));
        graphic.raycastTarget = false;
        label = CreateHintText("Gesture label", parent, font, Vector2.zero, Vector2.zero, 19);
        GameUiLayout.Place(label.rectTransform, parent, new Vector2(left, .02f), new Vector2(right, .23f));
        return graphic;
    }

    private static void UpdateHandPose(HandPoseGraphic graphic, Text label, string side, string gesture, int[] points)
    {
        if (graphic == null) return;
        Color tint = gesture == "OK" ? new Color(1f, .79f, .38f)
            : gesture == "V" ? new Color(.85f, .68f, 1f)
            : gesture == "FIST" ? new Color(.48f, .94f, .67f)
            : new Color(.67f, .86f, 1f);
        graphic.Show(points, tint);
        label.color = tint;
        string text = side + " " + gesture;
        if (label.text != text) label.text = text;
    }

    private void NormalizePauseButton(Transform parent)
    {
        foreach (PauseMenu menu in FindObjectsByType<PauseMenu>(FindObjectsSortMode.None))
        {
            Button button = menu.GetComponent<Button>();
            if (button == null || menu.gameObject.scene.name != GameSceneName) continue;
            RectTransform rect = button.GetComponent<RectTransform>();
            rect.SetParent(parent, false);
            rect.localScale = Vector3.one;
            // The scene's original pivot is far outside its rectangle. Reset it
            // before anchoring; otherwise the icon appears in the playfield.
            rect.pivot = new Vector2(1f, 1f);
            rect.anchorMin = rect.anchorMax = Vector2.one;
            rect.anchoredPosition = new Vector2(-48f, -208f);
            rect.sizeDelta = new Vector2(56f, 56f);
        }
    }

    private static RectTransform CreateHintPanel(string label, Transform parent, Vector2 anchor,
        Vector2 position, Vector2 size, Color color)
    {
        GameObject panel = new GameObject(label, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        panel.transform.SetParent(parent, false);
        RectTransform rect = panel.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = anchor;
        rect.anchoredPosition = position;
        rect.sizeDelta = size;
        Image image = panel.GetComponent<Image>();
        image.color = color;
        image.raycastTarget = false;
        return rect;
    }

    private static Text CreateHintText(string label, Transform parent, Font font, Vector2 position,
        Vector2 size, int fontSize)
    {
        GameObject item = new GameObject(label, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
        item.transform.SetParent(parent, false);
        RectTransform rect = item.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.anchoredPosition = position;
        rect.sizeDelta = size;
        Text text = item.GetComponent<Text>();
        text.font = font;
        text.fontSize = fontSize;
        text.alignment = TextAnchor.MiddleCenter;
        text.color = Color.white;
        text.supportRichText = true;
        text.raycastTarget = false;
        return text;
    }

    private void UpdateInputStatus()
    {
        if (compactHintText != null) compactHintText.gameObject.SetActive(GamePreferences.ShowHints);
        if (inputStatusText == null) return;
        if (handInput == null) handInput = FindFirstObjectByType<MpuHandInput>();
        if (fruitMagnet == null && handInput != null) fruitMagnet = handInput.GetComponent<UltrasonicFruitMagnet>();
        if (playerMovement == null && handInput != null) playerMovement = handInput.GetComponent<PlayerMovement>();
        if (GamePreferences.Controls == ControlScheme.Camera && cameraInput == null && playerMovement != null)
            cameraInput = playerMovement.GetComponent<MediaPipeHandInput>();
        inputStatusText.transform.parent.gameObject.SetActive(fruitMagnet == null || fruitMagnet.showStatus);
        int power = fruitMagnet != null ? Mathf.RoundToInt(fruitMagnet.Power * 100f) : 0;
        string left = HandStatus("Left", handInput != null && handInput.LeftHandValid,
            handInput != null && handInput.LeftHandRaised);
        string right = HandStatus("Right", handInput != null && handInput.RightHandValid,
            handInput != null && handInput.RightHandRaised);
        string skill = playerMovement != null && playerMovement.SkillActive
            ? "Skill <color=#FFE09A>ON</color>" : "Skill OFF";
        string controller = GamePreferences.Controls == ControlScheme.Gyro ? left + "  |  " + right
            : GamePreferences.Controls == ControlScheme.Joystick
            ? "JOY " + (handInput != null && handInput.StickConnected ? "LIVE" : "WAIT") : "KEYBOARD";
        if (GamePreferences.Controls == ControlScheme.Camera)
        {
            UpdateHandPose(leftPose, leftPoseLabel, "L", cameraInput?.LeftGesture ?? "--", cameraInput?.LeftPoints);
            UpdateHandPose(rightPose, rightPoseLabel, "R", cameraInput?.RightGesture ?? "--", cameraInput?.RightPoints);
            if (cameraInput == null || !cameraInput.Connected) controller = "CAM WAIT BRIDGE";
            else if (!cameraInput.CameraLive) controller = "CAM WAIT STREAM";
            else
            {
                int dash = playerMovement.DashDirection;
                float move = playerMovement.HorizontalIntent;
                string action = dash < 0 ? "DASH LEFT" : dash > 0 ? "DASH RIGHT"
                    : move < 0f ? "MOVE LEFT" : move > 0f ? "MOVE RIGHT" : "STOP";
                controller = "CAM  |  L " + cameraInput.LeftGesture + "  |  R " + cameraInput.RightGesture + "  |  " + action;
            }
        }
        inputStatusText.text = "MAGNET " + power + "% " + (fruitMagnet != null && fruitMagnet.UsingManualPower ? "MANUAL" : "SENSOR") + "  |  " + controller + "  |  " + skill;
        if (GamePreferences.Controls == ControlScheme.Joystick)
        {
            PiezoShockwave pulse = handInput != null ? handInput.GetComponent<PiezoShockwave>() : null;
            string pulseStatus = pulse == null || !pulse.SensorLive ? "WAIT"
                : pulse.IsFlashing ? "PUSH!" : pulse.CooldownRemaining > 0f
                ? pulse.CooldownRemaining.ToString("0.0") + "s" : "READY";
            inputStatusText.text += "  |  PULSE " + pulseStatus;
        }
    }

    private static string HandStatus(string label, bool valid, bool raised)
    {
        if (!valid) return label + " --";
        return label + (raised ? " <color=#91EDB3>UP</color>" : " DOWN");
    }

    private Sprite GetHeartSprite()
    {
        if (heartIcon != null)
            return heartIcon;

        if (proceduralHeartSprite != null)
            return proceduralHeartSprite;

        const int size = 32;
        Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
        texture.filterMode = FilterMode.Point;
        texture.wrapMode = TextureWrapMode.Clamp;
        Color red = new Color(0.95f, 0.08f, 0.16f, 1f);
        texture.SetPixels(new Color[size * size]);

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                bool leftLobe = (x - 9) * (x - 9) + (y - 21) * (y - 21) <= 81;
                bool rightLobe = (x - 23) * (x - 23) + (y - 21) * (y - 21) <= 81;
                bool lowerPoint = y <= 19 && x >= 4 + (19 - y) / 2 && x <= 28 - (19 - y) / 2;
                if (leftLobe || rightLobe || lowerPoint)
                    texture.SetPixel(x, y, red);
            }
        }

        texture.Apply();
        proceduralHeartSprite = Sprite.Create(texture, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f), size);
        return proceduralHeartSprite;
    }

    private void EnsureGameplayCamera()
    {
        Camera[] cameras = FindObjectsByType<Camera>(
            FindObjectsInactive.Include,
            FindObjectsSortMode.None
        );

        Camera gameplayCamera = null;
        foreach (Camera candidate in cameras)
        {
            if (candidate.CompareTag("MainCamera"))
            {
                gameplayCamera = candidate;
                break;
            }

            if (gameplayCamera == null)
                gameplayCamera = candidate;
        }

        if (gameplayCamera != null)
        {
            if (!gameplayCamera.gameObject.activeSelf)
                gameplayCamera.gameObject.SetActive(true);

            gameplayCamera.enabled = true;
            backgroundCamera = gameplayCamera;
            return;
        }

        GameObject cameraObject = new GameObject("Main Camera");
        cameraObject.tag = "MainCamera";
        cameraObject.transform.position = new Vector3(transform.position.x, transform.position.y, -10f);

        Camera fallbackCamera = cameraObject.AddComponent<Camera>();
        backgroundCamera = fallbackCamera;
        fallbackCamera.orthographic = true;
        fallbackCamera.orthographicSize = 200f;

        Debug.LogWarning("No scene camera was available. Created a fallback 2D camera.", cameraObject);
    }

    private void ApplySelectedBackground()
    {
        gameplayBackground = GetComponent<SpriteRenderer>();
        if (gameplayBackground == null) return;
        if (GameData.selectedBackgroundSprite != null)
            gameplayBackground.sprite = GameData.selectedBackgroundSprite;
        backgroundBaseScale = gameplayBackground.transform.localScale;
        backgroundBaseCenter = gameplayBackground.bounds.center;
        backgroundBaseSize = gameplayBackground.bounds.size;
        FitBackgroundToView();
    }

    private void LateUpdate() => FitBackgroundToView();

    private void FixedUpdate() => FitFloorToView();

    private void FitFloorToView()
    {
        if (gameplayFloor == null || backgroundCamera == null || !backgroundCamera.orthographic)
            return;

        // Keep the same surface height and extend its solid collider past both edges.
        float halfViewWidth = backgroundCamera.orthographicSize * backgroundCamera.aspect;
        Transform floor = gameplayFloor.transform;
        float scaleX = Mathf.Abs(floor.lossyScale.x);
        if (scaleX <= 0f) return;
        float floorCenterX = floor.TransformPoint(gameplayFloor.offset).x;
        float distanceFromCenter = Mathf.Abs(backgroundCamera.transform.position.x - floorCenterX);
        float width = Mathf.Max(originalFloorWidth, (halfViewWidth + distanceFromCenter + 1f) * 2f / scaleX);
        Vector2 size = gameplayFloor.size;
        if (!Mathf.Approximately(size.x, width))
            gameplayFloor.size = new Vector2(width, size.y);
    }

    private void FitBackgroundToView()
    {
        if (gameplayBackground == null || backgroundCamera == null || !backgroundCamera.enabled ||
            !backgroundCamera.orthographic || backgroundBaseSize.x <= 0f || backgroundBaseSize.y <= 0f)
            return;

        float height = backgroundCamera.orthographicSize * 2f;
        Vector2 view = new Vector2(height * backgroundCamera.aspect, height);
        float scale = Mathf.Max(1f, view.x / backgroundBaseSize.x, view.y / backgroundBaseSize.y);
        Transform background = gameplayBackground.transform;
        background.localScale = new Vector3(backgroundBaseScale.x * scale,
            backgroundBaseScale.y * scale, backgroundBaseScale.z);

        Vector2 slack = Vector2.Max(Vector2.zero, (backgroundBaseSize * scale - view) * .5f);
        Vector3 cameraCenter = backgroundCamera.transform.position;
        Vector3 center = gameplayBackground.bounds.center;
        center.x = Mathf.Clamp(backgroundBaseCenter.x, cameraCenter.x - slack.x, cameraCenter.x + slack.x);
        center.y = Mathf.Clamp(backgroundBaseCenter.y, cameraCenter.y - slack.y, cameraCenter.y + slack.y);
        background.position += center - gameplayBackground.bounds.center;
    }

    private void Update()
    {
        UpdateShieldHud();
        UpdateInputStatus();
        if (performanceText != null)
        {
            string accuracy = GameData.caught + GameData.missed == 0 ? "--" : GameData.Accuracy.ToString("0") + "%";
            performanceText.text = "CAUGHT " + GameData.caught + "  |  MISS " + GameData.missed
                + "  |  ACC " + accuracy + "  |  <color=#FFE09A>COMBO " + GameData.combo
                + " x" + GameData.ComboMultiplier.ToString("0.##") + "</color>"
                + (DifficultyProfile.FinalRush ? "  <color=#FFE09A>FINAL RUSH!</color>" : "");
        }
        if (gameEnded)
            return;

        remainingTime -= Time.deltaTime;
        int warningSecond = Mathf.CeilToInt(remainingTime);
        if (warningSecond > 0 && warningSecond <= 10 && warningSecond != lastWarningSecond)
        {
            lastWarningSecond = warningSecond;
            GameAudio.Play("Warning", .25f, warningSecond <= 3 ? 1.2f : 1f, .5f, true);
        }
        if (remainingTime <= 0f)
        {
            remainingTime = 0f;
            EndGame();
            return;
        }

        GameData.timeRemaining = remainingTime;
        UpdateTimerDisplay();
    }

    public static void StopCurrentRound()
    {
        GameData.StopScoring();
        GameSessionManager[] managers = FindObjectsByType<GameSessionManager>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (GameSessionManager manager in managers)
            manager.gameEnded = true;
    }

    private void EnsureHud()
    {
        if (timerText != null)
            return;

        GameObject existingTimer = GameObject.Find("TimeText");
        if (existingTimer != null)
            timerText = existingTimer.GetComponent<Text>();

        if (timerText != null)
            return;

        GameObject canvasObject = new GameObject("GameSessionHudCanvas");
        Transform canvasTransform = canvasObject.transform;

        hudCanvas = canvasObject.AddComponent<Canvas>();
        hudCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObject.AddComponent<CanvasScaler>();
        canvasObject.AddComponent<GraphicRaycaster>();

        GameObject timerObject = new GameObject("TimeText");
        timerObject.transform.SetParent(canvasTransform, false);

        RectTransform timerRect = timerObject.AddComponent<RectTransform>();
        timerRect.anchorMin = new Vector2(0.02f, 0.93f);
        timerRect.anchorMax = new Vector2(0.3f, 1f);
        timerRect.offsetMin = Vector2.zero;
        timerRect.offsetMax = Vector2.zero;

        timerText = timerObject.AddComponent<Text>();
        timerText.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        timerText.fontSize = 28;
        timerText.alignment = TextAnchor.MiddleLeft;
        timerText.color = Color.white;
        timerText.text = "TIME: " + Mathf.CeilToInt(MatchDurationSeconds);
    }

    private void UpdateTimerDisplay()
    {
        if (timerText != null)
        {
            int totalSeconds = Mathf.CeilToInt(Mathf.Max(0f, remainingTime));
            timerText.text = "TIME: " + (totalSeconds / 60).ToString("00") + ":" + (totalSeconds % 60).ToString("00");
            timerText.color = remainingTime <= 15f ? new Color(1f, 0.36f, 0.3f) : Color.white;
        }
    }

    private void EndGame()
    {
        if (gameEnded)
            return;

        gameEnded = true;
        CompleteGame();
    }

    private void CompleteGame()
    {
        ObstacleSpawner spawner = GetComponent<ObstacleSpawner>();
        if (spawner != null)
            spawner.enabled = false;
        GameData.timeRemaining = remainingTime;
        GameData.PrepareCompletedRun();
        GameData.RunRecord completedRun = GameData.RecordPendingCompletedRun();
        if (completedRun != null)
            GoogleSheetsReporter.Submit(completedRun, true);
        GameData.timeRemaining = 0f;
        Time.timeScale = 1f;
        SceneManager.LoadScene("RetryScene");
    }
}
