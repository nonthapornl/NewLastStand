public readonly struct DifficultyProfile
{
    public readonly string Name;
    public readonly float FruitMin, FruitMax, FruitGravity, BombMin, BombMax, BombGravity, ScoreMultiplier;

    private DifficultyProfile(string name, float fruitMin, float fruitMax, float fruitGravity,
        float bombMin, float bombMax, float bombGravity, float scoreMultiplier)
    {
        Name = name; FruitMin = fruitMin; FruitMax = fruitMax; FruitGravity = fruitGravity;
        BombMin = bombMin; BombMax = bombMax; BombGravity = bombGravity; ScoreMultiplier = scoreMultiplier;
    }

    // Preserve the serialized Normal value used by existing scenes.
    public static DifficultyProfile For(FruitSpeedLevel level) => level switch
    {
        FruitSpeedLevel.Easy => new DifficultyProfile("Easy", 0.95f, 1.35f, 0.8f, 8f, 11f, 0.8f, 1f),
        FruitSpeedLevel.Hard => new DifficultyProfile("Hard", 0.30f, 0.50f, 3.2f, 1.8f, 2.8f, 2.8f, 1.5f),
        _ => new DifficultyProfile("Medium", 0.55f, 0.80f, 1.8f, 4f, 6f, 1.6f, 1.25f)
    };

    public static bool FinalRush => GameData.timeRemaining > 0f && GameData.timeRemaining <= 30f;
    public static float SpawnTempo => FinalRush ? 0.8f : 1f;
    public static float FallTempo => FinalRush ? 1.15f : 1f;
}
