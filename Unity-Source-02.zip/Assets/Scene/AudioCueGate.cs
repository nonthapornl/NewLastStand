using System.Collections.Generic;

// Uses an unscaled clock: menu/pause feedback remains responsive at timeScale zero.
public sealed class AudioCueGate
{
    private readonly Dictionary<string, float> next = new Dictionary<string, float>();
    public bool Allow(string cue, float now, float interval)
    {
        if (float.IsNaN(now) || float.IsInfinity(now)) return false;
        if (next.TryGetValue(cue, out float time) && now < time) return false;
        next[cue] = now + System.Math.Max(0f, interval);
        return true;
    }
    public void Reset() => next.Clear();
}
