using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

// Windows USB/UART serial access without a System.IO.Ports dependency.
internal sealed class ESP32WindowsSerial : IDisposable
{
    private readonly string portName;
    private readonly int baudRate;
    private readonly bool dtrEnable;
    private IntPtr handle = new IntPtr(-1);
    private readonly byte[] buffer = new byte[4096];
    public bool IsOpen { get { return handle != new IntPtr(-1); } }

    public ESP32WindowsSerial(string name, int baud, bool enableDtr = false)
    {
        portName = name;
        baudRate = baud;
        dtrEnable = enableDtr;
    }

    public void Open()
    {
#if UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN
        if (IsOpen) return;
        if (string.IsNullOrWhiteSpace(portName) || baudRate <= 0)
            throw new ArgumentException("Invalid COM port or baud rate.");
        handle = CreateFile(@"\\.\" + portName.Trim(), 0xC0000000u,
            0, IntPtr.Zero, 3, 0, IntPtr.Zero);
        if (!IsOpen) throw Error("Open " + portName);
        try
        {
            Dcb state = new Dcb();
            state.Length = (uint)Marshal.SizeOf(typeof(Dcb));
            if (!GetCommState(handle, ref state)) throw Error("GetCommState");
            state.BaudRate = (uint)baudRate;
            // Binary, no hardware flow control. Native USB boards (UNO R4)
            // require DTR to read/write; ESP32 UART users keep the default off.
            state.Flags = 1u | (dtrEnable ? 0x10u : 0u);
            state.ByteSize = 8;
            state.Parity = 0;
            state.StopBits = 0;
            if (!SetCommState(handle, ref state)) throw Error("SetCommState");
            // Return bytes already buffered immediately, including zero bytes.
            CommTimeouts timeouts = new CommTimeouts();
            timeouts.ReadIntervalTimeout = uint.MaxValue;
            timeouts.WriteTotalTimeoutConstant = 100;
            if (!SetCommTimeouts(handle, ref timeouts)) throw Error("SetCommTimeouts");
            DiscardInBuffer();
        }
        catch { Dispose(); throw; }
#else
        throw new PlatformNotSupportedException("ESP32 serial input requires Windows.");
#endif
    }

    public string ReadExisting()
    {
        if (!IsOpen) throw new InvalidOperationException("Serial port is closed.");
        uint count;
        if (!ReadFile(handle, buffer, (uint)buffer.Length, out count, IntPtr.Zero))
            throw Error("ReadFile");
        return count == 0 ? string.Empty : Encoding.ASCII.GetString(buffer, 0, (int)count);
    }

    public void WriteLine(string line)
    {
        if (!IsOpen) throw new InvalidOperationException("Serial port is closed.");
        byte[] data = Encoding.ASCII.GetBytes(line + "\n");
        uint written;
        if (!WriteFile(handle, data, (uint)data.Length, out written, IntPtr.Zero))
            throw Error("WriteFile");
        if (written != (uint)data.Length)
            throw new InvalidOperationException("Serial write timed out before the full command was sent.");
    }
    public void DiscardInBuffer()
    {
        if (IsOpen && !PurgeComm(handle, 8)) throw Error("PurgeComm");
    }

    public void Dispose()
    {
        if (!IsOpen) return;
        CloseHandle(handle);
        handle = new IntPtr(-1);
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool WriteFile(IntPtr file, byte[] data,
        uint length, out uint written, IntPtr overlapped);
    private static Win32Exception Error(string operation)
    {
        int code = Marshal.GetLastWin32Error();
        return new Win32Exception(code, operation + ": " + new Win32Exception(code).Message);
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Dcb
    {
        public uint Length, BaudRate, Flags;
        public ushort Reserved, XonLim, XoffLim;
        public byte ByteSize, Parity, StopBits;
        public byte XonChar, XoffChar, ErrorChar, EofChar, EvtChar;
        public ushort Reserved1;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct CommTimeouts
    {
        public uint ReadIntervalTimeout, ReadTotalTimeoutMultiplier, ReadTotalTimeoutConstant;
        public uint WriteTotalTimeoutMultiplier, WriteTotalTimeoutConstant;
    }

    [DllImport("kernel32.dll", EntryPoint = "CreateFileW", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateFile(string name, uint access, uint share,
        IntPtr security, uint disposition, uint flags, IntPtr template);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetCommState(IntPtr file, ref Dcb state);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetCommState(IntPtr file, ref Dcb state);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetCommTimeouts(IntPtr file, ref CommTimeouts timeouts);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ReadFile(IntPtr file, [Out] byte[] data,
        uint capacity, out uint count, IntPtr overlapped);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool PurgeComm(IntPtr file, uint flags);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CloseHandle(IntPtr file);
}
