using System;

using UnityEngine;

// Read before PlayerMovement.Update each frame.
[DefaultExecutionOrder(-100)]
public class ESP32JoystickInput : MonoBehaviour
{
    [Tooltip("Use the port shown in Arduino IDE > Tools > Port, e.g. COM5")]
    public string portName = "COM9";
    public int baudRate = 115200;
    public float disconnectTimeout = 0.3f;

    public int Horizontal { get; private set; }
    public int Vertical { get; private set; }
    public bool ButtonHeld { get; private set; }
    public bool JumpPressed { get; private set; }
    public int DashDirection { get; private set; }
    public bool Connected { get; private set; }

    private ESP32WindowsSerial port;
    private string pending = "";
    private float lastPacketTime;

    private void OnEnable()
    {
        ClearInput();
        pending = "";
        try
        {
            port = new ESP32WindowsSerial(portName, baudRate);
            port.Open();
            port.DiscardInBuffer();
            Debug.Log("ESP32: opened " + portName + ". Waiting for joystick data.", this);
        }
        catch (Exception e)
        {
            Debug.LogWarning("ESP32: " + e.Message +
                " Check COM port and close Arduino Serial Monitor. Toggle this component to retry.", this);
            ClosePort();
        }
    }

    private void Update()
    {
        JumpPressed = false;
        DashDirection = 0;
        if (port == null || !port.IsOpen) return;

        try
        {
            // Read only available bytes; no blocking ReadLine on the game thread.
            pending += port.ReadExisting();
            if (pending.Length > 4096)
            {
                pending = "";
                ClearInput();
                return;
            }
            int newline;
            while ((newline = pending.IndexOf('\n')) >= 0)
            {
                string line = pending.Substring(0, newline).Trim();
                pending = pending.Substring(newline + 1);
                ApplyPacket(line);
            }
            if (Connected && Time.realtimeSinceStartup - lastPacketTime > disconnectTimeout)
                ClearInput();
        }
        catch (Exception e)
        {
            Debug.LogWarning("ESP32 disconnected: " + e.Message, this);
            ClosePort();
            ClearInput();
        }
    }

    private void ApplyPacket(string line)
    {
        string[] fields = line.Split(',');
        if (fields.Length != 4 || fields[0] != "J" ||
            !int.TryParse(fields[1], out int x) ||
            !int.TryParse(fields[2], out int y) ||
            !int.TryParse(fields[3], out int b) ||
            x < -1 || x > 1 || y < -1 || y > 1 || b < 0 || b > 1)
            return;

        bool pressed = b == 1;
        // Jump once when the stick enters UP; release before another jump.
        if (y == 1 && Vertical != 1) JumpPressed = true;
        // Dash once on button press OR on entering a direction with button held.
        if (pressed && x != 0 && (!ButtonHeld || Horizontal != x))
            DashDirection = x;
        Horizontal = x;
        Vertical = y;
        ButtonHeld = pressed;
        lastPacketTime = Time.realtimeSinceStartup;
        Connected = true;
    }

    private void ClearInput()
    {
        Horizontal = Vertical = DashDirection = 0;
        ButtonHeld = JumpPressed = Connected = false;
    }

    private void ClosePort()
    {
        if (port == null) return;
        try { port.Dispose(); }
        catch (Exception) { }
        port = null;
    }

    private void OnDisable()
    {
        ClosePort();
        ClearInput();
        pending = "";
    }
}
