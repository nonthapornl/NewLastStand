using UnityEngine;

public enum ControlScheme { Keyboard, Joystick, Gyro, Camera }

public static class GamePreferences
{
    public static float ManualMagnetPower => Mathf.Clamp01(PlayerPrefs.GetFloat("Game.ManualMagnetPower", .5f));
    public static void SetManualMagnetPower(float value)
    {
        PlayerPrefs.SetFloat("Game.ManualMagnetPower", Mathf.Clamp01(value));
        PlayerPrefs.Save();
    }
    public const string MagnetHelp = "Keyboard / Camera: adjust Magnet in Settings.\nJoystick / Gyro: sensor 5-70 cm; manual when no reading.\nPulls fruit, potions AND bombs!";
    public static float Volume => PlayerPrefs.GetFloat("Game.Volume", 1f);
    public static float MusicVolume => Mathf.Clamp01(PlayerPrefs.GetFloat("Game.MusicVolume", .55f));
    public static float EffectsVolume => Mathf.Clamp01(PlayerPrefs.GetFloat("Game.EffectsVolume", .8f));
    public static bool ShowHints => PlayerPrefs.GetInt("Game.ShowHints", 1) != 0;
    public static readonly string[] ControlLabels = { "Keyboard", "Joystick", "Gyro", "Camera" };
    public static int ControlCount => Application.platform == RuntimePlatform.WebGLPlayer ? 3 : ControlLabels.Length;
    public static ControlScheme Controls => (ControlScheme)Mathf.Clamp(PlayerPrefs.GetInt("Game.Controls", 2), 0, ControlCount - 1);
    public static string ControlName => ControlLabels[(int)Controls].ToUpperInvariant();
    public static bool UsesManualMagnet => Controls == ControlScheme.Keyboard || Controls == ControlScheme.Camera;
    public static string ShortHint => Controls == ControlScheme.Keyboard
        ? "A/D MOVE   W JUMP   S DROP   SHIFT + SIDE DASH   PAUSE > SETTINGS: HELP"
        : Controls == ControlScheme.Joystick ? "JOY: LEFT/RIGHT MOVE   UP JUMP   PRESS + LEFT/RIGHT DASH   TAP PIEZO: PULSE"
        : Controls == ControlScheme.Camera ? "CAMERA: FIST MOVE   OPEN STOP   OK DASH   V JUMP   S DROP"
        : "GYRO: ONE UP MOVE   BOTH UP JUMP   WAVE DASH   PAUSE > SETTINGS: HELP";

    public static string[] ControlActions(ControlScheme scheme) => scheme == ControlScheme.Keyboard
        ? new[] { "Move", "Jump", "Drop", "Dash" }
        : scheme == ControlScheme.Joystick ? new[] { "Move", "Jump", "Dash", "Pulse" }
        : scheme == ControlScheme.Camera ? new[] { "Move", "Stop", "Dash", "Jump / Drop" }
        : new[] { "Move", "Jump", "Dash", "Stop" };

    public static string[] ControlBindings(ControlScheme scheme) => scheme == ControlScheme.Keyboard
        ? new[] { "A / D  or  Left / Right", "W  or  Up", "S  or  Down", "Shift + Left / Right" }
        : scheme == ControlScheme.Joystick
        ? new[] { "Tilt left / right", "Tilt up", "Press + tilt left / right", "Tap piezo pad (3s cooldown)" }
        : scheme == ControlScheme.Camera ? new[] { "Close left / right fist", "Open both hands", "Make OK with either hand", "V sign or W to jump / S to drop" }
        : new[] { "Raise one hand", "Raise both hands", "Wave left / right hand", "Lower both hands" };

    public static string ControlTip(ControlScheme scheme) => scheme == ControlScheme.Keyboard
        ? "Land before jumping again.\nHold a direction with Shift to dash."
        : scheme == ControlScheme.Joystick
        ? "Centre the stick at startup. Re-centre to jump again.\nTap piezo to push nearby items, including bombs."
        : scheme == ControlScheme.Camera ? "Start the ESP32-CAM bridge on this PC.\nOpen your hand before repeating OK or V."
        : "Neutral pitch: -35 to 45 degrees.\nLower a hand before raising both to jump again.";

    public static string Instructions
    {
        get
        {
            string[] actions = ControlActions(Controls), bindings = ControlBindings(Controls);
            string text = ControlName + "\n";
            for (int i=0; i<actions.Length; i++) text += actions[i] + ": " + bindings[i] + "\n";
            return text + ControlTip(Controls)
                + "\n\nMAGNET - ALL CONTROLLERS\n" + MagnetHelp
                + "\n\nPOTIONS\nRed: +1 heart (max 3). Blue: blocks one bomb for 8 seconds.\nGold: score x2 for 10 seconds. Green: faster movement for 8 seconds.\nPurple: slower falling objects for 6 seconds. Same colour refreshes its timer."
                + "\n\nPOISONS - RED ! MARKER\nBlack: size 60% for 6 seconds. Orange: movement 60% for 6 seconds.\nLime: reverse left/right movement and dash for 5 seconds.\nEffects expire automatically. Shield does not block poison.";
        }
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Apply() => AudioListener.volume = Volume;

    public static void SetVolume(float volume)
    {
        volume = Mathf.Clamp01(volume);
        AudioListener.volume = volume;
        PlayerPrefs.SetFloat("Game.Volume", volume);
        PlayerPrefs.Save();
    }

    public static void SetHints(bool visible)
    {
        PlayerPrefs.SetInt("Game.ShowHints", visible ? 1 : 0);
        PlayerPrefs.Save();
    }

    public static void SetMusicVolume(float value)
    {
        PlayerPrefs.SetFloat("Game.MusicVolume", Mathf.Clamp01(value)); PlayerPrefs.Save();
    }
    public static void SetEffectsVolume(float value)
    {
        PlayerPrefs.SetFloat("Game.EffectsVolume", Mathf.Clamp01(value)); PlayerPrefs.Save();
    }

    public static void SetControls(int value)
    {
        PlayerPrefs.SetInt("Game.Controls", Mathf.Clamp(value, 0, ControlCount - 1));
        PlayerPrefs.Save();
    }
}
