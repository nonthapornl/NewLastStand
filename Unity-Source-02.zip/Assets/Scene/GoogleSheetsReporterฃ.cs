using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

public class GoogleSheetsReporter : MonoBehaviour
{
    private const string WebAppUrl =
        "SET_APPS_SCRIPT_URL";

    [Serializable]
    private class SheetRun
    {
        public string player;
        public int score;
        public float durationSeconds;
        public string difficulty;
        public bool incrementPlayCount;
    }

    [Serializable]
    private class SheetResponse
    {
        public bool success;
        public string message;
    }

    public void Submit(
        string player,
        int score,
        float duration,
        string difficulty)
    {
        Debug.Log("Submit Called");

        SheetRun run = new SheetRun
        {
            player = player.Trim(),
            score = score,
            durationSeconds = duration,
            difficulty = difficulty,
            incrementPlayCount = true
        };

        StartCoroutine(Upload(run));
    }

    private IEnumerator Upload(SheetRun run)
    {
        string json = JsonUtility.ToJson(run);

        Debug.Log("Sending JSON:");
        Debug.Log(json);

        byte[] body = Encoding.UTF8.GetBytes(json);

        using (UnityWebRequest request =
               new UnityWebRequest(WebAppUrl, "POST"))
        {
            request.uploadHandler = new UploadHandlerRaw(body);
            request.downloadHandler = new DownloadHandlerBuffer();

            request.SetRequestHeader(
                "Content-Type",
                "application/json");

            yield return request.SendWebRequest();

            Debug.Log("Result: " + request.result);
            Debug.Log("Response: " + request.downloadHandler.text);

            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError(
                    "Upload Failed: " + request.error);
                yield break;
            }

            SheetResponse response =
                JsonUtility.FromJson<SheetResponse>(
                    request.downloadHandler.text);

            if (response != null && response.success)
            {
                Debug.Log("Saved to Google Sheet");
            }
            else
            {
                Debug.LogError(
                    "Google Script Error: " +
                    request.downloadHandler.text);
            }
        }
    }
}