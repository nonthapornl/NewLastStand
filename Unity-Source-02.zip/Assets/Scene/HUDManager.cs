using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HUDManager : MonoBehaviour
{
    [Header("HUD Text")]
    public Text usernameText;
    public Text scoreText;
    public Text levelText;

    private Font originalUsernameFont;
    private TMP_Text mixedUsernameText;
    private bool decorated;

    public void ConfigureLayout(Transform parent, TMP_FontAsset font)
    {
        RectTransform nameFrame = Frame("Username", parent, .02f, .32f);
        RectTransform levelFrame = Frame("Level", parent, .35f, .65f);
        RectTransform scoreFrame = Frame("Score", parent, .68f, .98f);
        decorated = nameFrame != null && levelFrame != null && scoreFrame != null;
        if (decorated)
        {
            mixedUsernameText = GameUiLayout.Label("PlayerName", nameFrame, font, GameData.username,
                new Vector2(.26f,.16f), new Vector2(.86f,.43f), 38f, usernameText.color);
            mixedUsernameText.extraPadding = true;
            mixedUsernameText.useMaxVisibleDescender = false;
            mixedUsernameText.textWrappingMode = TextWrappingModes.NoWrap;
            usernameText.enabled = false;
            PlaceHudText(levelText, levelFrame, new Vector2(.54f,.23f), new Vector2(.74f,.49f));
            PlaceHudText(scoreText, scoreFrame, new Vector2(.50f,.15f), new Vector2(.81f,.47f));
            levelText.alignment = TextAnchor.MiddleCenter;
            scoreText.alignment = TextAnchor.MiddleCenter;
            return;
        }
        if (usernameText != null)
        {
            mixedUsernameText = GameUiLayout.Label("PlayerName", parent, font,
                "USERNAME: " + GameData.username, new Vector2(.03f, .935f),
                new Vector2(.30f, .993f), 32f, usernameText.color);
            mixedUsernameText.alignment = TextAlignmentOptions.MidlineLeft;
            mixedUsernameText.extraPadding = true;
            mixedUsernameText.useMaxVisibleDescender = false;
            mixedUsernameText.textWrappingMode = TextWrappingModes.NoWrap;
            usernameText.enabled = false;
        }
        PlaceHudText(levelText, parent, new Vector2(.755f, .935f), new Vector2(.90f, .993f));
        PlaceHudText(scoreText, parent, new Vector2(.755f, .88f), new Vector2(.90f, .935f));
    }

    private static RectTransform Frame(string key, Transform parent, float left, float right)
    {
        Texture2D texture = Resources.Load<Texture2D>("Hud/" + key);
        if (texture == null) return null;
        RectTransform rect = GameUiLayout.Panel(key + " frame", parent,
            new Vector2(left,.81f),new Vector2(right,.99f),Color.white);
        rect.GetComponent<Image>().sprite = Sprite.Create(texture,
            new Rect(0,0,texture.width,texture.height),new Vector2(.5f,.5f));
        return rect;
    }

    public static void PlaceHudText(Text text, Transform parent, Vector2 min, Vector2 max)
    {
        if (text == null) return;
        GameUiLayout.Place(text.rectTransform, parent, min, max);
        text.alignment = TextAnchor.MiddleLeft;
        text.resizeTextForBestFit = true;
        text.resizeTextMinSize = 22;
        text.resizeTextMaxSize = 32;
        text.horizontalOverflow = HorizontalWrapMode.Overflow;
        text.verticalOverflow = VerticalWrapMode.Truncate;
        text.raycastTarget = false;
    }

    private void Awake()
    {
        if (usernameText != null) originalUsernameFont = usernameText.font;
    }

    private void Update()
    {
        if (mixedUsernameText != null) mixedUsernameText.text = decorated ? GameData.username : "USERNAME: " + GameData.username;
        if (usernameText != null)
        {
            // Legacy UI Text cannot use TMP's fallback list.
            Font nameFont = ThaiFontSupport.ContainsThai(GameData.username)
                ? ThaiFontSupport.Font : originalUsernameFont;
            if (nameFont != null && usernameText.font != nameFont)
                usernameText.font = nameFont;
            usernameText.text = "USERNAME: " + GameData.username;
        }

        if (scoreText != null)
            scoreText.text = (decorated ? "" : "SCORE: ") + GameData.score;

        if (levelText != null)
            levelText.text = (decorated ? "" : "LEVEL: ") + DifficultyProfile.For(GameData.selectedLevel).Name;
    }
}
