using UnityEngine;
using UnityEngine.UI;

// Draw only MediaPipe landmarks, without transferring camera images to Unity.
public sealed class HandPoseGraphic : MaskableGraphic
{
    private static readonly int[] Edges =
    {
        0,1, 1,2, 2,3, 3,4, 0,5, 5,6, 6,7, 7,8, 5,9, 9,10, 10,11, 11,12,
        9,13, 13,14, 14,15, 15,16, 13,17, 17,18, 18,19, 19,20, 0,17
    };
    private readonly Vector2[] joints = new Vector2[21];
    private int[] points;

    public void Show(int[] next, Color tint)
    {
        if (!ReferenceEquals(points, next))
        {
            points = next;
            SetVerticesDirty();
        }
        if (color != tint) color = tint;
    }

    protected override void OnPopulateMesh(VertexHelper mesh)
    {
        mesh.Clear();
        if (points == null) return;

        Vector2 low = new Vector2(1000, 1000), high = Vector2.zero;
        for (int i = 0; i < joints.Length; i++)
        {
            joints[i] = new Vector2(points[i * 2] * (4f / 3f), -points[i * 2 + 1]);
            if (i == 0) low = high = joints[i];
            low = Vector2.Min(low, joints[i]);
            high = Vector2.Max(high, joints[i]);
        }
        Rect rect = GetPixelAdjustedRect();
        Vector2 size = high - low;
        float scale = Mathf.Min((rect.width - 10f) / Mathf.Max(size.x, 1f),
                                (rect.height - 10f) / Mathf.Max(size.y, 1f));
        if (scale <= 0f) return;

        Vector2 center = (low + high) * .5f;
        for (int i = 0; i < joints.Length; i++)
            joints[i] = rect.center + (joints[i] - center) * scale;
        for (int i = 0; i < Edges.Length; i += 2)
        {
            Vector2 a = joints[Edges[i]], b = joints[Edges[i + 1]];
            Vector2 d = b - a;
            if (d.sqrMagnitude < .01f) continue;
            Vector2 normal = new Vector2(-d.y, d.x).normalized * 1.25f;
            AddQuad(mesh, a - normal, a + normal, b + normal, b - normal);
        }
        foreach (Vector2 p in joints)
            AddQuad(mesh, p + new Vector2(-2, -2), p + new Vector2(-2, 2),
                    p + new Vector2(2, 2), p + new Vector2(2, -2));
    }

    private void AddQuad(VertexHelper mesh, Vector2 a, Vector2 b, Vector2 c, Vector2 d)
    {
        int index = mesh.currentVertCount;
        mesh.AddVert(a, color, Vector2.zero);
        mesh.AddVert(b, color, Vector2.zero);
        mesh.AddVert(c, color, Vector2.zero);
        mesh.AddVert(d, color, Vector2.zero);
        mesh.AddTriangle(index, index + 1, index + 2);
        mesh.AddTriangle(index, index + 2, index + 3);
    }
}
