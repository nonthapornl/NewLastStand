using UnityEngine;

[CreateAssetMenu(menuName = "Fruit Catch/Character")]
public sealed class CatchCharacter : ScriptableObject
{
    public string displayName;
    public Sprite[] idle, run, air;
}
