using UnityEngine;
using System.Collections;

public enum FruitSpeedLevel
{
    Easy,
    Normal,
    Hard
}

public class FruitSpawner : MonoBehaviour
{
    [Header("Fruit Prefabs")]
    public GameObject[] fruitPrefabs;

    [Header("Spawn Timing")]
    public float minSpawnInterval = 0.5f;
    public float maxSpawnInterval = 1.5f;

    [Header("Difficulty")]
    public FruitSpeedLevel speedLevel = FruitSpeedLevel.Normal;

    private Camera mainCamera;

    private void OnEnable()
    {
        if (mainCamera == null)
            mainCamera = Camera.main;

        speedLevel = GameData.selectedLevel;

        CancelInvoke(nameof(SpawnNextFruit));

        Invoke(nameof(SpawnNextFruit), 0.2f);
    }

    private void OnDisable()
    {
        CancelInvoke(nameof(SpawnNextFruit));
    }

    private void Start()
    {
        if (mainCamera == null)
            mainCamera = Camera.main;

        speedLevel = GameData.selectedLevel;
    }

    private void SpawnNextFruit()
    {
        if (!GameData.RoundActive) return;
        DifficultyProfile profile = DifficultyProfile.For(GameData.selectedLevel);
        Invoke(nameof(SpawnNextFruit), Random.Range(profile.FruitMin, profile.FruitMax) * DifficultyProfile.SpawnTempo);
        if (this == null || fruitPrefabs == null || fruitPrefabs.Length == 0)
            return;

        if (mainCamera == null)
            mainCamera = Camera.main;

        if (mainCamera == null)
            return;

        float x = Random.Range(0.15f, 0.85f);
        float y = 1.15f;

        Vector3 spawnPosition =
            mainCamera.ViewportToWorldPoint(
                new Vector3(x, y, 10f)
            );

        spawnPosition.z = 0f;

        GameObject fruitPrefab =
            fruitPrefabs[Random.Range(0, fruitPrefabs.Length)];

        if (fruitPrefab == null)
            return;

        GameObject fruit =
            Instantiate(fruitPrefab, spawnPosition, Quaternion.identity);

        if (fruit == null)
            return;

        Rigidbody2D rb = fruit.GetComponent<Rigidbody2D>();

        if (rb != null)
        {
            rb.gravityScale = profile.FruitGravity * DifficultyProfile.FallTempo;
            fruit.AddComponent<PotionFallModifier>();
        }

        // รอจนกว่าผลไม้จะตกออกนอกหน้าจอ
        StartCoroutine(DestroyWhenOffScreen(fruit));
    }

    
private IEnumerator DestroyWhenOffScreen(GameObject fruit)
{
    while (fruit != null)
    {
        if (mainCamera != null)
        {
            Vector3 viewportPosition =
                mainCamera.WorldToViewportPoint(
                    fruit.transform.position
                );

            // ผลไม้ตกพ้นขอบล่างของหน้าจอ
            if (viewportPosition.y < -0.1f)
            {
                FruitPickup pickup = fruit.GetComponent<FruitPickup>();
                if (pickup != null) pickup.MarkMissed();
                else Destroy(fruit);

                yield break;
            }
        }

        yield return null;
    }
}
}
