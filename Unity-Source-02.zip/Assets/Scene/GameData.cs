using System.Collections.Generic;
using UnityEngine;

public static class GameData
{
    public const float MatchDurationSeconds = 120f;
    public const int StartingLives = 3;

    public sealed class RunRecord
    {
        public string RunId { get; }
        public string Player { get; }
        public string Level { get; }
        public int Score { get; }
        public float DurationSeconds { get; }
        public int Caught { get; }
        public int Missed { get; }
        public int BestCombo { get; }
        public int AccuracyBonus { get; }

        public RunRecord(string runId, string player, string level, int score, float durationSeconds)
        {
            RunId = runId;
            Player = player;
            Level = level;
            Score = score;
            DurationSeconds = durationSeconds;
            Caught = caught;
            Missed = missed;
            BestCombo = bestCombo;
            AccuracyBonus = accuracyBonus;
        }
    }

    private static readonly List<RunRecord> runHistory = new List<RunRecord>();
    private static RunRecord pendingCompletedRun;
    private static RunRecord lastCompletedRun;

    public static string username = "Player";
    public static int score;
    public static int bestScore;
    public static int combo;
    public static int lives = StartingLives;
    public static int caught, missed, bestCombo, comboBonus, accuracyBonus, bombHits;
    public static readonly PotionEffectState Potions = new PotionEffectState();
    public static bool RoundActive { get; private set; }
    public static float Accuracy => caught + missed > 0 ? 100f * caught / (caught + missed) : 0f;
    public static float ComboMultiplier => combo >= 20 ? 2f : combo >= 10 ? 1.5f : combo >= 5 ? 1.25f : 1f;
    public static float timeRemaining = MatchDurationSeconds;
    public static FruitSpeedLevel selectedLevel = FruitSpeedLevel.Normal;
    public static Sprite selectedBackgroundSprite;
    public static IReadOnlyList<RunRecord> RunHistory => runHistory;

    public static void ResetForNewPlayer()
    {
        username = "Player";
        bestScore = 0;
        ResetRound();
        selectedLevel = FruitSpeedLevel.Normal;
        runHistory.Clear();
        pendingCompletedRun = null;
    }

    private static void ResetRound()
    {
        score = combo = caught = missed = bestCombo = comboBonus = accuracyBonus = bombHits = 0;
        lives = StartingLives;
        timeRemaining = MatchDurationSeconds;
        pendingCompletedRun = lastCompletedRun = null;
        RoundActive = false;
        Potions.Reset();
    }

    public static void BeginRound()
    {
        ResetRound();
        RoundActive = true;
    }

    public static void StopScoring() => RoundActive = false;

    public static int CatchFruit(int baseValue)
    {
        if (!RoundActive) return 0;
        caught++;
        combo++;
        bestCombo = Mathf.Max(bestCombo, combo);
        int basePoints = Mathf.RoundToInt(Mathf.Max(0, baseValue) * DifficultyProfile.For(selectedLevel).ScoreMultiplier);
        int comboPoints = Mathf.RoundToInt(basePoints * ComboMultiplier);
        int awarded = Mathf.RoundToInt(comboPoints * Potions.ScoreFactor(Time.time));
        comboBonus += comboPoints - basePoints;
        score += awarded;
        UpdateBestScore();
        return awarded;
    }

    public static void MissFruit()
    {
        if (!RoundActive) return;
        missed++;
        combo = 0;
    }

    public static void HitBomb()
    {
        if (!RoundActive) return;
        bombHits++;
        combo = 0;
    }

    public static void UpdateBestScore()
    {
        if (score > bestScore)
            bestScore = score;
    }

    public static RunRecord PrepareCompletedRun()
    {
        if (lastCompletedRun != null) return lastCompletedRun;
        StopScoring();
        // Exclude airborne fruit and require at least ten resolved fruit.
        float rate = caught + missed < 10 ? 0f
            : missed == 0 ? 0.20f : Accuracy >= 95f ? 0.15f : Accuracy >= 90f ? 0.10f : 0f;
        accuracyBonus = Mathf.RoundToInt(score * rate);
        score += accuracyBonus;
        UpdateBestScore();
        float durationSeconds = Mathf.Clamp(MatchDurationSeconds - timeRemaining, 0f, MatchDurationSeconds);
        pendingCompletedRun = new RunRecord(
            System.Guid.NewGuid().ToString("N"),
            username,
            selectedLevel.ToString(),
            score,
            durationSeconds
        );
        lastCompletedRun = pendingCompletedRun;
        return pendingCompletedRun;
    }

    public static RunRecord RecordPendingCompletedRun()
    {
        if (pendingCompletedRun == null)
            return null;

        RunRecord record = pendingCompletedRun;
        pendingCompletedRun = null;
        runHistory.Add(record);
        return record;
    }
}
