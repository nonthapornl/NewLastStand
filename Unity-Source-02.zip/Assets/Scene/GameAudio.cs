using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public sealed class GameAudio : MonoBehaviour
{
    private static GameAudio instance;
    private AudioSource music;
    private readonly AudioSource[] voices = new AudioSource[8];
    private readonly float[] voiceStart = new float[8];
    private readonly bool[] important = new bool[8];
    private readonly float[] gains = new float[8];
    private readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();
    private readonly AudioCueGate gate = new AudioCueGate();
    private float nextUiScan;
    private bool paused;
    private string sceneMusic;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetStatic() => instance = null;
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Bootstrap() => Ensure();
    private static GameAudio Ensure()
    {
        if (instance != null) return instance;
        instance = FindFirstObjectByType<GameAudio>();
        if (instance == null) instance = new GameObject("Game audio").AddComponent<GameAudio>();
        return instance;
    }
    private void Awake()
    {
        if (instance != null && instance != this) { Destroy(gameObject); return; }
        instance = this; DontDestroyOnLoad(gameObject);
        music = gameObject.AddComponent<AudioSource>();
        music.playOnAwake = false; music.loop = true; music.spatialBlend = 0f; music.priority = 96;
        music.volume=0f;
        for (int i=0;i<voices.Length;i++)
        {
            voices[i]=gameObject.AddComponent<AudioSource>();
            voices[i].playOnAwake=false;voices[i].spatialBlend=0f;voices[i].priority=128;
        }
    }
    private void OnEnable() => SceneManager.sceneLoaded += Loaded;
    private void OnDisable() => SceneManager.sceneLoaded -= Loaded;
    private void Loaded(Scene scene, LoadSceneMode mode)
    {
        nextUiScan=0f;
        if(mode==LoadSceneMode.Additive)return;
        gate.Reset();
        foreach(AudioSource source in voices)source.Stop();
        if(scene.name=="Play scene")
        {
            SetMusic("GameplayMusic");
            Play("Start", .5f, 1f, .2f, true);
        }
        else if(scene.name=="RetryScene")
        {
            SetMusic("MenuMusic");
            Play(GameData.lives>0?"Win":"Lose", .65f, 1f, .5f, true);
        }
        else SetMusic("MenuMusic");
    }
    private void SetMusic(string key)
    {
        if(sceneMusic==key&&music.isPlaying)return;
        sceneMusic=key;music.clip=Clip(key);music.pitch=1f;
        if(music.clip!=null)music.Play();
    }
    private AudioClip Clip(string key)
    {
        if(!clips.TryGetValue(key,out AudioClip clip)||clip==null)
        {
            clip=Resources.Load<AudioClip>("Audio/"+key);clips[key]=clip;
            if(clip==null)Debug.LogWarning("Missing audio clip: Resources/Audio/"+key);
        }
        return clip;
    }
    private void Update()
    {
        bool pauseNow=Time.timeScale<=0f&&SceneManager.GetActiveScene().name=="Play scene";
        if(pauseNow&&!paused)foreach(AudioSource source in voices)source.Stop();
        paused=pauseNow;
        for(int i=0;i<voices.Length;i++)voices[i].volume=gains[i]*GamePreferences.EffectsVolume;
        float target=GamePreferences.MusicVolume * (paused?.14f:SceneManager.GetActiveScene().name=="RetryScene"?.20f:.38f);
        music.volume=Mathf.MoveTowards(music.volume,target,Time.unscaledDeltaTime*.8f);
        music.pitch=!paused&&sceneMusic=="GameplayMusic"&&GameData.RoundActive&&GameData.timeRemaining<=30f?1.06f:1f;
        if(Time.unscaledTime<nextUiScan)return;
        nextUiScan=Time.unscaledTime+.5f;
        // New runtime menus, inactive Settings buttons and keyboard Submit all get the same feedback.
        foreach(Selectable control in FindObjectsByType<Selectable>(FindObjectsInactive.Include,FindObjectsSortMode.None))
            if((control is Button||control is TMP_Dropdown)&&control.GetComponent<UiSoundFeedback>()==null)
                control.gameObject.AddComponent<UiSoundFeedback>();
    }
    public static void Play(string cue,float gain=.6f,float pitch=1f,float interval=.06f,bool priority=false)
        => Ensure().PlayInternal(cue,gain,pitch,interval,priority);
    private void PlayInternal(string cue,float gain,float pitch,float interval,bool priority)
    {
        if(GamePreferences.Volume<=0f||GamePreferences.EffectsVolume<=0f)return;
        if(!gate.Allow(cue,Time.unscaledTime,interval))return;
        AudioClip clip=Clip(cue);if(clip==null)return;
        int slot=-1;
        for(int i=0;i<voices.Length;i++)if(!voices[i].isPlaying){slot=i;break;}
        if(slot<0)
        {
            if(!priority)return;
            for(int i=0;i<voices.Length;i++)
                if(!important[i]&&(slot<0||voiceStart[i]<voiceStart[slot]))slot=i;
            if(slot<0)return;
        }
        AudioSource source=voices[slot];source.Stop();source.clip=clip;
        source.volume=Mathf.Clamp01(gain)*GamePreferences.EffectsVolume;
        gains[slot]=Mathf.Clamp01(gain);
        source.pitch=Mathf.Clamp(pitch,.7f,1.4f);source.priority=priority?48:128;
        voiceStart[slot]=Time.unscaledTime;important[slot]=priority;source.Play();
    }
    public static void Fruit(int combo)
    {
        Play("Catch",.40f,Random.Range(.96f,1.04f)+Mathf.Min(combo,20)*.008f,.08f);
        if(combo>0&&combo%5==0)Play("Combo",.48f,1f+Mathf.Min(combo,20)*.008f,.45f,true);
    }
    public static void Potion(PotionKind kind)
        => Play(PotionEffectState.IsPoison(kind)?"Hurt":kind==PotionKind.Health?"Heal":kind==PotionKind.Shield?"Shield":kind.ToString(),.58f,PotionEffectState.IsPoison(kind)?.8f:1f,.12f,true);
}
