using UnityEngine;

public sealed class BombObstacle : MonoBehaviour
{
    private bool hitPlayer;

    private void OnTriggerEnter2D(Collider2D other)
    {
        TryHitPlayer(other.gameObject);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        TryHitPlayer(collision.gameObject);
    }

    private void TryHitPlayer(GameObject other)
    {
        if (hitPlayer || !other.CompareTag("Player"))
            return;

        hitPlayer = true;
        RepelledPickup repelled = GetComponent<RepelledPickup>();
        if (repelled != null && repelled.BlocksPlayerContact) { hitPlayer = false; return; }
        GameAudio.Play("Explosion", .62f, 1f, .12f, true);
        ExplosionEffect.Play(transform.position);
        GameSessionManager.RegisterBombHit();
        Destroy(gameObject);
    }
}
