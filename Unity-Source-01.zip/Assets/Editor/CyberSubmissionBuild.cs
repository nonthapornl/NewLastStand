using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

// Reproducible submission builds. Does not change scenes or gameplay settings.
public static class CyberSubmissionBuild
{
    public static void Windows() => Run(BuildTarget.StandaloneWindows64, "Windows/DokiDokiFruitCatch.exe");
    public static void Web() => Run(BuildTarget.WebGL, "WebGL");

    private static void Run(BuildTarget target, string relative)
    {
        string[] args = Environment.GetCommandLineArgs();
        int index = Array.IndexOf(args, "-submissionOutput");
        if (index < 0 || index + 1 >= args.Length) throw new ArgumentException("Provide -submissionOutput <directory>");
        string root = Path.GetFullPath(args[index + 1]);
        Directory.CreateDirectory(root);
        string destination = Path.Combine(root, relative);
        Directory.CreateDirectory(Path.GetDirectoryName(destination));
        var options = new BuildPlayerOptions {
            scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray(),
            locationPathName = destination, target = target, options = BuildOptions.None
        };
        BuildReport report = BuildPipeline.BuildPlayer(options);
        string result = $"Target: {target}\nResult: {report.summary.result}\nErrors: {report.summary.totalErrors}\nWarnings: {report.summary.totalWarnings}\nBytes: {report.summary.totalSize}\nDuration: {report.summary.totalTime}\n";
        File.WriteAllText(Path.Combine(root, target + "-build-result.txt"), result);
        Debug.Log(result);
        if (report.summary.result != BuildResult.Succeeded) throw new Exception("Submission build failed: " + target);
    }
}
