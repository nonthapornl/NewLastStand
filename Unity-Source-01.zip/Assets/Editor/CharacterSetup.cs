using System;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;

[InitializeOnLoad]
public static class CharacterSetup
{
    private static double next;
    static CharacterSetup() { EditorApplication.delayCall += Prepare; EditorApplication.update += Tick; }
    private static void Tick()
    {
        if(EditorApplication.isPlaying || EditorApplication.isCompiling || EditorApplication.timeSinceStartup<next)return;
        next=EditorApplication.timeSinceStartup+5;
        if(AssetDatabase.LoadAssetAtPath<CatchCharacter>("Assets/Resources/Characters/Character2.asset")==null)Prepare();
    }
    private static void Prepare()
    {
        if(EditorApplication.isPlaying)return;
        Directory.CreateDirectory("Assets/Resources/Characters");
        MakeOriginal();
        Make(1,"Addergul");Make(2,"Speckle");
    }
    private static void MakeOriginal()
    {
        const string target="Assets/Resources/Characters/Character0.asset";
        Sprite[] source=AssetDatabase.LoadAllAssetsAtPath("Assets/Simple 2D Platformer BE2/Sprites/Player.png").OfType<Sprite>().ToArray();
        Sprite[] idle=source.Where(s=>s.name.StartsWith("Idle ")).OrderBy(s=>s.name).ToArray();
        Sprite[] run=source.Where(s=>s.name.StartsWith("Run ")).OrderBy(s=>s.name).ToArray();
        Sprite[] air=source.Where(s=>s.name.StartsWith("Jump ")).OrderBy(s=>s.name).ToArray();
        if(idle.Length==0||run.Length==0||air.Length==0)return;
        var data=AssetDatabase.LoadAssetAtPath<CatchCharacter>(target);
        if(data==null){data=ScriptableObject.CreateInstance<CatchCharacter>();AssetDatabase.CreateAsset(data,target);}
        if(data.idle!=null&&data.run!=null&&data.air!=null&&data.idle.SequenceEqual(idle)&&data.run.SequenceEqual(run)&&data.air.SequenceEqual(air))return;
        data.displayName="Doki";data.idle=idle;data.run=run;data.air=air;
        EditorUtility.SetDirty(data);AssetDatabase.SaveAssets();
    }
    private static Sprite[] Find(string character,string animation)
    {
        string[] paths=AssetDatabase.FindAssets("t:Texture2D").Select(AssetDatabase.GUIDToAssetPath)
            .Where(p=>p.IndexOf(character,StringComparison.OrdinalIgnoreCase)>=0 && Path.GetFileNameWithoutExtension(p).IndexOf(animation,StringComparison.OrdinalIgnoreCase)>=0)
            .OrderBy(p=>p.Length).ThenBy(p=>p).ToArray();
        foreach(string path in paths)
        {
            Sprite[] sprites=AssetDatabase.LoadAllAssetsAtPath(path).OfType<Sprite>().OrderByDescending(s=>s.rect.y).ThenBy(s=>s.rect.x).ToArray();
            if(sprites.Length>0)return sprites;
        }
        return Array.Empty<Sprite>();
    }
    private static void Make(int index,string character)
    {
        string target="Assets/Resources/Characters/Character"+index+".asset";
        if(AssetDatabase.LoadAssetAtPath<CatchCharacter>(target)!=null)return;
        Sprite[] idle=Find(character,"Idle");if(idle.Length==0)return;
        var data=ScriptableObject.CreateInstance<CatchCharacter>();data.displayName=character;
        AssetDatabase.CreateAsset(data,target);
        data.idle=CopySprites(idle,data,"idle");
        Sprite[] run=Find(character,"Run"),air=Find(character,"Air");
        data.run=run.Length>0?CopySprites(run,data,"run"):data.idle;
        data.air=air.Length>0?CopySprites(air,data,"air"):data.idle;
        EditorUtility.SetDirty(data);AssetDatabase.SaveAssets();
        Debug.Log("[Characters] Prepared "+character+": "+data.idle.Length+" idle, "+data.run.Length+" run, "+data.air.Length+" air frames");
    }
    private static Sprite[] CopySprites(Sprite[] originals,CatchCharacter parent,string name)
    {
        return originals.Select((source,i)=>{
            Sprite sprite=Sprite.Create(source.texture,source.rect,new Vector2(.5f,0f),source.pixelsPerUnit);
            sprite.name=name+i;AssetDatabase.AddObjectToAsset(sprite,parent);return sprite;
        }).ToArray();
    }
}
