using System;
using System.IO;
using UnityEditor;
using UnityEngine;

// Read-only asset check; does not start a round or upload game results.
[InitializeOnLoad]
public static class PotionAssetValidation
{
    static PotionAssetValidation() { EditorApplication.delayCall += Check; }
    private static void Check()
    {
        string log = Path.Combine(Application.dataPath, "../Logs/PotionAssetValidation.json");
        try
        {
            Sprite[] red = PotionSpriteLibrary.Frames(PotionKind.Health);
            Sprite[] blue = PotionSpriteLibrary.Frames(PotionKind.Shield);
            if (red.Length != 15 || blue.Length != 15) throw new Exception("Potion frame count mismatch");
            if (red[0].texture.width != 285 || red[0].texture.height != 38) throw new Exception("Red image resized");
            if (blue[0].texture.width != 285 || blue[0].texture.height != 38) throw new Exception("Blue image resized");
            if (red[14].rect.x != 266 || blue[14].rect.x != 266) throw new Exception("Incorrect animation slices");
            if (!EditorApplication.isPlaying)
            {
                // Reproduce a cached native Sprite being destroyed between play sessions.
                UnityEngine.Object.DestroyImmediate(blue[0]);
                blue = PotionSpriteLibrary.Frames(PotionKind.Shield);
                if (blue.Length != 15 || blue[0] == null) throw new Exception("Destroyed sprite cache was not rebuilt");
            }
            Directory.CreateDirectory(Path.GetDirectoryName(log));
            File.WriteAllText(log, "{\"success\":true,\"redFrames\":15,\"blueFrames\":15,\"width\":285,\"height\":38,\"checkedUtc\":\"" + DateTime.UtcNow.ToString("o") + "\"}");
        }
        catch (Exception ex)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(log));
            File.WriteAllText(log, JsonUtility.ToJson(new Failure { error = ex.Message }));
            Debug.LogError("Potion asset validation: " + ex.Message);
        }
    }
    [Serializable] private class Failure { public bool success = false; public string error; }
}
