using UnityEditor;

public sealed class HudTextureImport : AssetPostprocessor
{
    private void OnPreprocessTexture()
    {
        if (!assetPath.StartsWith("Assets/Resources/Hud/")) return;
        TextureImporter texture = (TextureImporter)assetImporter;
        texture.textureType = TextureImporterType.Default;
        texture.npotScale = TextureImporterNPOTScale.None;
        texture.filterMode = UnityEngine.FilterMode.Point;
        texture.mipmapEnabled = false;
        texture.alphaIsTransparency = true;
        texture.textureCompression = TextureImporterCompression.Uncompressed;
        texture.maxTextureSize = 2048;
    }
}
