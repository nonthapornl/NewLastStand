# Audio sources (CC0)
Downloaded 2026-10-22. No paid subscription or account required.

- Kenney — Interface Sounds: https://kenney.nl/assets/interface-sounds
- Kenney — Digital Audio: https://kenney.nl/assets/digital-audio
- Kenney — Music Jingles: https://kenney.nl/assets/music-jingles
- Zane Little Music — Flowerbed Fields [Loop] (gameplay): https://opengameart.org/content/flowerbed-fields-loop
- Guy G. Gamerson — Happy Town (menu): https://opengameart.org/content/happy-town

Each source page identifies its content as CC0. Original Kenney license texts included.
Audio pixel-game cues are selected from those packs; manifest.json records original filenames.
Original music files retained without editing. Menu music is a town theme with a short quiet transition at the loop boundary.
