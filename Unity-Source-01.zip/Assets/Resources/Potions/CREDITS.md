# Potion art attribution

Pixel Art Potion Pack - Animated, by karsiori.
Official author download: https://karsiori.itch.io/pixel-art-potion-pack-animated
Unity listing: https://assetstore.unity.com/packages/2d/pixel-art-potion-pack-animated-270453
The author's itch.io page declares Creative Commons Zero v1.0 Universal (CC0).
Downloaded from the author's free download on 2026-10-22.

Included here: original Round Potion RED and BLUE spritesheets, 285x38 pixels,
15 frames of 19x38 each. Pack description rounds width to 20; actual PNG width
is 19 per frame. Animation plays at 10fps. Source pixel data unchanged.
Texture import: Point, no mipmaps, no NPOT resizing, uncompressed.
Full original archive retained at C:/Users/cigxr/Downloads/Pixel Potion Pack.zip.
