# Character art
Pixel Art Character Package by GDD-Quinnipiac, version 1.0.
https://assetstore.unity.com/packages/2d/characters/pixel-art-character-package-312497
Downloaded through Unity Package Manager on 2026-10-22 after the user accepted the Asset Store terms.
Standard Unity Asset Store EULA applies; this artwork is not CC0.
Selected originals: Addergul White and Speckle Turquoise (idle, run, air sheets and original metadata).
The Doki character comes from the existing project. All characters keep its original physics and hitbox.
