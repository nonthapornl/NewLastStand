#include <Arduino.h>
#include <Wire.h>
#include <EEPROM.h>
#include "UltrasonicInput.h"
#include "JoystickInput.h"
#include "PiezoInput.h"

// ---------------- Pins ----------------
#if defined(CONFIG_IDF_TARGET_ESP32)
const uint8_t MPU_SDA_PIN = 21;
const uint8_t MPU_SCL_PIN = 22;
const uint8_t LEFT_LED = 18;
const uint8_t RIGHT_LED = 19;
#elif defined(ARDUINO_ARCH_ESP32)
const uint8_t MPU_SDA_PIN = 8;
const uint8_t MPU_SCL_PIN = 9;
const uint8_t LEFT_LED = 5;
const uint8_t RIGHT_LED = 4;
#else
const uint8_t MPU_SDA_PIN = SDA;
const uint8_t MPU_SCL_PIN = SCL;
const uint8_t LEFT_LED = 5;
const uint8_t RIGHT_LED = 4;
#endif

// ---------------- MPU6050 ----------------
const uint8_t NUM_IMU = 2;
const uint8_t IMU_ADDR[NUM_IMU] = {0x68, 0x69};  // 0: left hand (AD0 low), 1: right hand (AD0 high)
const char *const IMU_NAME[NUM_IMU] = {"Left hand", "Right hand"};
const float ACCEL_LSB = 8192.0f;    // +-4 g (headroom for large offsets and fast hand moves)
const float GYRO_LSB = 32.8f;       // +-1000 deg/s

// Body frame used for all angles: 0 = Forward, 1 = Left, 2 = Up.
// The 6-step accel calibration figures out which sensor axis is which,
// so each sensor can be mounted in any orientation.
//   roll  > 0 : tilted right    roll  < 0 : tilted left
//   pitch > 0 : nose down       pitch < 0 : nose up

// ---------------- Settings (persisted in EEPROM) ----------------
struct ImuCal {
  float gyroOff[3];    // raw LSB, sensor axes
  float accBias[3];    // raw LSB, sensor axes
  float accScale[3];   // LSB per g, sensor axes
  int8_t axis[3];      // sensor axis index for body F, L, U
  int8_t sgn[3];       // +1 / -1 for body F, L, U
  float rollZero;      // level trim in degrees
  float pitchZero;
};

// LED modes
//   0: each hand  - left LED when the left hand tilts past the threshold, right LED for the right hand
//   1: left hand  - left/right LED when the left hand tilts left/right
//   2: right hand - left/right LED when the right hand tilts left/right
struct Settings {
  uint32_t magic;
  ImuCal cal[NUM_IMU];
  float threshold;     // tilt angle (deg) to turn on an LED
  float hysteresis;    // deg below threshold before LED turns off
  float alpha;         // complementary filter weight for gyro
  uint16_t rateMs;     // streaming interval
  uint8_t invert;      // swap left/right
  uint8_t raw;         // stream raw values
  uint8_t ledMode;
  uint8_t i2cFast;     // 0 = 100 kHz (long wires), 1 = 400 kHz (short wires). Uses a former padding byte.
};

// Single-IMU layout from the previous firmware, so its calibration carries over
struct LegacySettings {
  uint32_t magic;
  ImuCal cal;
  float threshold, hysteresis, alpha;
  uint16_t rateMs;
  uint8_t invert, raw;
};

const uint32_t SETTINGS_MAGIC = 0x4D505535;  // "MPU5" - bump when Settings layout or units change
const uint32_t V4_MAGIC = 0x4D505534;        // "MPU4" - same layout, accel calibration in +-2 g units
const uint32_t LEGACY_MAGIC = 0x4D505533;    // "MPU3" - single IMU, +-2 g units
Settings cfg;
const size_t SETTINGS_STORAGE_BYTES = 512;
static_assert(sizeof(Settings) <= SETTINGS_STORAGE_BYTES, "Settings exceed EEPROM allocation");
bool settingsStorageReady = true;
#include "mpu_saved_calibration.h"

bool saveSettings() {
  if (!settingsStorageReady) return false;
  EEPROM.put(0, cfg);
#if defined(ARDUINO_ARCH_ESP32)
  return EEPROM.commit();
#else
  return true;
#endif
}

void defaultCalibration(ImuCal &c) {
  for (int i = 0; i < 3; i++) {
    c.gyroOff[i] = 0;
    c.accBias[i] = 0;
    c.accScale[i] = ACCEL_LSB;
    c.axis[i] = i;
    c.sgn[i] = 1;
  }
  c.rollZero = c.pitchZero = 0;
}

void defaultSettings() {
  cfg.magic = SETTINGS_MAGIC;
  for (int i = 0; i < NUM_IMU; i++) defaultCalibration(cfg.cal[i]);
  cfg.threshold = 15.0f;
  cfg.hysteresis = 3.0f;
  cfg.alpha = 0.98f;
  cfg.rateMs = 20;
  cfg.invert = 0;
  cfg.raw = 0;
  cfg.ledMode = 0;
  cfg.i2cFast = 0;
}

// Calibration saved while the accelerometer ran at +-2 g has twice the LSB per g
void convertFrom2g(ImuCal &c) {
  for (int i = 0; i < 3; i++) {
    c.accBias[i] /= 2;
    c.accScale[i] /= 2;
  }
}

bool loadSettings() {
  if (!settingsStorageReady) return false;
  Settings s;
  EEPROM.get(0, s);
  if (s.magic == SETTINGS_MAGIC || s.magic == V4_MAGIC) {
    cfg = s;
    if (cfg.i2cFast > 1) cfg.i2cFast = 0;  // older saves left this byte undefined
    if (s.magic == V4_MAGIC) {
      for (int i = 0; i < NUM_IMU; i++) convertFrom2g(cfg.cal[i]);
      cfg.magic = SETTINGS_MAGIC;
    }
    return true;
  }
  LegacySettings old;
  EEPROM.get(0, old);
  if (old.magic == LEGACY_MAGIC) {
    defaultSettings();
    cfg.cal[0] = old.cal;
    convertFrom2g(cfg.cal[0]);
    cfg.threshold = old.threshold;
    cfg.hysteresis = old.hysteresis;
    cfg.alpha = old.alpha;
    cfg.rateMs = old.rateMs;
    cfg.invert = old.invert;
    return true;
  }
  return false;
}

// ---------------- State ----------------
struct Imu {
  uint8_t idx;
  bool ok;
  uint8_t failCount;
  int16_t rawA[3], rawG[3], rawT;
  float acc[3], gyro[3], tempC;   // body frame: g and deg/s
  float roll, pitch, yaw;
  // 6-step accel calibration captures (raw LSB means)
  // 0 level, 1 left side down, 2 right side down, 3 nose down, 4 nose up, 5 upside down
  float acalSample[6][3];
  float acalGyro[6][3];  // gyro means during each capture (sensor was still)
  uint8_t acalDone;      // bitmask
};
Imu imus[NUM_IMU];

bool leftOn = false, rightOn = false;
bool streaming = true;
uint32_t lastMicros = 0, lastSend = 0, lastRawSend = 0, lastRetry = 0;
String rxLine;

// ---------------- Helpers ----------------
float wrap180(float a) {
  while (a > 180) a -= 360;
  while (a < -180) a += 360;
  return a;
}

// Parse up to `max` space-separated numbers; returns how many were found
int parseNums(const String &s, float *out, int max) {
  const char *p = s.c_str();
  int n = 0;
  while (n < max) {
    char *end;
    float v = strtod(p, &end);
    if (end == p) break;
    out[n++] = v;
    p = end;
  }
  return n;
}

// ---------------- I2C ----------------
// A glitch on long wires can leave a sensor holding SDA low mid-byte, which
// blocks the whole bus. Clocking SCL up to 9 times lets it finish and release SDA.
void i2cRecoverBus() {
#if defined(ARDUINO_ARCH_ESP32)
  const uint8_t driveMode = OUTPUT_OPEN_DRAIN;
#else
  const uint8_t driveMode = OUTPUT;
#endif
  pinMode(MPU_SDA_PIN, INPUT_PULLUP);
  pinMode(MPU_SCL_PIN, INPUT_PULLUP);
  delayMicroseconds(10);
  if (digitalRead(MPU_SDA_PIN) == HIGH) return;
  digitalWrite(MPU_SCL_PIN, HIGH);
  pinMode(MPU_SCL_PIN, driveMode);
  for (int i = 0; i < 9 && digitalRead(MPU_SDA_PIN) == LOW; i++) {
    digitalWrite(MPU_SCL_PIN, LOW); delayMicroseconds(10);
    digitalWrite(MPU_SCL_PIN, HIGH); delayMicroseconds(10);
  }
  digitalWrite(MPU_SDA_PIN, LOW);
  pinMode(MPU_SDA_PIN, driveMode);
  delayMicroseconds(10);
  digitalWrite(MPU_SDA_PIN, HIGH); delayMicroseconds(10);
  pinMode(MPU_SDA_PIN, INPUT_PULLUP);
  pinMode(MPU_SCL_PIN, INPUT_PULLUP);
}

void i2cStart() {
  Wire.end();
  i2cRecoverBus();
#if defined(ARDUINO_ARCH_ESP32)
  Wire.begin(MPU_SDA_PIN, MPU_SCL_PIN);
  Wire.setTimeOut(5); // milliseconds on Arduino-ESP32
#else
  Wire.begin();
  Wire.setWireTimeout(5000);
#endif
  Wire.setClock(cfg.i2cFast ? 400000 : 100000);
}

void mpuWrite(uint8_t addr, uint8_t reg, uint8_t val) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

bool mpuReadAll(Imu &m) {
  uint8_t addr = IMU_ADDR[m.idx];
  Wire.beginTransmission(addr);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(addr, (uint8_t)14) != 14) return false;
  uint8_t b[14];
  for (int i = 0; i < 14; i++) b[i] = Wire.read();
  m.rawA[0] = (b[0] << 8) | b[1];
  m.rawA[1] = (b[2] << 8) | b[3];
  m.rawA[2] = (b[4] << 8) | b[5];
  m.rawT    = (b[6] << 8) | b[7];
  m.rawG[0] = (b[8] << 8) | b[9];
  m.rawG[1] = (b[10] << 8) | b[11];
  m.rawG[2] = (b[12] << 8) | b[13];
  return true;
}

// Read WHO_AM_I; returns -1 if nothing answered at this address.
// (Both sensors report 0x68 here regardless of their I2C address; clones may report 0x70/0x72/0x98.)
int mpuWhoAmI(uint8_t addr) {
  for (int attempt = 0; attempt < 3; attempt++) {
    Wire.beginTransmission(addr);
    Wire.write(0x75);
    if (Wire.endTransmission(false) == 0 && Wire.requestFrom(addr, (uint8_t)1) == 1) return Wire.read();
    delay(5);
  }
  return -1;
}

void sendInfo(const String &msg);
void sendImuInfo(int i, const String &msg);

// Report every address that answers on the bus, to help debug wiring
void scanI2C() {
  sendInfo(String("I2C clock: ") + (cfg.i2cFast ? "400" : "100") + " kHz");
  String found;
  for (uint8_t a = 0x08; a < 0x78; a++) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) found += " 0x" + String(a, HEX);
  }
  sendInfo("I2C scan:" + (found.length() ? found : String(" nothing found - check SDA/SCL/power")));
  for (int i = 0; i < NUM_IMU; i++) {
    int who = mpuWhoAmI(IMU_ADDR[i]);
    if (who < 0) sendImuInfo(i, "no reply");
    else sendImuInfo(i, "WHO_AM_I = 0x" + String(who, HEX));
  }
}

bool mpuInit(uint8_t addr) {
  if (mpuWhoAmI(addr) < 0) return false;
  mpuWrite(addr, 0x6B, 0x00);  // wake up
  delay(100);
  mpuWrite(addr, 0x6B, 0x01);  // PLL with X gyro reference
  mpuWrite(addr, 0x19, 0x04);  // sample rate divider -> 200 Hz
  mpuWrite(addr, 0x1A, 0x03);  // DLPF ~44 Hz
  mpuWrite(addr, 0x1B, 0x10);  // gyro +-1000 deg/s (fast tilts won't saturate)
  mpuWrite(addr, 0x1C, 0x08);  // accel +-4 g
  return true;
}

// Convert the latest raw reading to calibrated body-frame values
void toBody(Imu &m) {
  const ImuCal &c = cfg.cal[m.idx];
  for (int j = 0; j < 3; j++) {
    int s = c.axis[j];
    m.acc[j] = c.sgn[j] * (m.rawA[s] - c.accBias[s]) / c.accScale[s];
    m.gyro[j] = c.sgn[j] * (m.rawG[s] - c.gyroOff[s]) / GYRO_LSB;
  }
  m.tempC = m.rawT / 340.0f + 36.53f;
}

float accRoll(const Imu &m)  { return atan2(m.acc[1], m.acc[2]) * RAD_TO_DEG; }
float accPitch(const Imu &m) { return atan2(-m.acc[0], sqrt(m.acc[1] * m.acc[1] + m.acc[2] * m.acc[2])) * RAD_TO_DEG; }

void seedAngles(Imu &m) {
  if (!mpuReadAll(m)) return;
  toBody(m);
  m.roll = accRoll(m);
  m.pitch = accPitch(m);
  m.yaw = 0;
}

float tiltRoll(const Imu &m) { return wrap180(m.roll - cfg.cal[m.idx].rollZero); }

// ---------------- Output ----------------
void sendInfo(const String &msg) {
  Serial.print(F("{\"t\":\"i\",\"msg\":\""));
  Serial.print(msg);
  Serial.println(F("\"}"));
}

void sendImuInfo(int i, const String &msg) {
  sendInfo(String(IMU_NAME[i]) + " (0x" + String(IMU_ADDR[i], HEX) + "): " + msg);
}

void printArr(const char *key, const float *v, int digits, bool first = false) {
  if (!first) Serial.print(',');
  Serial.print('"'); Serial.print(key); Serial.print(F("\":["));
  for (int i = 0; i < 3; i++) { if (i) Serial.print(','); Serial.print(v[i], digits); }
  Serial.print(']');
}

void printIntArr(const char *key, const int16_t *v) {
  Serial.print(F(",\"")); Serial.print(key); Serial.print(F("\":["));
  for (int i = 0; i < 3; i++) { if (i) Serial.print(','); Serial.print(v[i]); }
  Serial.print(']');
}

void sendSettings() {
  Serial.print(F("{\"t\":\"s\",\"thr\":"));  Serial.print(cfg.threshold, 2);
  Serial.print(F(",\"hys\":"));   Serial.print(cfg.hysteresis, 2);
  Serial.print(F(",\"alpha\":")); Serial.print(cfg.alpha, 3);
  Serial.print(F(",\"rate\":"));  Serial.print(cfg.rateMs);
  Serial.print(F(",\"inv\":"));   Serial.print(cfg.invert);
  Serial.print(F(",\"raw\":"));   Serial.print(cfg.raw);
  Serial.print(F(",\"led\":"));   Serial.print(cfg.ledMode);
  Serial.print(F(",\"alsb\":"));  Serial.print((int)ACCEL_LSB);
  Serial.print(F(",\"i2c\":"));   Serial.print(cfg.i2cFast ? 400 : 100);
  Serial.print(F(",\"stream\":")); Serial.print(streaming ? 1 : 0);
  Serial.print(F(",\"imu\":["));
  for (int i = 0; i < NUM_IMU; i++) {
    const ImuCal &c = cfg.cal[i];
    if (i) Serial.print(',');
    Serial.print(F("{\"addr\":")); Serial.print(IMU_ADDR[i]);
    Serial.print(F(",\"ok\":")); Serial.print(imus[i].ok ? 1 : 0);
    Serial.print(F(",\"rz\":")); Serial.print(c.rollZero, 2);
    Serial.print(F(",\"pz\":")); Serial.print(c.pitchZero, 2);
    printArr("go", c.gyroOff, 1);
    printArr("ab", c.accBias, 1);
    printArr("as", c.accScale, 1);
    Serial.print(F(",\"map\":["));
    for (int j = 0; j < 3; j++) { if (j) Serial.print(','); Serial.print(c.sgn[j] * (c.axis[j] + 1)); }
    Serial.print(F("],\"acal\":")); Serial.print(imus[i].acalDone);
    Serial.print('}');
  }
  Serial.println(F("]}"));
}

// Angles for both hands: h = [[roll, pitch, yaw, ok], ...]
void sendData() {
  Serial.print(F("{\"t\":\"d\",\"L\":")); Serial.print(leftOn ? 1 : 0);
  Serial.print(F(",\"R\":")); Serial.print(rightOn ? 1 : 0);
  Serial.print(F(",\"h\":["));
  for (int i = 0; i < NUM_IMU; i++) {
    const Imu &m = imus[i];
    if (i) Serial.print(',');
    Serial.print('['); Serial.print(tiltRoll(m), 2);
    Serial.print(','); Serial.print(m.pitch - cfg.cal[i].pitchZero, 2);
    Serial.print(','); Serial.print(m.yaw, 2);
    Serial.print(','); Serial.print(m.ok ? 1 : 0);
    Serial.print(']');
  }
  Serial.println(F("]}"));
}

// Raw values go in a separate, slower line so both sensors fit at 115200 baud
void sendRaw() {
  Serial.print(F("{\"t\":\"r\",\"h\":["));
  for (int i = 0; i < NUM_IMU; i++) {
    const Imu &m = imus[i];
    if (i) Serial.print(',');
    Serial.print(F("{\"tc\":")); Serial.print(m.tempC, 1);
    printIntArr("ra", m.rawA);
    printIntArr("rg", m.rawG);
    printArr("a", m.acc, 3);
    printArr("g", m.gyro, 2);
    Serial.print('}');
  }
  Serial.println(F("]}"));
}

// ---------------- Sampling ----------------
// Average `samples` readings. Returns false if the sensor moved too much.
bool averageStill(Imu &m, uint16_t samples, float meanA[3], float meanG[3], uint8_t progressStep) {
  double sa[3] = {0, 0, 0}, sg[3] = {0, 0, 0}, sgg = 0;
  uint16_t got = 0;
  for (uint16_t n = 0; n < samples; n++) {
    if (mpuReadAll(m)) {
      for (int i = 0; i < 3; i++) {
        sa[i] += m.rawA[i];
        sg[i] += m.rawG[i];
        sgg += (double)m.rawG[i] * m.rawG[i];
      }
      got++;
    }
    if (n % 50 == 0) {
      Serial.print(F("{\"t\":\"c\",\"imu\":")); Serial.print(m.idx);
      Serial.print(F(",\"step\":")); Serial.print(progressStep);
      Serial.print(F(",\"pct\":")); Serial.print((uint32_t)n * 100 / samples);
      Serial.println('}');
    }
    delay(3);
  }
  Serial.print(F("{\"t\":\"c\",\"imu\":")); Serial.print(m.idx);
  Serial.print(F(",\"step\":")); Serial.print(progressStep);
  Serial.println(F(",\"pct\":100}"));
  if (got < samples / 2) return false;
  double var = sgg / got;
  for (int i = 0; i < 3; i++) {
    meanA[i] = sa[i] / got;
    meanG[i] = sg[i] / got;
    var -= (double)meanG[i] * meanG[i];
  }
  // Total gyro noise; above ~3 deg/s RMS means it was being moved
  return sqrt(fabs(var)) / GYRO_LSB < 3.0;
}

// ---------------- Gyro calibration ----------------
void calibrateGyro(Imu &m) {
  sendImuInfo(m.idx, "gyro calibration - keep the sensor still");
  float a[3], g[3];
  if (!averageStill(m, 600, a, g, 255)) { sendImuInfo(m.idx, "gyro calibration failed - sensor moved, try again"); return; }
  for (int i = 0; i < 3; i++) cfg.cal[m.idx].gyroOff[i] = g[i];
  m.yaw = 0;
  sendImuInfo(m.idx, "gyro calibrated (not saved yet)");
  sendSettings();
}

// ---------------- 6-step accel calibration ----------------
const char *const STEP_NAMES[6] = {"Level", "Left side down", "Right side down", "Nose down", "Nose up", "Upside down"};

void accelCaptureStep(Imu &m, int k) {
  if (k < 0 || k > 5) { sendInfo("Step must be 0-5"); return; }
  float a[3], g[3];
  bool still = averageStill(m, 400, a, g, k);
  Serial.print(F("{\"t\":\"ac\",\"imu\":")); Serial.print(m.idx);
  Serial.print(F(",\"k\":")); Serial.print(k);
  Serial.print(F(",\"ok\":")); Serial.print(still ? 1 : 0);
  if (still) {
    for (int i = 0; i < 3; i++) { m.acalSample[k][i] = a[i]; m.acalGyro[k][i] = g[i]; }
    m.acalDone |= 1 << k;
    printArr("v", a, 0);
  }
  Serial.println('}');
  if (!still) sendImuInfo(m.idx, String("step '") + STEP_NAMES[k] + "' failed - sensor moved, hold it still");
}

// Find which sensor axis changed most between two opposite poses
void pickAxis(const float *plus, const float *minus, int8_t &axis, int8_t &sgn) {
  int best = 0;
  float bestAbs = 0;
  for (int i = 0; i < 3; i++) {
    float d = plus[i] - minus[i];
    if (fabs(d) > bestAbs) { bestAbs = fabs(d); best = i; }
  }
  axis = best;
  sgn = (plus[best] - minus[best]) > 0 ? 1 : -1;
}

// An axis mapping is valid if it uses 3 different axes and is a rotation, not a mirror
bool validMapping(const int8_t ax[3], const int8_t sg[3]) {
  if (ax[0] == ax[1] || ax[1] == ax[2] || ax[0] == ax[2]) return false;
  float m[3][3] = {{0}};
  for (int j = 0; j < 3; j++) m[j][ax[j]] = sg[j];
  float det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
            - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
            + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
  return det > 0;
}

bool validScale(float scale, float bias) {
  return scale >= 0.7f * ACCEL_LSB && scale <= 1.3f * ACCEL_LSB && fabs(bias) <= 1.5f * ACCEL_LSB;  // clone chips can be off by ~1 g
}

// Result of a 6-step solve; on failure `why` is shown in the web UI
void sendSolveResult(int i, bool ok, const char *why = "") {
  Serial.print(F("{\"t\":\"as\",\"imu\":")); Serial.print(i);
  Serial.print(F(",\"ok\":")); Serial.print(ok ? 1 : 0);
  Serial.print(F(",\"why\":\"")); Serial.print(why);
  Serial.println(F("\"}"));
}

void accelSolve(Imu &m) {
  if (m.acalDone != 0x3F) { sendImuInfo(m.idx, "capture all 6 steps first"); sendSolveResult(m.idx, false, "Not all 6 steps were captured"); return; }
  int8_t ax[3], sg[3];
  // Accelerometer reads +1 g along the axis pointing up:
  //   Up:      level (+U) vs upside down (-U)
  //   Left:    right side down (+L) vs left side down (-L)
  //   Forward: nose up (+F) vs nose down (-F)
  pickAxis(m.acalSample[4], m.acalSample[3], ax[0], sg[0]);
  pickAxis(m.acalSample[2], m.acalSample[1], ax[1], sg[1]);
  pickAxis(m.acalSample[0], m.acalSample[5], ax[2], sg[2]);
  if (!validMapping(ax, sg)) {
    sendImuInfo(m.idx, "calibration failed - poses don't match 6 different directions. Redo the steps");
    sendSolveResult(m.idx, false, "The 6 poses don't point in 6 different directions, or left/right or nose up/down were swapped");
    return;
  }

  const int pairs[3][2] = {{4, 3}, {2, 1}, {0, 5}};
  float bias[3], scale[3];
  for (int j = 0; j < 3; j++) {
    int s = ax[j];
    float p = m.acalSample[pairs[j][0]][s], n = m.acalSample[pairs[j][1]][s];
    bias[s] = (p + n) / 2;
    scale[s] = fabs(p - n) / 2;
    if (!validScale(scale[s], bias[s])) {
      sendImuInfo(m.idx, "calibration failed - readings out of range. Hold each pose at 90 degrees and redo");
      sendSolveResult(m.idx, false, "Readings out of range - a pose wasn't close to 90 degrees, or the readings are corrupted");
      return;
    }
  }

  ImuCal &c = cfg.cal[m.idx];
  for (int i = 0; i < 3; i++) {
    c.axis[i] = ax[i];
    c.sgn[i] = sg[i];
    c.accBias[i] = bias[i];
    c.accScale[i] = scale[i];
    // The sensor was held still for every step, so the gyro bias comes for free
    float sum = 0;
    for (int k = 0; k < 6; k++) sum += m.acalGyro[k][i];
    c.gyroOff[i] = sum / 6;
  }

  // Use the level capture as the zero reference (removes small mounting tilt)
  for (int i = 0; i < 3; i++) m.rawA[i] = m.acalSample[0][i];
  toBody(m);
  c.rollZero = m.roll = accRoll(m);
  c.pitchZero = m.pitch = accPitch(m);
  m.yaw = 0;
  m.acalDone = 0;
  sendImuInfo(m.idx, "accel calibration done");
  sendSolveResult(m.idx, true);
  sendSettings();
}

// CALSET i gx gy gz bx by bz sx sy sz mapF mapL mapU rollZero pitchZero
// Restores a calibration from a downloaded profile. map = +-1..3 (sensor axis X/Y/Z with sign).
void calSet(const String &arg) {
  float v[15];
  if (parseNums(arg, v, 15) != 15) { sendInfo("CALSET needs 15 numbers"); return; }
  int i = (int)v[0];
  if (i < 0 || i >= NUM_IMU) { sendInfo("CALSET: bad IMU index"); return; }
  ImuCal c;
  int8_t ax[3], sg[3];
  for (int j = 0; j < 3; j++) {
    c.gyroOff[j] = v[1 + j];
    c.accBias[j] = v[4 + j];
    c.accScale[j] = v[7 + j];
    int mp = (int)v[10 + j];
    if (mp == 0 || abs(mp) > 3) { sendImuInfo(i, "profile rejected - bad axis map"); return; }
    ax[j] = abs(mp) - 1;
    sg[j] = mp > 0 ? 1 : -1;
    c.axis[j] = ax[j];
    c.sgn[j] = sg[j];
  }
  if (!validMapping(ax, sg)) { sendImuInfo(i, "profile rejected - bad axis map"); return; }
  for (int j = 0; j < 3; j++) {
    if (!validScale(c.accScale[j], c.accBias[j])) { sendImuInfo(i, "profile rejected - accel values out of range"); return; }
  }
  c.rollZero = v[13];
  c.pitchZero = v[14];
  cfg.cal[i] = c;
  seedAngles(imus[i]);
  sendImuInfo(i, "calibration loaded from profile (not saved yet)");
}

// ---------------- Commands ----------------
// Per IMU (i = 0 left hand, 1 right hand):
//   CAL i | ACAL i k | ASOLVE i | ARESET i | ZERO i | CLR i | CALSET i ...
// Global:
//   YAW0 | SAVE | LOAD | DEF | THR x | HYS x | ALPHA x | RATE ms | LED 0-2
//   I2C 100/400 | RAW 0/1 | INV 0/1 | STREAM 0/1 | SCAN | GET | PING
void handleCommand(String line) {
  line.trim();
  if (line.length() == 0) return;
  int sp = line.indexOf(' ');
  String cmd = sp < 0 ? line : line.substring(0, sp);
  String arg = sp < 0 ? "" : line.substring(sp + 1);
  cmd.toUpperCase();
  if (cmd == "USCHECK") {
    UltrasonicInput::diagnose();
    lastMicros = micros(); // The diagnostic pause is not IMU integration time.
    return;
  }
  if (cmd == "PIEZOTHR") { PiezoInput::setThreshold(arg.toInt()); return; }
  if (cmd == "PIEZOZERO") { PiezoInput::zero(); return; }
  float a[2] = {0, 0};
  int nArgs = parseNums(arg, a, 2);
  float v = a[0];

  // Commands that act on one IMU
  if (cmd == "CAL" || cmd == "ACAL" || cmd == "ASOLVE" || cmd == "ARESET" || cmd == "ZERO" || cmd == "CLR") {
    int i = (int)a[0];
    if (nArgs < 1 || i < 0 || i >= NUM_IMU) { sendInfo(cmd + " needs an IMU index (0 or 1)"); return; }
    Imu &m = imus[i];
    if (!m.ok && cmd != "ARESET" && cmd != "CLR") { sendImuInfo(i, "not connected"); return; }
    if (cmd == "CAL") { calibrateGyro(m); return; }
    if (cmd == "ACAL") {
      if (nArgs < 2) { sendInfo("ACAL needs IMU index and step"); return; }
      accelCaptureStep(m, (int)a[1]);
      return;
    }
    if (cmd == "ASOLVE") { accelSolve(m); return; }
    if (cmd == "ARESET") { m.acalDone = 0; sendImuInfo(i, "accel calibration steps cleared"); }
    if (cmd == "ZERO") { cfg.cal[i].rollZero = m.roll; cfg.cal[i].pitchZero = m.pitch; sendImuInfo(i, "current pose set as level"); }
    if (cmd == "CLR") { defaultCalibration(cfg.cal[i]); sendImuInfo(i, "calibration cleared (not saved)"); }
    sendSettings();
    return;
  }

  if (cmd == "CALSET") calSet(arg);
  else if (cmd == "YAW0") { for (int i = 0; i < NUM_IMU; i++) imus[i].yaw = 0; sendInfo("Yaw reset"); }
  else if (cmd == "SAVE") { sendInfo(saveSettings() ? "Settings saved to board" : "Settings save failed"); }
  else if (cmd == "LOAD") {
    if (loadSettings()) sendInfo("Settings loaded");
    else sendInfo("No saved settings");
  }
  else if (cmd == "DEF")    { defaultSettings(); sendInfo("Defaults restored (not saved)"); }
  else if (cmd == "THR")    cfg.threshold = constrain(v, 1.0f, 89.0f);
  else if (cmd == "HYS")    cfg.hysteresis = constrain(v, 0.0f, 20.0f);
  else if (cmd == "ALPHA")  cfg.alpha = constrain(v, 0.5f, 0.999f);
  else if (cmd == "RATE")   cfg.rateMs = constrain((int)v, 5, 1000);
  else if (cmd == "LED")    cfg.ledMode = constrain((int)v, 0, 2);
  else if (cmd == "I2C")    { cfg.i2cFast = v >= 400; i2cStart(); sendInfo(String("I2C clock set to ") + (cfg.i2cFast ? "400" : "100") + " kHz"); }
  else if (cmd == "RAW")    cfg.raw = v != 0;
  else if (cmd == "INV")    cfg.invert = v != 0;
  else if (cmd == "STREAM") streaming = v != 0;
  else if (cmd == "GET")    ;
  else if (cmd == "SCAN")   { scanI2C(); return; }
  else if (cmd == "PING")   { sendInfo("PONG"); return; }
  else { sendInfo("Unknown command: " + cmd); return; }
  sendSettings();
}

void readSerial() {
  while (Serial.available()) {
    int incoming = Serial.read();
    if (incoming < 0) break;
    char c = (char)incoming;
    if (c == '\n' || c == '\r') {
      if (rxLine.length()) handleCommand(rxLine);
      rxLine = "";
    } else if (rxLine.length() < 200) {
      rxLine += c;
    }
  }
}

// ---------------- IMU startup ----------------
void startImu(Imu &m, bool autoGyro) {
  m.ok = mpuInit(IMU_ADDR[m.idx]);
  m.failCount = 0;
  if (!m.ok) { sendImuInfo(m.idx, "not found - check wiring"); return; }
  // Like a drone: re-measure the gyro bias at power-up if the sensor is still.
  // If it's being moved, keep the saved offsets.
  float a[3], g[3];
  if (autoGyro) {
    if (averageStill(m, 300, a, g, 255)) {
      for (int i = 0; i < 3; i++) cfg.cal[m.idx].gyroOff[i] = g[i];
      sendImuInfo(m.idx, "found, gyro auto-calibrated");
    } else {
      sendImuInfo(m.idx, "found, moved during startup - using saved gyro offsets");
    }
  } else {
    sendImuInfo(m.idx, "connected");
  }
  seedAngles(m);
}

// ---------------- Main ----------------
void setup() {
  pinMode(LEFT_LED, OUTPUT);
  pinMode(RIGHT_LED, OUTPUT);
  Serial.begin(115200);
#if defined(ARDUINO_ARCH_ESP32)
  settingsStorageReady = EEPROM.begin(SETTINGS_STORAGE_BYTES);
#endif
  defaultSettings();
  bool loaded = loadSettings();
#if defined(ARDUINO_ARCH_ESP32)
  if (!loaded) {
    applySavedMpuCalibration();
    sendInfo("Using saved two-hand calibration profile in RAM (flash unchanged)");
  }
  if (!settingsStorageReady) sendInfo("Flash settings unavailable; SAVE will fail");
  sendInfo(String("ESP32 I2C SDA=") + MPU_SDA_PIN + " SCL=" + MPU_SCL_PIN);
#else
  (void)loaded;
#endif
  i2cStart();

  // Blink both LEDs on boot
  digitalWrite(LEFT_LED, HIGH); digitalWrite(RIGHT_LED, HIGH);
  delay(300);
  digitalWrite(LEFT_LED, LOW); digitalWrite(RIGHT_LED, LOW);

  delay(100);  // let the sensors power up
  scanI2C();
  for (int i = 0; i < NUM_IMU; i++) {
    imus[i] = Imu();
    imus[i].idx = i;
    startImu(imus[i], true);
  }

  JoystickInput::begin();
  PiezoInput::begin();
  lastMicros = micros();
  UltrasonicInput::begin();
  sendInfo("Ready");
  sendSettings();
}

void updateLeds() {
  float off = cfg.threshold - cfg.hysteresis;
  if (cfg.ledMode == 0) {
    // Each hand drives its own LED; tilting either way past the threshold turns it on
    bool *state[2] = {&leftOn, &rightOn};
    for (int i = 0; i < NUM_IMU; i++) {
      float r = fabs(tiltRoll(imus[i]));
      if (!imus[i].ok) *state[i] = false;
      else if (r > cfg.threshold) *state[i] = true;
      else if (r < off) *state[i] = false;
    }
  } else {
    // One hand: tilt left -> left LED, tilt right -> right LED
    const Imu &m = imus[cfg.ledMode - 1];
    float r = m.ok ? tiltRoll(m) : 0;
    if (cfg.invert) r = -r;
    if (r < -cfg.threshold) leftOn = true;
    else if (r > -off) leftOn = false;
    if (r > cfg.threshold) rightOn = true;
    else if (r < off) rightOn = false;
  }
  digitalWrite(LEFT_LED, leftOn ? HIGH : LOW);
  digitalWrite(RIGHT_LED, rightOn ? HIGH : LOW);
}

void loop() {
  readSerial();
  PiezoInput::update(streaming);
  UltrasonicInput::update(streaming);
  JoystickInput::update(streaming);

  // Retry missing sensors every 2 s, so they can be plugged in later.
  // If none are answering, the bus may be stuck, so recover it first.
  if (millis() - lastRetry > 2000) {
    lastRetry = millis();
    bool changed = false;
    bool anyOk = false;
    for (int i = 0; i < NUM_IMU; i++) anyOk |= imus[i].ok;
    if (!anyOk) i2cStart();
    for (int i = 0; i < NUM_IMU; i++) {
      if (!imus[i].ok) { startImu(imus[i], false); changed |= imus[i].ok; }
    }
    if (changed) sendSettings();
  }

  uint32_t now = micros();
  if (now - lastMicros < 5000) return;  // ~200 Hz update
  float dt = (now - lastMicros) * 1e-6f;
  lastMicros = now;

  for (int i = 0; i < NUM_IMU; i++) {
    Imu &m = imus[i];
    if (!m.ok) continue;
    if (!mpuReadAll(m)) {
      if (++m.failCount >= 20) {
        m.ok = false;
        sendImuInfo(i, "lost connection");
        sendSettings();
      }
      continue;
    }
    m.failCount = 0;
    toBody(m);

    // Complementary filter: gyro for fast response, accel to cancel drift.
    // Blend on the wrapped difference so roll crossing +-180 doesn't jump.
    m.roll = wrap180(m.roll + m.gyro[0] * dt);
    m.roll = wrap180(m.roll + (1 - cfg.alpha) * wrap180(accRoll(m) - m.roll));
    m.pitch = m.pitch + m.gyro[1] * dt;
    m.pitch = m.pitch + (1 - cfg.alpha) * (accPitch(m) - m.pitch);
    m.yaw = wrap180(m.yaw + m.gyro[2] * dt);  // gyro only, drifts slowly
  }

  updateLeds();

  if (streaming && millis() - lastSend >= cfg.rateMs) {
    lastSend = millis();
    sendData();
  }
  if (streaming && cfg.raw && millis() - lastRawSend >= 100) {
    lastRawSend = millis();
    sendRaw();
  }
}
