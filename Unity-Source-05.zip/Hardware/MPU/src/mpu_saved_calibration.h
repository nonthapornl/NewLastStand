#pragma once
// Fallback for a new ESP32-S3 with no saved flash settings.
// Source: docs/mpu-calibration-both-hands-2026-10-16.json
// Included after Settings/cfg have been declared. No EEPROM writes.
inline void applySavedMpuCalibration() {
  cfg.cal[0].gyroOff[0] = -103.6f;
  cfg.cal[0].gyroOff[1] = 54.3f;
  cfg.cal[0].gyroOff[2] = -350.7f;
  cfg.cal[0].accBias[0] = -1178.0f;
  cfg.cal[0].accBias[1] = -75.9f;
  cfg.cal[0].accBias[2] = -7748.3f;
  cfg.cal[0].accScale[0] = 8156.8f;
  cfg.cal[0].accScale[1] = 8158.7f;
  cfg.cal[0].accScale[2] = 8309.3f;
  cfg.cal[0].axis[0] = 0;
  cfg.cal[0].sgn[0] = 1;
  cfg.cal[0].axis[1] = 1;
  cfg.cal[0].sgn[1] = -1;
  cfg.cal[0].axis[2] = 2;
  cfg.cal[0].sgn[2] = -1;
  cfg.cal[0].rollZero = -0.3f;
  cfg.cal[0].pitchZero = 2.16f;
  cfg.cal[1].gyroOff[0] = -337.2f;
  cfg.cal[1].gyroOff[1] = -197.2f;
  cfg.cal[1].gyroOff[2] = 0.8f;
  cfg.cal[1].accBias[0] = -2228.5f;
  cfg.cal[1].accBias[1] = -2335.1f;
  cfg.cal[1].accBias[2] = -2837.5f;
  cfg.cal[1].accScale[0] = 8187.8f;
  cfg.cal[1].accScale[1] = 8171.9f;
  cfg.cal[1].accScale[2] = 8256.0f;
  cfg.cal[1].axis[0] = 0;
  cfg.cal[1].sgn[0] = 1;
  cfg.cal[1].axis[1] = 1;
  cfg.cal[1].sgn[1] = -1;
  cfg.cal[1].axis[2] = 2;
  cfg.cal[1].sgn[2] = -1;
  cfg.cal[1].rollZero = 0.26f;
  cfg.cal[1].pitchZero = 1.81f;
}
