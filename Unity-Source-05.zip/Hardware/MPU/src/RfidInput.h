#pragma once
#include <Arduino.h>

// RC522 is enabled only on the classic ESP32 wiring used by this project.
// A separate task owns SPI. Only update() on the main task writes Serial,
// keeping RFID JSON and the existing sensor packets from interleaving.
#if defined(CONFIG_IDF_TARGET_ESP32)
#include <SPI.h>
#include <MFRC522.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>

namespace RfidInput {
constexpr uint8_t SCK_PIN=14, MISO_PIN=33, MOSI_PIN=23, SS_PIN=4, RST_PIN=32;
struct Event { char uid[21]; int state; }; // state: 1 ready, 0 absent, 2 UID
static StaticQueue_t queueStorage;
static uint8_t queueBytes[8 * sizeof(Event)];
static QueueHandle_t events=nullptr;
static StaticTask_t taskStorage;
static StackType_t taskStack[3072];
static MFRC522 reader(SS_PIN, RST_PIN);

static void run(void*) {
  SPI.begin(SCK_PIN, MISO_PIN, MOSI_PIN, SS_PIN);
  bool ready=false;
  uint32_t nextProbe=0;
  int previousState=-1;
  for (;;) {
    if (!ready && static_cast<int32_t>(millis()-nextProbe)>=0) {
      reader.PCD_Init();
      byte version=reader.PCD_ReadRegister(MFRC522::VersionReg);
      ready=(version!=0 && version!=0xFF);
      int state=ready?1:0;
      if (state!=previousState) {
        Event event={}; event.state=state;
        xQueueSend(events,&event,0);
        previousState=state;
      }
      nextProbe=millis()+3000;
    }
    if (ready && reader.PICC_IsNewCardPresent() && reader.PICC_ReadCardSerial()) {
      Event event={}; event.state=2;
      const char hex[]="0123456789ABCDEF";
      byte count=reader.uid.size;
      if (count==4 || count==7 || count==10) {
        for (byte i=0;i<count;i++) {
          event.uid[2*i]=hex[reader.uid.uidByte[i]>>4];
          event.uid[2*i+1]=hex[reader.uid.uidByte[i]&15];
        }
        xQueueSend(events,&event,0);
      }
      reader.PICC_HaltA();
      reader.PCD_StopCrypto1();
    }
    // Detect an unplugged reader without blocking the IMU loop.
    if (ready && static_cast<int32_t>(millis()-nextProbe)>=0) {
      byte version=reader.PCD_ReadRegister(MFRC522::VersionReg);
      if (version==0 || version==0xFF) ready=false;
      nextProbe=millis()+3000;
    }
    vTaskDelay(pdMS_TO_TICKS(80));
  }
}
static void begin() {
  events=xQueueCreateStatic(8,sizeof(Event),queueBytes,&queueStorage);
  xTaskCreateStaticPinnedToCore(run,"rfid",3072,nullptr,1,taskStack,&taskStorage,0);
}
static void update() {
  if (!events) return;
  Event event;
  while (xQueueReceive(events,&event,0)==pdTRUE) {
    if (event.state==2) Serial.printf("{\"t\":\"id\",\"uid\":\"%s\"}\n",event.uid);
    else Serial.printf("{\"t\":\"rfid\",\"ok\":%d}\n",event.state);
  }
}
}
#else
namespace RfidInput { static void begin() {} static void update() {} }
#endif
