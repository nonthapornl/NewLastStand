#pragma once
#include <Arduino.h>
#include "PiezoKnockState.h"

#if defined(CONFIG_IDF_TARGET_ESP32)
namespace PiezoInput {
constexpr uint8_t PIN=36; // VP on the classic ESP32 38-pin board.
static PiezoKnockState detector;
static uint32_t sampleUs=0, sendAt=0;
static int raw=0, peak=0;
static void begin() {
  // The module/protected interface must provide a discharge/pull-down path.
  // VP has no internal pull. Software does not require a particular resistor value.
  pinMode(PIN,INPUT);
  analogSetPinAttenuation(PIN,ADC_11db);
  detector.begin(millis()); sampleUs=micros(); sendAt=millis();
}
static void send(bool hit) {
  Serial.printf("{\"t\":\"p\",\"seq\":%lu,\"hit\":%d,\"raw\":%d,\"peak\":%d,\"thr\":%d,\"base\":%d,\"level\":%d,\"armed\":%d,\"ok\":%d}\n",
    static_cast<unsigned long>(detector.sequence),hit?1:0,raw,peak,detector.threshold,
    static_cast<int>(detector.baseline+.5f),detector.level,detector.armed?1:0,detector.calibrated?1:0);
  peak=0; sendAt=millis();
}
static void update(bool stream) {
  uint32_t nowUs=micros();
  if (nowUs-sampleUs<1000u) return;
  sampleUs=nowUs;
  raw=analogRead(PIN); peak=max(peak,raw);
  bool hit=detector.sample(raw,millis());
  if (stream && (hit || millis()-sendAt>=200u)) send(hit);
}
static void setThreshold(int value) {
  detector.threshold=constrain(value,80,3000);
  detector.release=max(20,detector.threshold/3);
  detector.armed=false; detector.trackingLow=false;
}
static void zero() { detector.begin(millis()); peak=0; }
}
#else
namespace PiezoInput { static void begin() {} static void update(bool) {} static void setThreshold(int) {} static void zero() {} }
#endif
