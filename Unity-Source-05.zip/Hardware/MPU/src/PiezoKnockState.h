#pragma once
#include <stdint.h>

// Detect excursions from the measured quiet baseline, not from absolute ADC 0.
// A quiet return is required before another hit; ringing cannot retrigger it.
struct PiezoKnockState {
  int threshold=200, release=90;
  float baseline=0;
  int level=0;
  uint32_t sequence=0, started=0, lowSince=0, lastHit=0;
  bool armed=false, trackingLow=false, hasHit=false, calibrated=false;
  uint16_t warmCount[64]={};
  uint32_t warmSum[64]={}, warmSamples=0;
  void begin(uint32_t now) {
    sequence=0; started=now; lowSince=lastHit=now;
    armed=trackingLow=hasHit=calibrated=false;
    baseline=0; level=0; warmSamples=0;
    for(int i=0;i<64;i++){warmCount[i]=0;warmSum[i]=0;}
  }
  bool sample(int raw,uint32_t now) {
    if (raw<0) raw=0;
    if (raw>4095) raw=4095;
    if (now-started<800u) {
      int bin=raw/64;
      ++warmCount[bin]; warmSum[bin]+=raw; ++warmSamples;
      return false;
    }
    if (!calibrated) {
      // Median bucket resists occasional startup taps. Mean within that bucket
      // avoids quantizing a quiet zero input to a nonzero bucket centre.
      baseline=static_cast<float>(raw);
      uint32_t seen=0;
      for(int i=0;i<64 && warmSamples>0;i++) {
        seen+=warmCount[i];
        if (seen>=(warmSamples+1)/2 && warmCount[i]>0) {
          baseline=static_cast<float>(warmSum[i])/warmCount[i]; break;
        }
      }
      calibrated=true;
    }
    int difference=raw-static_cast<int>(baseline+.5f);
    level=difference<0?-difference:difference;
    if (level<release) {
      // Follow slow drift only while quiet. Never learn the actual impact.
      baseline+=(static_cast<float>(raw)-baseline)*.005f;
      if (!trackingLow) {trackingLow=true; lowSince=now;}
      if (now-lowSince>=80u && (!hasHit || now-lastHit>=300u)) armed=true;
    } else trackingLow=false;
    if (!armed || level<threshold) return false;
    armed=false; trackingLow=false; hasHit=true; lastHit=now; ++sequence;
    return true;
  }
};
