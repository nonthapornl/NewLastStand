#pragma once
#include <Arduino.h>

// Classic ESP32 only: joystick power is 3.3 V, not 5 V.
#if defined(CONFIG_IDF_TARGET_ESP32)
namespace JoystickInput {
constexpr uint8_t X_PIN = 34, Y_PIN = 35, SW_PIN = 27;
static int centerX = 2048, centerY = 2048;
static int x = 0, y = 0, rawX = 2048, rawY = 2048;
static bool candidateButton = false, button = false;
static uint32_t buttonAt = 0, sampleAt = 0, sendAt = 0;

static int readAxis(uint8_t pin) {
  uint32_t sum = 0;
  for (uint8_t i = 0; i < 4; i++) sum += analogRead(pin);
  return sum / 4;
}

static int direction(int value, int center, int previous) {
  const int delta = value - center;
  if (delta < -700) return -1;
  if (delta > 700) return 1;
  if (previous < 0 && delta < -450) return -1;
  if (previous > 0 && delta > 450) return 1;
  return 0;
}

static void begin() {
  pinMode(X_PIN, INPUT); pinMode(Y_PIN, INPUT);
  pinMode(SW_PIN, INPUT_PULLUP);
  analogReadResolution(12);
  analogSetPinAttenuation(X_PIN, ADC_11db);
  analogSetPinAttenuation(Y_PIN, ADC_11db);
  uint32_t sx = 0, sy = 0;
  for (uint8_t i = 0; i < 32; i++) {
    sx += analogRead(X_PIN); sy += analogRead(Y_PIN); delay(1);
  }
  centerX = sx / 32; centerY = sy / 32;
  // A stick held at an endpoint during boot must not become the centre.
  if (centerX < 1000 || centerX > 3000) centerX = 2048;
  if (centerY < 1000 || centerY > 3000) centerY = 2048;
  candidateButton = button = digitalRead(SW_PIN) == LOW;
  buttonAt = sampleAt = sendAt = millis();
}

static void update(bool stream) {
  const uint32_t now = millis();
  if (now - sampleAt < 10u) return;
  sampleAt = now;
  rawX = readAxis(X_PIN); rawY = readAxis(Y_PIN);
  x = direction(rawX, centerX, x);
  // Default: low VRy is UP. Unity exposes axis inversion for other mounts.
  y = direction(rawY, centerY, y);
  const bool pressed = digitalRead(SW_PIN) == LOW;
  if (pressed != candidateButton) { candidateButton = pressed; buttonAt = now; }
  if (now - buttonAt >= 25u) button = candidateButton;
  if (stream && now - sendAt >= 50u) {
    sendAt = now;
    Serial.print("{\"t\":\"j\",\"v\":[");
    Serial.print(x); Serial.print(',');
    Serial.print(-y); Serial.print(','); Serial.print(button ? 1 : 0);
    Serial.print("],\"raw\":["); Serial.print(rawX); Serial.print(',');
    Serial.print(rawY); Serial.println("]}");
  }
}
}
#else
namespace JoystickInput { static void begin() {} static void update(bool) {} }
#endif
