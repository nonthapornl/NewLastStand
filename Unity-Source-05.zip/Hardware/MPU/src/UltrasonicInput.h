#pragma once
#include <Arduino.h>

// HC-SR04: classic ESP32 TRIG=25/ECHO=26; S3 TRIG=6/ECHO=7.
// ECHO always goes through a 5 V -> 3.3 V divider.
// Capture echo edges in an interrupt so missing echoes never block MPU updates.
#if defined(ARDUINO_ARCH_ESP32)
namespace UltrasonicInput {
#if defined(CONFIG_IDF_TARGET_ESP32)
constexpr uint8_t TRIG = 25, ECHO = 26;
#else
constexpr uint8_t TRIG = 6, ECHO = 7;
#endif
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
static volatile bool waiting = false, rising = false, ready = false;
static volatile uint32_t riseUs = 0, pulseUs = 0;
static uint32_t triggerUs = 0, cycleUs = 0;

static void ARDUINO_ISR_ATTR echoChanged() {
  const bool high = digitalRead(ECHO);
  const uint32_t now = micros();
  portENTER_CRITICAL_ISR(&mux);
  if (waiting) {
    if (high) { riseUs = now; rising = true; }
    else if (rising) {
      pulseUs = now - riseUs;
      ready = true; waiting = false; rising = false;
    }
  }
  portEXIT_CRITICAL_ISR(&mux);
}

static void begin() {
  pinMode(TRIG, OUTPUT); digitalWrite(TRIG, LOW);
  pinMode(ECHO, INPUT);
  attachInterrupt(digitalPinToInterrupt(ECHO), echoChanged, CHANGE);
  cycleUs = micros() - 70000u;
}

// Explicit diagnostic only: briefly pause the interrupt reader and compare
// against Arduino pulseIn. Normal gameplay never calls this blocking path.
static void diagnose() {
  detachInterrupt(digitalPinToInterrupt(ECHO));
  pinMode(TRIG, OUTPUT); // ESP32 Arduino OUTPUT also enables pad readback.
  portENTER_CRITICAL(&mux);
  waiting = false; rising = false; ready = false;
  portEXIT_CRITICAL(&mux);
  for (uint8_t i = 0; i < 3; ++i) {
    delay(70);
    digitalWrite(TRIG, LOW); delayMicroseconds(2);
    digitalWrite(TRIG, HIGH);
    const int trigHigh = digitalRead(TRIG);
    delayMicroseconds(10); digitalWrite(TRIG, LOW);
    const uint32_t width = pulseIn(ECHO, HIGH, 30000u);
    Serial.print("{\"t\":\"i\",\"msg\":\"USCHECK TRIG");
    Serial.print(TRIG); Serial.print("=");
    Serial.print(trigHigh); Serial.print(" ECHO"); Serial.print(ECHO); Serial.print("=");
    Serial.print(digitalRead(ECHO)); Serial.print(" pulse_us=");
    Serial.print(width); Serial.print(" cm=");
    Serial.print(width / 58.0f, 1); Serial.println("\"}");
  }
  pinMode(TRIG, OUTPUT);
  digitalWrite(TRIG, LOW);
  cycleUs = micros();
  attachInterrupt(digitalPinToInterrupt(ECHO), echoChanged, CHANGE);
}

static void update(bool stream) {
  const uint32_t now = micros();
  bool report = false; uint32_t width = 0;
  portENTER_CRITICAL(&mux);
  if (ready) { width = pulseUs; ready = false; report = true; }
  else if (waiting && now - triggerUs >= 25000u) {
    waiting = false; rising = false; report = true;
  }
  portEXIT_CRITICAL(&mux);
  if (report && stream) {
    const bool valid = width >= 116u && width <= 23200u;
    Serial.print("{\"t\":\"u\",\"cm\":");
    Serial.print(valid ? width / 58.0f : 0.0f, 1);
    Serial.print(",\"ok\":"); Serial.print(valid ? 1 : 0); Serial.println("}");
  }
  if (now - cycleUs >= 70000u) {
    cycleUs = triggerUs = now;
    portENTER_CRITICAL(&mux);
    waiting = true; rising = false; ready = false;
    portEXIT_CRITICAL(&mux);
    digitalWrite(TRIG, HIGH); delayMicroseconds(10); digitalWrite(TRIG, LOW);
  }
}
}
#else
namespace UltrasonicInput {
static void begin() {}
static void update(bool) {}
static void diagnose() {}
}
#endif
